# STATE T5_band_mean (started 2026-11-12)
## Read so far (done)
- closure/loop2/REPORT.md sec 3 + check3_exit_line.py; mixer_v2/feed_loop_02.py.
- HIS definitions (quoted from /home/claude/notes/NOTES_15_DRIVE_LIGHT_WEIGHT_OFFSET.md lines ~54-62, from Exit Line paper s4/Prop 4.2 / Thm 5.4):
  h(k) = [[iu, v + w e^{-ik}],[v + w e^{ik}, -iu]], E(k)^2 = v^2+w^2-u^2+2vw cos k, K(k)=1+u^2/E(k)^2, <K>=1+u^2/(E(0)E(pi)),
  <K>=2 iff E(0)E(pi)=u^2 iff (w^2-v^2)^2 = 2u^2(w^2+v^2). w=1: u_exit=(1-v^2)/sqrt(2(1+v^2)); u=0.5 -> v_exit=0.46821319...; u=.25,.45,.65 -> v=0.7474014,0.5291503,0.2357262.
  Also /home/claude/nov/matter/EXTRACT.md line 16-17 (G2: gamma^2=u^2/(E0 Epi)=Kbar-1).
## Plan / checks (kill lines written BEFORE running)
S1 s1_kz.py: closed form from loop: A=|v+we^{ik}|, A^2/u^2 = (2G^2)^(-1) inside wall, (2G^2) past. So cos k = (u^2 (2G^2)^(-+1) - v^2 - w^2)/(2vw).
  WHY decides: A^2/u^2 is the only band quantity the loop fixes (scale free); K=A^2/(A^2-u^2) is independent of scale.
  KILL: for any of the 12 z, rel resid > 1e-12 between (i) K_band(k(z)) and K_W from W biorthogonal eigvecs, or (ii) A^2/u^2 from k(z) and from |a|,|b| of log(-W) -> closed form killed.
  KILL2: |k(3)-k*|>1e-12 or |k(z=1e25)-k*|>1e-12 where K(k*)=2 -> "z=3 and rim pick the same k" killed.
S2 s2_readings.py readings, each kill = |value-2|>1e-10 (value stated before run):
  (a) mean of K over z with measure dk(z), over the z-range the exit band covers (inside branch). Expect 2 by change of variable. Opposites: mean uniform in z, in ln z, in G, in turn angle theta; mean of 1/K (target 1/2).
  (b) pair across wall G G'=1/2: expect K(G)=K(G') exactly (so pair mean = K, =2 only at G=1/2,G'=1). Kill: |K-K'|>1e-10.
  (c) three perpendicular pairs ij,jk,ki: expect identical K (spectrum symmetric) so mean=K(z), =2 only z=3. Kill: spread >1e-10. Arms: mean over sphere of sin^2 phi etc.
  (d) 1/K0+1/Kpi for band ends at exit parameters: expect exactly 1 (since 1/K = 1-2G^2 inside), <=> G0^2+G1^2=1/2. Kill |sum-1|>1e-10. Opposite: K0+Kpi, K0*Kpi, sqrt(K0 Kpi) vs 2 (expect fail).
  (e) mean over one full turn (x=n theta, integral over 2pi) of K(Gamma_n), Gamma_n=-sin(phi) sin x: expect 1/sqrt(1-2 sin^2 phi) (=2 iff sin^2phi=3/8); opposite mean of 1/K = 1-sin^2 phi (=1/2 iff sin^2 phi=1/2, the half line). Kill: no tree arm (z in list, 7 prepared arms) gives 2 to 1e-10.
  (f) general exit identity: random G0,G1 with G0^2+G1^2=1/2 -> band built, <K> by quadrature =2 within 1e-10; random G0,G1 off the circle -> must differ.
## Status
S1 DONE: PASS, worst residual 8.0e-25 (K vs W biorthogonal, A2/u2 vs log(-W), k(3)=k*, k(1e25)->k*). Output s1_out.txt. Next: S2 python3 s2_readings.py
S2 DONE (s2_out.txt): (a),(b),(c-trivial),(d),(f) as predicted; (a-opp) all other measures FAIL; (e) no arm gives mean K=2; arm +-z has sin^2phi = 2G^2 at z=2,3,4,5 (to 4 digits) -> S3.
S3 (s3_arm.py): WHY: if sin^2(phi)=2G^2 for the +-z arm then turn-mean of Gamma_n^2 = G^2 and turn-mean of 1/K(Gamma_n) = 1-2G^2 = 1/K_W(z). KILL (written before run): |sin^2phi - 2G^2| > 1e-10 at any inside-wall z in the list (1.5,2,3,4,5,5.5,5.8) for either +z or -z arm, or at 20 random z in (1.01,5.8).
ALL STEPS DONE. Final: REPORT.md
