# SCRIPT: T5-S1-KZ
# WHY: loop fixes only A^2/u^2 (A=|v+w e^{ik}|); K=A^2/(A^2-u^2) is scale free. Closed form for k(z) tested against W itself.
# KILL: rel resid > 1e-12 in K or in A^2/u^2 vs W-derived values; |k(3)-k*|>1e-12; |k(1e25)-k*|>1e-12.
import mpmath as mp
mp.mp.dps=60
sig=[mp.matrix([[0,1],[1,0]]),mp.matrix([[0,-1j],[1j,0]]),mp.matrix([[1,0],[0,-1]])]
def W_of(z):
    r=mp.log(mp.mpf(z)); c,s=mp.cosh(r/2),mp.sinh(r/2)
    Bx=mp.matrix([[c,s],[s,c]]); By=mp.matrix([[c,-1j*s],[1j*s,c]]); Bxi=mp.matrix([[c,-s],[-s,c]]); Byi=mp.matrix([[c,1j*s],[-1j*s,c]])
    return Bx*By*Bxi*Byi
def Ktrue(W):
    E,V=mp.eig(W); VL=mp.inverse(V).H
    r=V[:,0]; l=VL[:,0]
    nr=sum(abs(x)**2 for x in r); nl=sum(abs(x)**2 for x in l); ov=abs(sum(l[j].conjugate()*r[j] for j in range(2)))**2
    return nr*nl/ov
def mloop(z):
    W=W_of(z); M=-W; E,V=mp.eig(M); L=V*mp.diag([mp.log(E[0]),mp.log(E[1])])*mp.inverse(V)
    c=[((L*sg)[0,0]+(L*sg)[1,1])/2 for sg in sig]
    na=mp.sqrt(sum(x.real**2 for x in c)); nb=mp.sqrt(sum(x.imag**2 for x in c))
    return (nb**2/na**2) if na<nb else (na**2/nb**2)   # A^2/u^2
def band_exit(u,w=1):
    u=mp.mpf(u); t=1+u*u-u*mp.sqrt(u*u+4); return u,mp.sqrt(t),mp.mpf(w)
def kz(z,u,v,w):
    G2=mp.tanh(mp.log(mp.mpf(z))/2)**2
    m=1/(2*G2) if G2<mp.mpf(1)/2 else 2*G2
    c=(u*u*m-v*v-w*w)/(2*v*w)
    return m,c,mp.acos(c)
ZS=['1.5','2','3','4','5','5.5','5.8','6.5','7','8','16.8177','206.768']
worst=0
for u0 in ['0.5','0.25','0.45','0.65']:
    u,v,w=band_exit(u0)
    chk=(1-v*v)**2-2*u*u*w*w*(1+v*v)  # exit-line identity with w=1
    E0=mp.sqrt((v+w)**2-u*u); Ep=mp.sqrt((w-v)**2-u*u)
    print('BAND u=%s w=1 v=%s  exit resid %s  <K>=%s  E0Epi-u^2=%s'%(u0,mp.nstr(v,15),mp.nstr(chk,3),mp.nstr(1+u*u/(E0*Ep),15),mp.nstr(E0*Ep-u*u,3)))
    print(' m range [(w-v)^2/u^2,(w+v)^2/u^2] = [%s, %s]; K(0)=%s K(pi)=%s'%(mp.nstr((w-v)**2/u**2,8),mp.nstr((w+v)**2/u**2,8),mp.nstr(1+u*u/E0**2,10),mp.nstr(1+u*u/Ep**2,10)))
    kst=mp.acos((2*u*u-v*v-w*w)/(2*v*w))
    print(' k* (K(k*)=2, E(k*)=u) = %s'%mp.nstr(kst,20))
    for z in ZS:
        m,c,k=kz(z,u,v,w)
        A2=v*v+w*w+2*v*w*c; Kb=A2/(A2-u*u); Kw=Ktrue(W_of(z)); ml=mloop(z)
        r1=abs(Kb-Kw)/Kw; r2=abs(m-ml)/m; worst=max(worst,r1,r2)
        inband='in band' if abs(c)<=1 else 'OFF band (k complex)'
        kk=mp.nstr(k.real if mp.im(k)==0 else k,12)
        print('  z=%-9s %-6s m=A2/u2=%-12s cos k=%-14s k=%-28s %-20s Kw=%-12s res K %s res m %s'%(z,'inside' if mp.tanh(mp.log(mp.mpf(z))/2)**2<0.5 else 'past',mp.nstr(m,8),mp.nstr(c,10),kk,inband,mp.nstr(Kw,8),mp.nstr(r1,2),mp.nstr(r2,2)))
    m3,c3,k3=kz('3',u,v,w); mr,cr,kr=kz('1e25',u,v,w)
    print(' k(3)-k* = %s ; k(1e25)-k* = %s'%(mp.nstr(k3-kst,3),mp.nstr(kr-kst,3)))
    worst=max(worst,abs(k3-kst),abs(kr-kst))
print('WORST residual over everything:',mp.nstr(worst,3),' kill line 1e-12 ->','PASS' if worst<1e-12 else 'FAIL')
