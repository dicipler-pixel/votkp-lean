# SCRIPT: T5-S2-READINGS
# WHY: each reading is a candidate tree meaning of <K>=1+u^2/(E0 Epi)=2. Kill lines (|value-2|>1e-10 where a value 2 is predicted) in STATE.md, written before the run.
import mpmath as mp, random, numpy as np
from scipy.linalg import expm
mp.mp.dps=40
def band_exit(u):
    u=mp.mpf(u); t=1+u*u-u*mp.sqrt(u*u+4); return u,mp.sqrt(t),mp.mpf(1)
Gof=lambda z: (mp.mpf(z)-1)/(mp.mpf(z)+1)
Kin=lambda G: 1/(1-2*G*G)
TOL=mp.mpf('1e-10'); res=[]
def rep(tag,val,target,note=''):
    ok=abs(val-target)<=TOL
    print('%-58s value=%-24s target=%-8s %s %s'%(tag,mp.nstr(val,16),mp.nstr(target,6),'PASS' if ok else 'FAIL',note)); res.append((tag,ok))
for u0 in ['0.5','0.25','0.45','0.65']:
    u,v,w=band_exit(u0); print('\n=== exit band u=%s v=%s w=1'%(u0,mp.nstr(v,12)))
    mmax=(w+v)**2/u**2; mmin=(w-v)**2/u**2     # m=A^2/u^2 ; k=0 -> mmax, k=pi -> mmin
    G0=mp.sqrt(1/(2*mmax)); G1=mp.sqrt(1/(2*mmin)); z0=(1+G0)/(1-G0); z1=(1+G1)/(1-G1)
    print('band ends inside wall: G0=%s G1=%s ; z0=%s z1=%s ; G0^2+G1^2=%s'%(mp.nstr(G0,12),mp.nstr(G1,12),mp.nstr(z0,10),mp.nstr(z1,10),mp.nstr(G0**2+G1**2,20)))
    cosk=lambda G:(u*u/(2*G*G)-v*v-w*w)/(2*v*w)
    kG=lambda G: mp.acos(max(min(cosk(G),1),-1))
    dkdG=lambda G: (u*u/(2*v*w*G**3))/mp.sqrt(1-cosk(G)**2)      # |dk/dG|
    # (a) mean of K over z with measure dk(z): integral K dk / pi
    meanK=mp.quad(lambda G: Kin(G)*dkdG(G),[G0,(G0+G1)/2,G1])/mp.pi
    rep('(a) <K> with measure dk(z), z in [z0,z1]',meanK,2)
    rep('(a) check length of k range = pi',mp.quad(dkdG,[G0,(G0+G1)/2,G1]),mp.pi)
    # opposites: other measures on the same z range
    Gm=lambda G: Kin(G)
    rep('(a-opp) uniform in G',mp.quad(Gm,[G0,G1])/(G1-G0),2)
    rep('(a-opp) uniform in z',mp.quad(lambda z:Kin(Gof(z)),[z0,z1])/(z1-z0),2)
    rep('(a-opp) uniform in ln z (rapidity)',mp.quad(lambda r:Kin(mp.tanh(r/2)),[mp.log(z0),mp.log(z1)])/(mp.log(z1)-mp.log(z0)),2)
    th=lambda G: 2*mp.acos(1-2*mp.sinh(mp.atanh(G))**4)
    rep('(a-opp) uniform in loop turn angle theta',mp.quad(lambda G:Kin(G)*mp.diff(th,G),[G0,G1])/(th(G1)-th(G0)),2)
    rep('(a-opp) uniform in 2G^2',mp.quad(lambda G:Kin(G)*4*G,[G0,G1])/(2*(G1**2-G0**2)),2)
    rep('(a-opp) mean of 1/K with dk(z)',mp.quad(lambda G:dkdG(G)/Kin(G),[G0,(G0+G1)/2,G1])/mp.pi,mp.mpf(1)/2,'closed form 1-u^2/(w^2-v^2)=%s'%mp.nstr(1-u*u/(w*w-v*v),12))
    # (b) pair across the wall G G'=1/2, G in [1/2, 1/sqrt2)
    for g in ['0.5','0.55','0.6','0.65','0.7']:
        g=mp.mpf(g); gp=1/(2*g); Kp=2*gp*gp/(2*gp*gp-1)
        rep('(b) K(G=%s) vs K(G\'=1/(2G)=%s) past wall'%(mp.nstr(g,3),mp.nstr(gp,6)),Kin(g)-Kp,0,'K=%s'%mp.nstr(Kin(g),10))
    # (c) the three perpendicular pairs are identical by symmetry: tested in s2c below
    # (d) 1/K0+1/Kpi
    K0=1+u*u/((w+v)**2-u*u); K1=1+u*u/((w-v)**2-u*u)
    rep('(d) 1/K(0)+1/K(pi)',1/K0+1/K1,1,'<=> G0^2+G1^2=1/2')
    rep('(d-opp) K(0)+K(pi)',K0+K1,2); rep('(d-opp) K(0)*K(pi)',K0*K1,2); rep('(d-opp) sqrt(K0 Kpi)',mp.sqrt(K0*K1),2)
    rep('(d) sqrt((K0-1)(Kpi-1)) geometric mean of excesses',mp.sqrt((K0-1)*(K1-1)),1)
    # z carrying the band mean: K(k_g)=<K> <=> E(k_g)^2=E0 Epi
    E0=mp.sqrt((w+v)**2-u*u); E1=mp.sqrt((w-v)**2-u*u); cg=(E0*E1-v*v-w*w+u*u)/(2*v*w)
    print('k_g with K(k_g)=<K> (E^2=E0Epi): cos k_g=%s k_g=%s ; k_g/pi=%s'%(mp.nstr(cg,12),mp.nstr(mp.acos(cg),14),mp.nstr(mp.acos(cg)/mp.pi,10)))
    Gg=mp.sqrt((1-1/mp.mpf(2))/2); print('z carrying K=2: G=%s z=%s (inside branch) ; same k as z=3 and rim: %s'%(mp.nstr(Gg,6),mp.nstr((1+Gg)/(1-Gg),6),'yes' if abs(cg-cosk(mp.mpf(1)/2))<1e-30 else 'NO'))
print('\n=== (f) general identity <K> = 1 + 2 G0 G1 / sqrt((1-2G0^2)(1-2G1^2)); exit <=> G0^2+G1^2=1/2')
random.seed(7); worst=0; worst2=0
for i in range(40):
    G0=mp.mpf(random.uniform(0.05,0.69)); G1=mp.mpf(random.uniform(0.05,0.69))
    if G0==G1: continue
    lo,hi=min(G0,G1),max(G0,G1); wv=1/(mp.sqrt(2)*lo); wm=1/(mp.sqrt(2)*hi); w=(wv+wm)/2; v=(wv-wm)/2; u=mp.mpf(1)
    Em=lambda k: mp.sqrt(v*v+w*w-u*u+2*v*w*mp.cos(k))
    q=mp.quad(lambda k:1+u*u/Em(k)**2,[0,mp.pi/2,mp.pi])/mp.pi
    cf=1+2*lo*hi/mp.sqrt((1-2*lo**2)*(1-2*hi**2)); worst=max(worst,abs(q-cf))
    if hi>=mp.sqrt(0.5): continue
for i in range(40):
    G0=mp.mpf(random.uniform(0.01,0.7)); G1=mp.sqrt(mp.mpf(1)/2-G0**2)
    if abs(G0-G1)<1e-6: continue
    lo,hi=min(G0,G1),max(G0,G1); wv=1/(mp.sqrt(2)*lo); wm=1/(mp.sqrt(2)*hi); w=(wv+wm)/2; v=(wv-wm)/2; u=mp.mpf(1)
    Em=lambda k: mp.sqrt(v*v+w*w-u*u+2*v*w*mp.cos(k))
    q=mp.quad(lambda k:1+u*u/Em(k)**2,[0,mp.pi/2,mp.pi])/mp.pi; worst2=max(worst2,abs(q-2))
rep('(f) random pairs: quad <K> vs closed form, worst diff',worst,0)
rep('(f) pairs with G0^2+G1^2=1/2: quad <K> vs 2, worst diff',worst2,0)
print('off-circle example G0=G1=0.3: <K>=',mp.nstr(1+2*mp.mpf('0.09')/(1-2*mp.mpf('0.09')),10),' (not 2)')
# (c) three perpendicular pairs
sx=mp.matrix([[0,1],[1,0]]); sy=mp.matrix([[0,-1j],[1j,0]]); sz=mp.matrix([[1,0],[0,-1]]); S=[sx,sy,sz]
def Bm(a,r): return mp.expm(S[a]*r/2)
def Ktrue(W):
    E,V=mp.eig(W); VL=mp.inverse(V).H; r=V[:,0]; l=VL[:,0]
    return sum(abs(x)**2 for x in r)*sum(abs(x)**2 for x in l)/abs(sum(l[j].conjugate()*r[j] for j in range(2)))**2
print('\n=== (c) three perpendicular pairs ij, jk, ki at each z')
for z in ['2','3','4','5']:
    r=mp.log(mp.mpf(z)); Ks=[]
    for (i,j) in [(0,1),(1,2),(2,0)]:
        W=Bm(i,r)*Bm(j,r)*Bm(i,-r)*Bm(j,-r); Ks.append(Ktrue(W))
    rep('(c) z=%s: spread of K over three pairs'%z,max(Ks)-min(Ks),0,'mean K=%s vs 1/(1-2G^2)=%s'%(mp.nstr(sum(Ks)/3,12),mp.nstr(Kin(Gof(z)),12)))
rep('(c) mean K over three pairs at z=5 equals 2?',Ktrue(Bm(0,mp.log(5))*Bm(1,mp.log(5))*Bm(0,-mp.log(5))*Bm(1,-mp.log(5))),2)
# (e) full turn of loop-fed signal; arms from feed_loop_02 anatomy (numpy)
print('\n=== (e) mean over a full turn of K(Gamma_n), Gamma_n=-sin(phi) sin x ; arms = 7 prepared directions')
sxn=np.array([[0,1],[1,0]],complex); syn=np.array([[0,-1j],[1j,0]]); szn=np.array([[1,0],[0,-1]],complex); SIG=[sxn,syn,szn]; I2=np.eye(2)
B=lambda a,r: expm(0.5*r*SIG[a]); loop=lambda r: B(0,r)@B(1,r)@B(0,-r)@B(1,-r)
def bloch(p): p=p/np.linalg.norm(p); return np.array([np.real(p.conj()@s@p) for s in SIG])
def state(v): v=np.array(v,float); v/=np.linalg.norm(v); P=0.5*(I2+sum(v[i]*SIG[i] for i in range(3))); w,V=np.linalg.eigh(P); return V[:,1]
def arm(z,prep):
    r=np.log(z); W=loop(r); w,V=np.linalg.eig(W); e1,e2=bloch(V[:,0]),bloch(V[:,1]); alpha=np.arccos(np.clip(e1@e2,-1,1))
    d=(e1+e2); d/=np.linalg.norm(d); rho=(1-np.sin(alpha/2))/np.cos(alpha/2); eta=2*np.arctanh(rho); S_=expm(0.5*eta*sum(d[i]*SIG[i] for i in range(3)))
    U=np.linalg.inv(S_)@W@S_; ax=-np.array([np.trace(U@s).imag for s in SIG]); ax/=np.linalg.norm(ax)
    s0=bloch(np.linalg.inv(S_)@state(prep)); return float(np.sqrt(max(0,1-(s0@ax)**2)))
for z in [2.0,3.0,4.0,5.0]:
    out=[]
    for p in ([1,0,0],[0,1,0],[0,0,1],[0,0,-1],[1,1,1],[1,1,0],[-1,-1,0]):
        s=arm(z,p); s2=s*s
        if 2*s2<1:
            mK=mp.quad(lambda x:1/(1-2*(mp.mpf(s)*mp.sin(x))**2),[0,mp.pi/2,mp.pi,3*mp.pi/2,2*mp.pi])/(2*mp.pi); out.append('s2=%.4f meanK=%s'%(s2,mp.nstr(mK,8)))
        else: out.append('s2=%.4f meanK diverges'%s2)
        m1=mp.quad(lambda x:1-2*(mp.mpf(s)*mp.sin(x))**2,[0,2*mp.pi])/(2*mp.pi)
    print(' z=%s : '%z+' | '.join(out))
print(' 1/K mean over a turn = 1 - sin^2 phi (analytic, =1/2 iff sin^2 phi=1/2 = half line); K mean = 1/sqrt(1-2 sin^2 phi) =2 iff sin^2 phi=3/8')
print(' sphere average of sin^2 phi = 2/3 -> mean 1/K over arms and turn = 1/3 (not 1/2); tested analytically only')
print('\nSUMMARY (tag, pass):'); [print(' ',t,'PASS' if o else 'FAIL') for t,o in res]
