# SCRIPT: T5-S3-ARM
# WHY: tests sin^2(phi)=2G^2 for the +-z prepared arm of the loop-fed signal (feed_loop_02 anatomy, copied functions). Kill line in STATE.md.
import numpy as np, random
from scipy.linalg import expm
sxn=np.array([[0,1],[1,0]],complex); syn=np.array([[0,-1j],[1j,0]]); szn=np.array([[1,0],[0,-1]],complex); SIG=[sxn,syn,szn]; I2=np.eye(2)
B=lambda a,r: expm(0.5*r*SIG[a]); loop=lambda r: B(0,r)@B(1,r)@B(0,-r)@B(1,-r)
def bloch(p): p=p/np.linalg.norm(p); return np.array([np.real(p.conj()@s@p) for s in SIG])
def state(v): v=np.array(v,float); v/=np.linalg.norm(v); P=0.5*(I2+sum(v[i]*SIG[i] for i in range(3))); w,V=np.linalg.eigh(P); return V[:,1]
def s2(z,prep):
    r=np.log(z); W=loop(r); w,V=np.linalg.eig(W); e1,e2=bloch(V[:,0]),bloch(V[:,1]); alpha=np.arccos(np.clip(e1@e2,-1,1))
    d=(e1+e2); d/=np.linalg.norm(d); rho=(1-np.sin(alpha/2))/np.cos(alpha/2); eta=2*np.arctanh(rho); S_=expm(0.5*eta*sum(d[i]*SIG[i] for i in range(3)))
    U=np.linalg.inv(S_)@W@S_; ax=-np.array([np.trace(U@s).imag for s in SIG]); ax/=np.linalg.norm(ax)
    s0=bloch(np.linalg.inv(S_)@state(prep)); return 1-(s0@ax)**2
worst=0
zs=[1.5,2,3,4,5,5.5,5.8]+[random.Random(3).uniform(1.01,5.8) for _ in range(0)]
rg=random.Random(11); zs+= [rg.uniform(1.01,5.8) for _ in range(20)]
for z in zs:
    G2=((z-1)/(z+1))**2
    for p in ([0,0,1],[0,0,-1]):
        s=s2(z,p); worst=max(worst,abs(s-2*G2))
    print('z=%.6f  sin2phi(+z)=%.12f  sin2phi(-z)=%.12f  2G^2=%.12f'%(z,s2(z,[0,0,1]),s2(z,[0,0,-1]),2*G2))
print('WORST |sin2phi-2G^2| =',worst,'kill 1e-10 ->','PASS' if worst<1e-10 else 'FAIL')
