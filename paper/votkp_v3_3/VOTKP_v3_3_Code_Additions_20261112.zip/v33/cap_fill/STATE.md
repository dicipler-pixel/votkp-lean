# STATE T3_cap_fill  (worker T3; kill lines written BEFORE any run of script 1/2)

## Status
- [ ] 0 read inputs (done: RULES, BOARD, loop2 REPORT sec 2, check2/2b/2c, feed_loop_02)
- [x] 1 t3_a_failures.py DONE (reproduced 8 own + 11 lab = 19, 0 mismatch vs stored N(2000)/cap; zero-slack cases (cap exact: eps .5 at sin2phi=1 and at z=3 2G^2) exist: 14 of 144). Output t3_a_failures.out/.json. Note: t3_validate.py confirmed new exact orbit = old matrix orbit to 1e-11.
- [x] 2 done (A,B killed; E killed; K-0 holds), see REPORT.md
- [x] 3 done
- [x] 4 done; REPORT.md written. Nothing running.

## Paper derivation (written before running)
Own frame: n points k*alpha mod 1 (alpha = theta/2pi, irrational), on a circle of length 2pi (angles). Pairwise distinguishable
iff circular distance >= d, d = 2 arcsin(s_e), s_e = sqrt(eps/2)/sin(phi). cap = floor(2pi/d). Slack for m points:
sigma_m = 2pi - m*d  (>= 0 for m <= cap).
CHAIN ARGUMENT (rigorous, new; tighter than the old floor((2pi-g)/(d+g)) bound): start at any point x_0. Let x_{j+1} be the first point
at or after x_j + d. Because the largest gap is g_n, x_{j+1} < x_j + d + g_n. So x_{m-1} < x_0 + (m-1)(d+g_n). The m points are
pairwise >= d apart if x_{m-1} + d <= x_0 + 2pi, which holds when (m-1) g_n <= 2pi - m d = sigma_m.
  => N(n) >= m whenever g_n <= T_m := sigma_m/(m-1)      (m >= 2).
For m = cap, T_cap = sigma_cap/(cap-1) ~ (2pi/cap - d) * cap/(cap-1): this is the "stated fraction (about 1) of the slack of the cap".
g_n is non-increasing in n (prefix sets nested). So the first n at which the law fires is
  n_A(m) = min { n : g_n <= T_m }   and  n_first(m) <= n_A(m)  ALWAYS (sufficient condition, so measured can never be larger).
Three-gap closed form (own frame): with convergents q_k and eta_k = || q_k alpha || * 2pi, for n = j*q_k + q_{k-1} + r (1<=j<=a_{k+1}, 0<=r<q_k)
the gaps are eta_k, eta_{k-1}-j*eta_k, eta_{k-1}-(j-1)*eta_k and the largest is eta_{k-1}-(j-1)*eta_k. So g_n is a step function constant on
blocks of q_k consecutive n, and n_A(m) = j*q_k + q_{k-1} for the first (k,j) with eta_{k-1}-(j-1)*eta_k <= T_m  (checked numerically vs direct gaps).
Candidate B (mean overshoot, heuristic): each greedy step overshoots by the distance from x+d to the next point; for a uniform
position this has mean  e_n = sum_i g_i^2 /(2*2pi). A chain of m points costs about (m-1)*e_n of slack:
  n_B(m) = min { n : (m-1) * e_n <= sigma_m }.
(Min over starting points should beat the mean, so I expect n_first < n_B; B is the typical-case reading, A is the worst-case reading.)
OPPOSITE CLASS (derived on paper): if sigma_cap = 0 exactly (floor tight: 2pi/d integer, e.g. sin(phi)=1, eps=1/2: d=pi/3, cap=6)
then N=cap would need cap points pairwise exactly d apart = exactly 2pi/cap apart, i.e. a difference k*alpha = 1/cap mod 1 : impossible
for irrational alpha. So N(n) <= cap-1 for ALL n: "never within 0" is a real class, cap is a supremum never attained; only cap-1 is reachable.
For sigma_cap > 0 but tiny, T_cap is tiny and n_A(cap) is huge: delay, not impossibility.

## KILL LINES (fixed before any run)
K-A: law A. For every case (frame, z, sin2phi, eps) and every target m in {cap, cap-1} with m >= 3 and sigma_m > 0 and measured first-reach n_meas(m) <= NMAX:
     require 1 <= n_A(m)/n_meas(m) <= 2.  (The lower side n_A >= n_meas is a theorem; violation = instrument/proof bug.)
     Law A is KILLED if ANY case in the 144 original cases OR the 120 fresh cases (z=2.5,3.5,4.5,5.2,5.7 x same 3 sin2phi x 4 eps x own+lab) has ratio > 2.
     I record the failing count; a law "passes" only with 0 failures in both sets.
K-B: law B, same ratio window but two-sided: 0.5 <= n_B(m)/n_meas(m) <= 2 in every case of both sets.
K-0 (opposite class): in every case with sigma_cap/d < 1e-9 own frame: N(n) <= cap-1 for all n up to NMAX; and N reaches cap-1.
     Killed if any such case has N = cap at any n.
K-inst: reproduced original run: N(2000) deficit cases must be 8 own + 11 lab = 19 (instrument check; mismatch = bug).
NMAX: own 2*10^5 (exact angles from 100-bit integers of alpha, alpha from mpmath 50 digits); lab 2*10^5 with exact own azimuth mapped through S.
Frame note: lab frame = own circle pushed through S (Moebius); points then are not equally spaced; law A applies verbatim with g_n of the lab angles
(proof only uses largest gap on that circle, chord rule 2 rho^2 sin^2(D/2) >= eps with rho = rho_c).

## Next command
cd /home/claude/harness/workers/T3_cap_fill && nohup python3 t3_b_law.py BASE > b_base.log & ; python3 t3_b_law.py FRESH > b_fresh.log  (writes t3_b_BASE.jsonl / t3_b_FRESH.jsonl; then t3_c_judge.py applies K-A/K-B/K-0 exactly as written above)

## RESULT OF STEP 2 (recorded after running; the kill lines above were fixed before)
- K-A (law A, largest-gap chain bound): KILLED. Ratio n_A/n_meas > 2 in 176 of 230 base targets and 135 of 196 fresh targets; theorem side holds (n_A >= n_meas, min ratio 1.000, 0 violations). Median ratio 3.9, max 66.
- K-B (law B, mean overshoot): KILLED. 38 of 230 base and 26 of 196 fresh outside [0.5, 2] (about 85% pass); fails both directions (too late at resonances, e.g. z=5.8 own eps .1 measured n=13 = a convergent denominator; too early where a long partial quotient holds g up, e.g. z=3 2G^2 eps .02 measured 2633, B 201).
- K-0 (zero-slack class): HOLDS. 14 base + 10 fresh zero-slack cases (cap an exact integer: eps .5 at sin2phi 1, and z=3 2G^2 eps .5): N never reached cap up to n = 2e5, cap-1 reached.  Files: t3_b_BASE.jsonl, t3_b_FRESH.jsonl, t3_c_judge.out.

## STEP 3b: opposite-direction repair, law E (pre-registered here BEFORE running; own frame only)
Reason A and B miss: the true cost of a chain is not set by the largest gap (A, worst case) or the mean gap (B), but by the ARITHMETIC of d against alpha.
Constructive law D (paper): write delta = d/2pi. If a small integer j has frac(j*alpha) = delta + r with 0 <= r <= sigma_m/(2pi (m-1)),
or the same for frac(-j*alpha) (reflection), then the m points k = 1 + i*j (i = 0..m-1) are pairwise >= d apart, using n = 1 + (m-1) j passes.
Proof: consecutive chosen points differ by exactly (delta+r)*2pi >= d; m points need (m-1)(delta+r) + delta <= 1, i.e. (m-1) r <= sigma/2pi. [rigorous, sufficient]
Law E: n_E(m) = min( n_A(m), n_D(m) ),  n_D(m) = 1 + (m-1) j_min(m), j_min = smallest admissible j <= 20000.   n_meas <= n_E always (both sufficient).
KILL E: on own-frame cases only (lab frame is not a uniform rotation: untested), targets m in {cap, cap-1}, m>=3, sigma_m>0:
  need 1 <= n_E/n_meas <= 2 in EVERY case of (BASE own: 144/2 cases) + (FRESH own) + a THIRD fresh set Z3 = z in {2.2, 3.3, 4.4, 5.1, 5.6} (never looked at).
  E is killed if even one target is outside. If killed: statement = "none of A, B, E passes; rigorous envelope is n_meas <= n_E".
Next: python3 t3_d_law_e.py  (also runs Z3 through t3_b_law.py's measuring code via the Z3 key)

## INSTRUMENT BUG FOUND AND FIXED (not a kill-line change)
t3_d_law_e.py reported 12 "theorem violations" (n_E < n_meas, e.g. z=3 2G^2 eps .5 m=3: n_E=7, n_meas=8). Cause: first_true() in t3_b_law.py
started its gallop with lo=hi//2=8 without testing n<8, so every true first-reach n<=8 was reported as 8. Fixed (lo=1 start). The first-reach
numbers above in "RESULT OF STEP 2" and the E run were produced with the bug; ALL of B/FRESH/Z3 re-run with the fix and judged again with the SAME kill lines (below the "RERUN" heading).
