# SCRIPT: T3-A-FAILURES
# WHY THIS DECIDES IT: re-derives N(2000,eps) for all 144 (frame,z,sin2phi,eps) cases with the validated exact-angle orbit and checks that the
# deficit count equals the stored one (8 own + 11 lab = 19, K-inst). Then tabulates for each failure the quantities the candidate laws use:
# cap, sigma_cap/d, g_2000, T_cap = sigma_cap/(cap-1), and the continued fraction of theta/2pi.  Kill (instrument): count != 19.
import numpy as np, json
exec(open('/home/claude/harness/workers/T3_cap_fill/t3_common.py').read())
N0=2000; rows=[]; EPS=[0.5,0.1,0.02,0.005]
for z in [2,3,4,5,5.5,5.8]:
    a=anatomy(float(z)); G2=a['G']**2; cf,den=cf_expansion(z)
    for label,s2 in [('1',1.0),('2G^2',2*G2),('0.301',0.301)]:
        phi=np.arcsin(np.sqrt(min(s2,1.0)))
        t_own=own_angles(z,N0)
        t_lab,rho_l,res=lab_angles(a,phi,t_own)
        for eps in EPS:
            for frame,t,rho in (('own',t_own,np.sin(phi)),('lab',t_lab,rho_l)):
                cap=cap_formula(rho,eps); d=dmin(rho,eps); sig=TWO-cap*d if cap>1 else None
                N=maxset(t,rho,eps); g=gmax(t)
                rows.append(dict(z=z,label=label,sin2phi=float(np.sin(phi)**2),eps=eps,frame=frame,rho=float(rho),cap=cap,d=float(d),
                   slack_over_d=(None if sig is None else float(sig/d)),N2000=N,g2000=float(g),
                   T_cap=(None if cap<2 or sig is None else float(sig/(cap-1))),short=bool(N<cap-1),cf=cf[:10],den=den[:10]))
json.dump(rows,open('t3_a_failures.json','w'),indent=1)
fails=[r for r in rows if r['short']]
print('cases',len(rows),'failures (N(2000)<cap-1):',len(fails),' own',sum(r['frame']=='own' for r in fails),' lab',sum(r['frame']=='lab' for r in fails))
old=json.load(open('/home/claude/closure/loop2/check2_capacity.out'))
oo=sum(r['short_own'] for r in old); ol=sum(r['short_lab'] for r in old); print('stored: own',oo,'lab',ol)
mism=0
for r in rows:
    o=[x for x in old if x['z']==r['z'] and x['label']==r['label'] and x['eps']==r['eps']][0]
    Nold=o['N_own_at']['2000'] if r['frame']=='own' else o['N_lab_at']['2000']
    capold=o['cap_own'] if r['frame']=='own' else o['cap_lab']
    if Nold!=r['N2000'] or capold!=r['cap']: mism+=1; print('MISMATCH',r['z'],r['label'],r['eps'],r['frame'],Nold,r['N2000'],capold,r['cap'])
print('mismatches vs stored N(2000)/cap:',mism)
for r in fails:
    print(r['z'],r['label'],r['eps'],r['frame'],'cap',r['cap'],'N',r['N2000'],'slack/d %.4f'%r['slack_over_d'],'g %.3e'%r['g2000'],'T %.3e'%r['T_cap'],'g/T %.2f'%(r['g2000']/r['T_cap']))
print('--- non-failures with small slack (context):')
for r in rows:
    if not r['short'] and r['slack_over_d'] is not None and 1e-9<r['slack_over_d']<0.1 and r['cap']>2: print(r['z'],r['label'],r['eps'],r['frame'],'cap',r['cap'],'N',r['N2000'],'slack/d %.4f'%r['slack_over_d'],'g/T %.2f'%(r['g2000']/r['T_cap']))
