# SCRIPT: T3-B-LAW
# WHY THIS DECIDES IT: for each case and target m in {cap, cap-1} it measures n_meas(m) = first n with N(n,eps) >= m (exact circular greedy; N is
# non-decreasing in n because prefix sets are nested, so bisection is exact) and compares with the two pre-registered predictions:
#   n_A(m) = first n with g_n <= sigma_m/(m-1)        (theorem: n_meas <= n_A always)
#   n_B(m) = first n with (m-1)*e_n <= sigma_m, e_n = sum g^2/(2*2pi)   (typical-case heuristic)
# Kill lines are in STATE.md (K-A, K-B, K-0), written before this run.  Usage: python3 t3_b_law.py BASE|FRESH
import numpy as np, json, sys
exec(open('/home/claude/harness/workers/T3_cap_fill/t3_common.py').read())
SET=sys.argv[1]; NMAX=200000
ZS={'BASE':[2,3,4,5,5.5,5.8],'FRESH':[2.5,3.5,4.5,5.2,5.7],'Z3':[2.2,3.3,4.4,5.1,5.6]}[SET]
EPS=[0.5,0.1,0.02,0.005]
def first_true(f,nmax):
    """smallest n in [1,nmax] with f(n) True (f monotone: False..True); None if f(nmax) False."""
    if not f(nmax): return None
    hi=16; lo=1
    while hi<nmax and not f(hi): lo=hi+1; hi*=2
    hi=min(hi,nmax)
    while lo<hi:
        mid=(lo+hi)//2
        if f(mid): hi=mid
        else: lo=mid+1
    return lo
out=open('t3_b_%s.jsonl'%SET,'w')
for z in ZS:
    a=anatomy(float(z)); G2=a['G']**2
    t_own=own_angles(z,NMAX)
    for label,s2 in [('1',1.0),('2G^2',2*G2),('0.301',0.301)]:
        phi=np.arcsin(np.sqrt(min(s2,1.0)))
        t_lab,rho_l,res=lab_angles(a,phi,t_own)
        for frame,t,rho in (('own',t_own,np.sin(phi)),('lab',t_lab,rho_l)):
            gcache={}; ecache={}
            gm=lambda n: gcache.setdefault(n,gmax(t[:n]))
            es=lambda n: ecache.setdefault(n,esum(t[:n]))
            for eps in EPS:
                cap=cap_formula(rho,eps); d=dmin(rho,eps)
                rec=dict(set=SET,z=z,label=label,frame=frame,eps=eps,rho=float(rho),cap=cap,d=float(d),targets=[])
                for m in (cap,cap-1):
                    if m<3: continue
                    sig=TWO-m*d
                    tr=dict(m=m,sigma=float(sig),sigma_over_d=float(sig/d))
                    if abs(sig/d)<1e-9 and m==cap:
                        tr['zero_slack']=True
                        tr['n_meas']=first_true(lambda n: maxset(t[:n],rho,eps)>=m,NMAX)   # expected None
                        tr['n_A']=None; tr['n_B']=None
                    else:
                        tr['zero_slack']=False
                        tr['n_meas']=first_true(lambda n: maxset(t[:n],rho,eps)>=m,NMAX)
                        T=sig/(m-1)
                        tr['n_A']=first_true(lambda n: gm(n)<=T,NMAX)
                        tr['n_B']=first_true(lambda n: (m-1)*es(n)<=sig,NMAX)
                    rec['targets'].append(tr)
                out.write(json.dumps(rec)+'\n'); out.flush()
        print(SET,z,label,'done',flush=True)
