# SCRIPT: T3-C-JUDGE
# Applies the kill lines of STATE.md exactly as written: K-A ratio n_A/n_meas in [1,2]; K-B n_B/n_meas in [0.5,2]; K-0 zero-slack class.
import json, collections
rows=[]
for S in ('BASE','FRESH'): rows+= [json.loads(l) for l in open('t3_b_%s.jsonl'%S)]
res=collections.defaultdict(lambda: collections.Counter()); bad=[]
for r in rows:
    for tr in r['targets']:
        key=(r['set'],r['frame'],'cap' if tr['m']==r['cap'] else 'cap-1')
        if tr['zero_slack']:
            res[(r['set'],r['frame'],'K0')]['cases']+=1
            if tr['n_meas'] is not None: res[(r['set'],r['frame'],'K0')]['VIOL(N=cap reached)']+=1
            continue
        nm,nA,nB=tr['n_meas'],tr['n_A'],tr['n_B']
        c=res[key]; c['targets']+=1
        if nm is None:
            c['censored_meas']+=1
            if nA is not None: c['THEOREM_VIOL(A fires, meas not)']+=1; bad.append((r,tr,'thm'))
            continue
        if nA is None: c['A_censored']+=1
        else:
            q=nA/nm
            if q<1: c['THEOREM_VIOL(nA<nmeas)']+=1; bad.append((r,tr,'thm'))
            if q>2: c['A_fail(ratio>2)']+=1; bad.append((r,tr,'A'))
            else: c['A_pass']+=1
        if nB is None: c['B_censored']+=1
        else:
            q=nB/nm
            if q<0.5 or q>2: c['B_fail']+=1; bad.append((r,tr,'B'))
            else: c['B_pass']+=1
for k in sorted(res): print(k,dict(res[k]))
tot=collections.Counter()
for (s,f,w),c in res.items():
    for kk,v in c.items(): tot[(s,kk)]+=v
print('TOTALS',dict(tot))
json.dump(bad,open('t3_c_bad.json','w'),indent=0)
import statistics
for law in ('n_A','n_B'):
    qs=[tr[law]/tr['n_meas'] for r in rows for tr in r['targets'] if not tr['zero_slack'] and tr['n_meas'] and tr[law]]
    qs.sort(); print(law,'ratio to measured: n=%d min %.3f median %.3f p90 %.3f max %.3f'%(len(qs),qs[0],statistics.median(qs),qs[int(.9*len(qs))],qs[-1]))
