# SCRIPT: T3-COMMON
# Shared helpers: exact own-frame angles (100-bit integers of theta/2pi from mpmath 50 digits), lab frame by pushing the
# exact own Bloch points through S, exact circular greedy (copied logic from loop2/check2_capacity.py), gap functions.
import numpy as np, mpmath as mp
mp.mp.dps = 50
src = open('/home/claude/mixer_v2/feed_loop_02.py').read().split('out={}; k1=k2=k4=0')[0]
exec(src)          # read-only: defines anatomy, bloch, SIG, I2 ...
TWO = 2*np.pi
SC = 1 << 110
def theta_mp(z):
    z = mp.mpf(z); s2 = (z-1)**2/(4*z); return 2*mp.acos(1-2*s2**2)
def alpha_int(z):
    return int(mp.floor(theta_mp(z)/(2*mp.pi)*SC))
def own_angles(z, n, k0=1):
    A = alpha_int(z); ks = range(k0, k0+n)
    fr = np.array([((k*A) % SC) / SC for k in ks], dtype=float)   # exact to 2^-110 then float
    return TWO*fr
def cap_formula(rho, eps):
    s = np.sqrt(eps/2)/rho
    if s > 1+1e-15: return 1
    s = min(s, 1.0); return int(np.floor(np.pi/np.arcsin(s)+1e-9))
def dmin(rho, eps):
    s = np.sqrt(eps/2)/rho
    return 2*np.arcsin(min(s, 1.0))
def maxset(t, rho, eps):
    s = np.sqrt(eps/2)/rho
    if s > 1+1e-15: return 1
    s = min(s, 1.0); dm = 2*np.arcsin(s)
    t = np.sort(np.mod(t, TWO)); n = len(t); p2 = np.concatenate([t, t+TWO]); tol = 1e-12
    nxt = np.searchsorted(p2, p2+dm-tol, side='left')
    idx = np.arange(n); cnt = np.ones(n, int); alive = np.ones(n, bool); lim = p2[:n]+TWO-dm+tol
    cur = idx.copy()
    for _ in range(n):
        nj = nxt[cur]; ok = alive & (nj < 2*n) & (p2[np.minimum(nj, 2*n-1)] <= lim)
        if not ok.any(): break
        cnt[ok] += 1; cur = np.where(ok, nj, cur); alive = ok
    return int(cnt.max())
def gaps(t):
    s = np.sort(np.mod(t, TWO)); return np.diff(np.concatenate([s, [s[0]+TWO]]))
def gmax(t): return gaps(t).max()
def esum(t):   # mean overshoot e_n = sum g^2 / (2*2pi)
    g = gaps(t); return float((g**2).sum()/(2*TWO))
def fit_circle(P):
    A = np.hstack([P, -np.ones((len(P), 1))]); u, s, vh = np.linalg.svd(A, full_matrices=False); x = vh[-1]
    nrm = np.linalg.norm(x[:3]); n = x[:3]/nrm; h = x[3]/nrm
    if h < 0: n, h = -n, -h
    res = np.max(abs(P@n-h)); rho = np.sqrt(max(1-h*h, 0)); c = h*n
    e1 = P[0]-c; e1 -= np.dot(e1, n)*n; e1 /= np.linalg.norm(e1); e2 = np.cross(n, e1)
    return n, h, rho, e1, e2, c, res
def own_bloch(a, phi, t):
    ax = a['axis']; d = a['d']; e1 = d-np.dot(d, ax)*ax; e1 /= np.linalg.norm(e1); e2 = np.cross(ax, e1)
    return (np.cos(phi)*ax[None, :] + np.sin(phi)*(np.cos(t)[:, None]*e1[None, :] + np.sin(t)[:, None]*e2[None, :])), ax, e1, e2
def lab_points(a, V):
    be = np.arccos(np.clip(V[:, 2], -1, 1)); ga = np.arctan2(V[:, 1], V[:, 0])
    psi = np.stack([np.cos(be/2), np.sin(be/2)*np.exp(1j*ga)], axis=1)
    out = psi @ a['S'].T
    out = out/np.linalg.norm(out, axis=1)[:, None]
    aa, bb = out[:, 0], out[:, 1]; z = np.conj(aa)*bb
    return np.stack([2*z.real, 2*z.imag, abs(aa)**2-abs(bb)**2], axis=1)
def lab_angles(a, phi, tgen, nfit=3000):
    """tgen: own azimuths (n,). returns t_lab angles on the fitted circle, rho_c"""
    V, ax, e1, e2 = own_bloch(a, phi, tgen); L = lab_points(a, V)
    n_, h, rho, E1, E2, c, res = fit_circle(L[:nfit])
    t = np.arctan2((L-c)@E2, (L-c)@E1); return t, rho, res
def cf_expansion(z, terms=16):
    x = theta_mp(z)/(2*mp.pi); cf = []
    for _ in range(terms):
        q = int(mp.floor(x)); cf.append(q); x = 1/(x-q)
    h0, h1, k0, k1 = 1, cf[0], 0, 1; den = [1]
    for q in cf[1:]:
        h0, h1 = h1, q*h1+h0; k0, k1 = k1, q*k1+k0; den.append(k1)
    return cf, den
