# SCRIPT: T3-D-LAW-E
# Applies the pre-registered law E = min(n_A, n_D) (STATE.md, written before this run) to own-frame targets of BASE, FRESH, Z3.
# n_D(m) = 1 + (m-1)*j for the smallest j<=20000 with frac(+-j*alpha) - delta in [0, sigma_m/(2pi(m-1))].
# KILL: any target with n_E/n_meas outside [1,2]; ratio <1 = bug in proof/instrument.
import json, collections, numpy as np
exec(open('/home/claude/harness/workers/T3_cap_fill/t3_common.py').read())
J=20000; cache={}
def fr(z):
    if z not in cache:
        A=alpha_int(z); f=np.array([((j*A)%SC)/SC for j in range(1,J+1)]); cache[z]=f
    return cache[z]
def nD(z,m,d,sig):
    f=fr(z); delta=d/TWO; rmax=sig/(TWO*(m-1)); js=np.arange(1,J+1)
    ok=((f-delta>=-1e-15)&(f-delta<=rmax))|(((1-f)-delta>=-1e-15)&((1-f)-delta<=rmax))
    w=np.nonzero(ok)[0]
    return None if len(w)==0 else 1+(m-1)*int(js[w[0]])
rows=[]; 
for S in ('BASE','FRESH','Z3'):
    rows+=[json.loads(l) for l in open('t3_b_%s.jsonl'%S)]
cnt=collections.Counter(); fails=[]; ratios=[]; nD_help=collections.Counter()
for r in rows:
    if r['frame']!='own': continue
    for tr in r['targets']:
        if tr['zero_slack']: continue
        nm=tr['n_meas']; nA=tr['n_A']; nd=nD(r['z'],tr['m'],r['d'],tr['sigma'])
        cands=[x for x in (nA,nd) if x is not None]; nE=min(cands) if cands else None
        k=(r['set'],)
        cnt[(r['set'],'targets')]+=1
        if nd is not None and nA is not None and nd<nA: nD_help[r['set']]+=1
        if nm is None:
            cnt[(r['set'],'meas censored')]+=1
            if nE is not None: cnt[(r['set'],'THEOREM VIOL')]+=1; fails.append((r['z'],r['label'],r['eps'],tr['m'],nm,nE,'thm'))
            continue
        if nE is None: cnt[(r['set'],'E censored')]+=1; continue
        q=nE/nm; ratios.append(q)
        if q<1: cnt[(r['set'],'THEOREM VIOL')]+=1; fails.append((r['z'],r['label'],r['eps'],tr['m'],nm,nE,'thm'))
        elif q>2: cnt[(r['set'],'E fail')]+=1; fails.append((r['z'],r['label'],r['eps'],tr['m'],nm,nE,'E %.1f'%q))
        else: cnt[(r['set'],'E pass')]+=1
for k in sorted(cnt): print(k,cnt[k])
print('D beat A in', dict(nD_help))
ratios.sort(); print('ratio n_E/n_meas: n=%d min %.2f median %.2f p90 %.2f max %.2f'%(len(ratios),ratios[0],ratios[len(ratios)//2],ratios[int(.9*len(ratios))],ratios[-1]))
for f in fails[:40]: print(f)
json.dump(fails,open('t3_d_fails.json','w'))
