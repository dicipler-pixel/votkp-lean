# SCRIPT: T3-VALIDATE
# WHY: the new vectorised orbit (exact angles + S push) must equal the old matrix orbit from check2 (own and lab Bloch points) before anything is built on it.
# KILL: max Bloch difference over 300 passes > 1e-8 for either frame, either azimuth sign -> instrument bug.
import numpy as np
exec(open('/home/claude/harness/workers/T3_cap_fill/t3_common.py').read())
exec('def orbit(a,phi,psi0=0.0,k0=1,n=2000):'+open('/home/claude/closure/loop2/check2_capacity.py').read().split('def orbit(a,phi,psi0=0.0,k0=1,n=2000):')[1].split('def fit_circle')[0])
for z in [2,5,5.8]:
    a=anatomy(float(z))
    for s2 in [1.0,0.301]:
        phi=np.arcsin(np.sqrt(s2)); own,lab,ax,e1,e2=orbit(a,phi,0.0,1,300)
        for sg in (1,-1):
            t=sg*own_angles(z,300)
            V,_,_,_=own_bloch(a,phi,t); L=lab_points(a,V)
            print(z,s2,'sign',sg,'own diff',abs(V-own).max(),'lab diff',abs(L-lab).max())
