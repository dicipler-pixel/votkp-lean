# STATE T3b_cap_word  (kill lines written BEFORE any run of the law script)

## Status
- [x] 0 read RULES, BOARD, T3 REPORT/STATE, loop2 sec 2. Copied t3_common.py (no edits to T3 folder).
- [x] 0b exploration only (x_explore.py, no law tested): optimal sets at first reach use a few integer steps (e.g. z=2, eps .1: steps 26 and 1; z=5.5: 1236 and others), i.e. mixed steps, not one repeated step (why law D of T3 was too slow).
- [ ] 1 write derivation into REPORT.md (done in draft below, final in REPORT.md)
- [ ] 2 run t3b_law.py (own frame): BASE (from T3 jsonl n_meas, reused, validated post-fix), FRESH (same), Z4 = z in {2.3,3.7,4.2,5.3,5.75} (never used; n_meas measured here)

## Derivation (paper, before running)
Let alpha = theta/2pi, delta = d/2pi, m target (cap or cap-1), sigma' = 1 - m*delta >= 0.
Exact reformulation: n_first(m) = 1 + min over m-subsets K of Z, delta-separated on the circle {k alpha}, of (max K - min K)  (shift invariance).
Arcs between circularly consecutive chosen points a_i = frac(j_i alpha) >= delta, j_i = index difference, sum a_i = 1, sum j_i = 0.
NECESSARY CONDITION (new, rigorous): among m arcs summing to 1, any run of r consecutive arcs has total >= r delta, and for each r some run
has total <= r/m (average over the m cyclic runs of length r is exactly r/m). A run of r consecutive chosen points is a pair of points of the set
whose index difference j satisfies frac(j alpha) in [r delta, r/m] (j signed, |j| <= n-1).
  => N(n) >= m implies for EVERY r = 1..m-1 some |j| <= n-1 with frac(j alpha) in I_r = [r delta, r/m].
  => n_first(m) >= n_L(m) := 1 + max_{r=1..m-1} j_min(r),  j_min(r) = min{ |j| >= 1 : frac(j alpha) in I_r }.     (law F1, lower envelope)
Width of I_r = r sigma'/m: this is "an integer combination a*small + b*large in [d, 2pi/cap]" with a+b = r gaps per run.
Block ends (two gap lengths): at n = q_k the points are (i/q_k) + k e, gaps s = eta_{k-1} (count q_k - q_{k-1}) and l = eta_{k-1}+eta_k (count q_{k-1});
runs of r gaps have sums r s + t (l - s), t = number of large gaps in the run (two consecutive values per r by Sturmian balance); tiling with m runs needs
each run >= delta and total 1; N(q_k) >= m needs an integer r with r s + t(l-s) in [delta, 1/m] for the balanced t: rational r/q_k in [delta, 1/m] up to the perturbation q_k e < 1/q_{k+1}.
Upper envelope (sufficient, from T3): n_E (laws A, D). So n_L <= n_meas <= n_E.

## KILL LINE (fixed now, before running)
Own frame, targets m in {cap, cap-1}, m >= 3, sigma_m > 0 (zero-slack cap excluded: class K-0 of T3), measured n_meas <= 200000:
  F1 passes iff 0.5 <= n_L(m)/n_meas(m) <= 1.0 in EVERY target of BASE own + FRESH own + Z4 own (Z4 = z in {2.3,3.7,4.2,5.3,5.75},
  sin^2 phi in {1, 2 Gamma^2, 0.301}, eps in {.5,.1,.02,.005}).  Upper side (n_L <= n_meas) is a theorem: any violation = instrument bug.
  Failure count recorded per set.  No constants anywhere.
OPPOSITE READINGS pre-registered (run only if F1 fails, same line, same sets):
  F2: n_L2 = 1 + max over r of j_min'(r) where j_min' uses only positive-orientation arcs frac(j alpha) with j>0 and frac(-j alpha) both, but window for the m-1 arcs
      complementary: I'_r = [1 - r/m, 1 - r delta] (mirror reading; identical set of j by symmetry j -> -j, so it must reproduce F1 exactly: this is the consistency check, not a new law).
  F3 (cap-1 first-reach is also in F1's targets; the cap-only subset is reported separately).
  F4 (upper reading): n_U(m) = 1 + sum over r=1..m-1 of ... NOT pre-registered; if F1 fails the envelope [n_L, n_E] is what is reported, with the ratio n_E/n_L.
Lab frame: only if F1 passes the own-frame line.
## Next command
python3 t3b_law.py   (writes t3b_results.jsonl, t3b_law.out)

## RESULT OF STEP 2 (recorded after run; kill line above was fixed before)
F1 KILLED: 110 of 330 targets below 0.5 (BASE 44/123, FRESH 40/104, Z4 26/103). Theorem side holds: 0 violations of n_L <= n_meas, none censored.
Median n_L/n_meas 0.56, p10 0.31, min 0.035. Much tighter than A (median 3.9x) but the window-per-r condition ignores that the SAME steps must close the cycle.

## STEP 3 (opposite reading, derived on paper and pre-registered BEFORE running; own frame, same sets, same targets)
Every arc of a valid m-set lies in W = [delta, delta + sigma'] (arc >= delta and the other m-1 arcs are >= delta, total 1).  So every step j_i (index difference between
circularly consecutive chosen points) satisfies frac(j_i alpha) in W, and sum of the j_i = 0, so a valid walk needs at least one step with j>0 and one with j<0.
Let a_+ = min{ j>0 : frac(j alpha) in W }, a_- = min{ j>0 : frac(-j alpha) in W }.  The set spans at least max(a_+, a_-) + ... :
  F5 (necessary, proven): n_first >= n_5 := 1 + max(a_+, a_-).  [at least one + step >= a_+ and one - step >= a_-, partial sums of a closed walk with both
      a step >= a_+ upward and a step >= a_- downward cover a range >= max(a_+, a_-)].  Also n_first >= max(n_L, n_5).
  F6 (derived estimate): closed walk with u steps +p and v steps -q (p=a_+, q=a_-) with u p = v q has minimal span p + q - gcd(p,q); so
      n_6 := 1 + a_+ + a_- - gcd(a_+, a_-).   (no free constant; heuristic since richer walks may do better and the minimal pair may not close with u+v=m)
KILL LINES (fixed now): same targets/sets as F1.
  F5: n_5/n_meas in [0.5, 1.0] everywhere (upper side a theorem).    F5b: max(n_L, n_5)/n_meas in [0.5, 1.0].
  F6: n_6/n_meas in [0.5, 2.0] everywhere (two-sided, factor 2 as in the original brief).

## RESULT OF STEP 3 and FINISH
F5 killed 268/330, F5b = F1 (110/330), F6 killed 264/330 (never above 1.57, too small). Blocks diagnostic: first reach at block start in only 34/330.
Lab frame not run (own frame failed). REPORT.md written. Nothing running. Next exact step if continued: integer program for min-span closed walk on step set {j: frac(j alpha) in [delta, delta+sigma']}.
