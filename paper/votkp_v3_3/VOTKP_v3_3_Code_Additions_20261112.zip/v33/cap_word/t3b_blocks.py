# SCRIPT: T3B-BLOCKS
# Diagnostic (no law): where inside the three-gap block structure does the measured first-reach n fall?
# block (k,j): n = j q_k + q_{k-1} + r, 0 <= r < q_k, 1 <= j <= a_{k+1}; position r/q_k.
import json,numpy as np
exec(open('t3_common.py').read())
R=[json.loads(l) for l in open('t3b_results2.jsonl')]
cfc={}
def blocks(z):
    if z in cfc: return cfc[z]
    cf,den=cf_expansion(z,24); L=[]
    q=[0,1]  # q_{-1}=0? use den list: den[0]=1 (q_0), den[1]=a1...
    qs=den
    for k in range(1,len(qs)-1):
        for j in range(1,cf[k+1]+1):
            start=j*qs[k]+qs[k-1]
            L.append((start,start+qs[k],k,j,qs[k]))
    cfc[z]=L; return L
pos=[];isconv=0;tot=0;atstart=0
for r in R:
    n=r['n_meas']; tot+=1
    for (s,e,k,j,q) in blocks(r['z']):
        if s<=n<e: pos.append((n-s)/q); atstart+= (n==s); break
pos=np.array(pos); print('targets',tot,'located',len(pos),'at block start',atstart)
print('position within block r/q: quantiles',np.percentile(pos,[0,10,25,50,75,90,100]).round(3))
print('fraction in first 10% of block',(pos<0.1).mean().round(3),'in last 10%',(pos>0.9).mean().round(3))
