# SCRIPT: T3B-JUDGE
import json,numpy as np
R=[json.loads(l) for l in open('t3b_results.jsonl')]
for S in ['BASE','FRESH','Z4','ALL']:
    X=[r for r in R if S=='ALL' or r['set']==S]
    for tgt in ['both','cap']:
        Y=[r for r in X if tgt=='both' or r['m']==r['cap']]
        rat=np.array([ (r['n_L'] if r['n_L'] else np.nan)/r['n_meas'] for r in Y])
        none=sum(1 for r in Y if r['n_L'] is None)
        up=int((rat>1+1e-12).sum()); lo=int((rat<0.5).sum())
        print(S,tgt,'N',len(Y),'n_L none',none,'upper violations (>1)',up,'below 0.5',lo,'median',np.nanmedian(rat),'min',np.nanmin(rat),'p10',np.nanpercentile(rat,10))
bad=[r for r in R if r['n_L'] and r['n_L']/r['n_meas']>1+1e-12]
print('violations:',bad[:5])
low=sorted([r for r in R if r['n_L'] and r['n_L']/r['n_meas']<0.5],key=lambda r:r['n_L']/r['n_meas'])
for r in low[:12]: print(r)
