# SCRIPT: T3B-JUDGE2
import json,numpy as np
R=[json.loads(l) for l in open('t3b_results2.jsonl')]
print('rows',len(R),'none',sum(1 for r in R if r['n_5'] is None))
R=[r for r in R if r['n_5'] is not None]
def rep(name,f,lo,hi,sets=('BASE','FRESH','Z4','ALL'),cap_only=False):
    for S in sets:
        X=[r for r in R if (S=='ALL' or r['set']==S) and (not cap_only or r['m']==r['cap'])]
        q=np.array([f(r)/r['n_meas'] for r in X]); bad=int(((q<lo-1e-12)|(q>hi+1e-12)).sum())
        print(name,S,'cap' if cap_only else 'both','N',len(X),'outside [%g,%g]'%(lo,hi),bad,'median %.3f min %.3f max %.3f p10 %.3f p90 %.3f'%(np.median(q),q.min(),q.max(),np.percentile(q,10),np.percentile(q,90)))
rep('F5',lambda r:r['n_5'],0.5,1.0)
rep('F5b',lambda r:max(r['n_5'],r['n_L']),0.5,1.0)
rep('F6',lambda r:r['n_6'],0.5,2.0)
rep('F6',lambda r:r['n_6'],0.5,2.0,sets=('ALL',),cap_only=True)
