# SCRIPT: T3B-LAW
# WHY THIS DECIDES IT: n_L(m) = 1 + max_r j_min(r) is a proven lower bound on first-reach n (a necessary window condition on pairs).
# If it also lies within a factor 2 below the measured first-reach in every case it is the law; kill line in STATE.md (written before this run).
# BASE/FRESH n_meas are read from T3's post-fix jsonl; Z4 n_meas is measured here with the exact circular greedy.
import numpy as np, json
exec(open('t3_common.py').read())
NMAX=200000; TOL=1e-12
T3='/home/claude/harness/workers/T3_cap_fill/'
def first_true(f,nmax):
    if not f(nmax): return None
    lo,hi=1,1
    while hi<nmax and not f(hi): lo=hi+1; hi*=2
    hi=min(hi,nmax)
    while lo<hi:
        mid=(lo+hi)//2
        if f(mid): hi=mid
        else: lo=mid+1
    return lo
def n_L(fr,delta,m):
    best=0
    for r in range(1,m):
        a=r*delta-TOL; b=r/m+TOL
        ok=((fr>=a)&(fr<=b))|(((1-fr)>=a)&((1-fr)<=b))
        idx=np.nonzero(ok)[0]
        if len(idx)==0: return None
        best=max(best,int(idx[0])+1)      # j = idx+1
    return 1+best
frcache={}
def frs(z):
    if z not in frcache: frcache[z]=own_angles(z,NMAX)/TWO
    return frcache[z]
res=[]
def judge(rec,nmeas,fr,tag):
    pass
out=open('t3b_results.jsonl','w')
# BASE, FRESH: from T3 jsonl (own frame)
for SET in ['BASE','FRESH']:
    for line in open(T3+'t3_b_%s.jsonl'%SET):
        r=json.loads(line)
        if r['frame']!='own': continue
        fr=frs(r['z']); delta=r['d']/TWO
        for tg in r['targets']:
            if tg['zero_slack'] or tg['n_meas'] is None: continue
            m=tg['m']; nl=n_L(fr,delta,m)
            out.write(json.dumps(dict(set=SET,z=r['z'],label=r['label'],eps=r['eps'],cap=r['cap'],m=m,n_meas=tg['n_meas'],n_L=nl))+'\n')
out.flush()
# Z4: measure here
for z in [2.3,3.7,4.2,5.3,5.75]:
    a=anatomy(float(z)); G2=a['G']**2; t=own_angles(z,NMAX); fr=frs(z)
    for label,s2 in [('1',1.0),('2G^2',2*G2),('0.301',0.301)]:
        phi=np.arcsin(np.sqrt(min(s2,1.0))); rho=np.sin(phi)
        for eps in [0.5,0.1,0.02,0.005]:
            cap=cap_formula(rho,eps); d=dmin(rho,eps); delta=d/TWO
            for m in (cap,cap-1):
                if m<3: continue
                sig=TWO-m*d
                if abs(sig/d)<1e-9: continue
                nm=first_true(lambda n: maxset(t[:n],rho,eps)>=m,NMAX)
                if nm is None: continue
                out.write(json.dumps(dict(set='Z4',z=z,label=label,eps=eps,cap=cap,m=m,n_meas=nm,n_L=n_L(fr,delta,m)))+'\n'); out.flush()
        print('Z4',z,label,'done',flush=True)
out.close()
