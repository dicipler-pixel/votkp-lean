# SCRIPT: T3B-LAW2
# WHY THIS DECIDES IT: a_+ and a_- are the smallest forward and backward steps whose arc lies in W = [delta, delta+sigma'], where sigma' = 1 - m*delta.
# Any valid m-set has all its m arcs in W and a closed index walk (sum of steps 0), hence needs both a + and a - step. Kill lines in STATE.md (before run).
import numpy as np, json, math
exec(open('t3_common.py').read())
NMAX=200000; TOL=1e-12
frc={}
def frs(z):
    if z not in frc: frc[z]=own_angles(z,NMAX)/TWO
    return frc[z]
def first_idx(mask):
    i=np.nonzero(mask)[0]; return int(i[0])+1 if len(i) else None
out=open('t3b_results2.jsonl','w')
for line in open('t3b_results.jsonl'):
    r=json.loads(line); z=r['z']; m=r['m']
    a=anatomy(float(z)); G2=a['G']**2
    s2={'1':1.0,'2G^2':2*G2,'0.301':0.301}[r['label']]
    rho=np.sin(np.arcsin(np.sqrt(min(s2,1.0)))); d=dmin(rho,r['eps']); delta=d/TWO; sp=1-m*delta
    fr=frs(z); lo=delta-TOL; hi=delta+sp+TOL
    ap=first_idx((fr>=lo)&(fr<=hi)); am=first_idx(((1-fr)>=lo)&((1-fr)<=hi))
    if ap is None or am is None: r.update(a_p=ap,a_m=am,n_5=None,n_6=None)
    else:
        r.update(a_p=ap,a_m=am,n_5=1+max(ap,am),n_6=1+ap+am-math.gcd(ap,am))
    out.write(json.dumps(r)+'\n')
out.close()
