# SCRIPT: T3B-EXPLORE
# Exploration only (no law tested): for a few cases show the optimal set at first-reach n*: index differences between
# circularly consecutive chosen points, to see which integer steps tile the circle.
import numpy as np, sys
exec(open('t3_common.py').read())
def chosen(t,rho,eps,m):
    # return one set of m points (indices) with separation >= d, brute greedy from every start
    d=dmin(rho,eps); s=np.mod(t,TWO); order=np.argsort(s); ts=s[order]; n=len(ts)
    best=None
    for st in range(n):
        sel=[st]; cur=ts[st]
        while True:
            nxt=np.searchsorted(np.concatenate([ts,ts+TWO]),cur+d-1e-12)
            if nxt>=2*n: break
            p=ts[nxt%n]+(TWO if nxt>=n else 0)
            if p>ts[st]+TWO-d+1e-12: break
            sel.append(nxt%n); cur=p
        if len(sel)>=m: return [int(order[i])+1 for i in sel]
    return None
for z,s2,eps in [(2,1.0,0.1),(2,1.0,0.02),(3,1.0,0.02),(5.8,1.0,0.1),(5.5,1.0,0.02),(4,1.0,0.1)]:
    t=own_angles(z,6000); rho=1.0; cap=cap_formula(rho,eps)
    lo,hi=1,6000
    while lo<hi:
        mid=(lo+hi)//2
        if maxset(t[:mid],rho,eps)>=cap: hi=mid
        else: lo=mid+1
    n=lo; ch=chosen(t[:n],rho,eps,cap)
    cf,den=cf_expansion(z)
    print('z',z,'eps',eps,'cap',cap,'n*',n,'den',den[:10],'cf',cf[:9])
    if ch:
        ks=np.array(ch); print(' set',sorted(ks)[:5],'...',max(ks),'diffs(cyc order)',np.diff(ks).tolist()[:20])
