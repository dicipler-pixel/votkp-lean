# RESULTS (one block per item; kill line = frozen text in STATE.md; "NOT FIRED"/"FIRED" refers to the frozen kill line of the proposed opposite, in this setup only)

## 1. Run 02 polarizability 0/9 — RUN
Original reproduced: items/01/orig_rerun.out; regenerated CSV identical to stored CSV (K1 main: peel beats S2 in 0 of 9).
Opposite: items/01/opp_onion02_level_only.py -> items/01/opp_out.txt (SCRIPT: ONION02-OPP-01).
Numbers (main set, held-out MAE in ln alpha, S1=ln IE1 vs T1=peel shape): S1 beats T1 in 9 of 9 settings (K=3,6,10 x kNN1,kNN3,OLS); e.g. K=10 kNN1 0.285 vs 0.288, K=3 OLS 0.257 vs 0.729. Grade<=2% set also 9 of 9.
Frozen kill line (level-only does not beat peel shape in at least 7 of 9): NOT FIRED (9 of 9). Margin at K=10 kNN1 is 0.003.

## 4. H-01 echo weight 0.743 — RUN (confirmation, as the proposal says)
Original reproduced exactly (items/04/orig_rerun.out; LOMO |G| 0.977, w 0.743; run with VOTKP_ROOT=W). Opposite: items/04/opp_h01_gabs.py -> opp_out.txt (SCRIPT: H01-OPP-01).
Numbers: LOMO accuracy |G| 0.977 vs w 0.743 on 171 cases / 19 metals; per metal |G| better on 7, w better on 0, tie 12; metal-level bootstrap of (|G| - w) = +0.234, 95% [0.088, 0.404]. Reversed orientation of |G| 0.708 (below the 124/171 = 0.725 all-bump rate).
Frozen kill line: KILL NOT FIRED.

## 5. f-block cross-series 2-3/14 — RUN
Original reproduced (items/05/orig_rerun.out: 2,2,3,3 of 14). Opposite: items/05/opp_fblock_pairing.py -> opp_out.txt (SCRIPT: FBLOCK-OPP-01), pairing Ce..Lu (58-71) with Th..Lr (90-103), columns Z-57/Z-89.
Numbers (exact of 14): K=3 Ln->An 4, An->Ln 2; K=6 Ln->An 3, An->Ln 4. Within+-1: 7, 4, 4, 5 of 14.
Operationalisation (written in script before the run): fires only if all four are <= 3. Frozen kill line: KILL NOT FIRED (two of four reach 4 of 14; still far from useful, chance for 14 classes about 1/14).

## 6. Snell third filling rule — DEFERRED (not yet run)
Original run_snell.py runs (rule M: Snell set tp,fp,fn = 1,9,5 vs window rule (= the registered null "outer electrons > 6": 8 elements, 6 hits, 2 false) 6,2,0). The item text does not define "a rule from the 8-electron contained set" or what "beat" means (precision, count?). Revisit at the end; if run, the third rule and the beat criterion are written in the script header before the run.

## 2. NUM-01 0.392 vs 0.267 — RUN (interpretation stated)
Original reproduced (items/02/orig_rerun.out: n=66, L 0.282, D 0.267, N 0.392, S 0.374). Opposite: items/02/opp_num01_ratio.py -> opp_out.txt (SCRIPT: NUM01-OPP-01).
Interpretation (the item text "K=10" does not exist in NUM-01; written into the script header before the run): N2 = ln(f_res/f_neighbour), neighbour = nearest-in-energy listed line, only the 10 lowest listed lines used, elements with >=2 lines (n=65).
Numbers: held-out MAE ln alpha: L 0.284, D 0.291, N2 0.715; D - N2 = -0.424, 95% [-0.579, -0.272].
Frozen kill line: KILL FIRED (N2 does not beat D; it is worse by 0.42). Failed in this setup only; the sum-rule form S (item origin) was already tried in the original.
(The script contains one dead first assignment of `fire` that is overwritten on the next line; the printed verdict uses the second.)

## 17. T-O at K=6 tie — RUN
Original script not on disk; reproduction is a re-implementation from the TEST_LOG declaration and matches the logged number (n=18, T1 0.667 = S2 0.667). Opposite: items/17/opp_to_split.py -> opp_out.txt (SCRIPT: TO-OPP-01), random 18-element test sets from Z 1-86 non-f.
Numbers (seeds 0-4, T1 vs S2): 0.778/0.500, 0.611/0.389, 0.667/0.222, 0.778/0.500, 0.556/0.222. T1 exceeds S2 on 5 of 5. Supplementary seeds 5-204: T1>S2 in 200 of 200; mean 0.667 vs 0.347.
Operationalisation: fires if T1<=S2 on all 5 seeds. Frozen kill line: KILL NOT FIRED. (Random splits put same-group neighbours from other periods in training; that is a different question from the period-boundary split, stated here as a property of the setup, not an interpretation.)

## 15. Depth law "outer > K" — RUN
Original reproduced (c1_depth.py output: pooled 65 misses, 62 contained = 95.4%; 3 outside: Ta at K=11, Hf and Ta at K=12). Opposite: items/15/opp_depth_k1.py -> opp_out.txt (SCRIPT: DEPTH-OPP-01), rule "contained if outer > K+1".
Numbers: K=11 misses Ta (outer 5); K=12 misses Hf (4), Ta (5); contained under K+1 rule 0 of 3 (0.000). 
Frozen kill line: KILL FIRED. This is forced by arithmetic (outer <= 8 < K at K=11-12, so any outer-count threshold of the form K or K+1 contains nothing there); a rule on a different shell quantity was not run.

## 16. Run 03 radius, hardness — RUN
Original reproduced: items/16/orig_rerun.out; regenerated run03_results.csv identical to stored; static S2 beats peel T1 in 9/9 (covalent radius), 9/9 (atomic radius), 8/9 (hardness) over K x {kNN1,kNN3,OLS}.
Opposite: items/16/opp_run03_rf.py -> opp_out.txt (SCRIPT: RUN03-OPP-01): random forest (100 trees, LOO), K in 3,6,10 x max_features 1.0/0.5/sqrt. Run time 7m45s.
Numbers: RF static beats peel in 9/9 covalent radius, 9/9 atomic radius, 9/9 hardness (original counts 9, 9, 8). Example K=3 mf=1.0: covalent S2 0.069 vs T1 0.153; hardness 0.075 vs 0.144.
Operationalisation: fires if any target's RF count falls below the original. Frozen kill line: KILL NOT FIRED.

## 14. TIME-01b real time 0.99895 — RUN
Original rule reproduced inside the opposite script: Q = 0.998954 (T=50), 0.998958 (T=200); stored 0.9990 / registered miss 1.05e-3. Opposite: items/14/opp_time01b_mid.py -> opp_out.txt (SCRIPT: TIME01B-OPP-01), <dH/dk> evaluated on the half-step state.
Numbers: midpoint-rule Q = 1.000546 (T=50), 1.000556 (T=200); |Q-1| = 5.46e-4, 5.56e-4. 
Frozen kill line (off 1 by more than 1e-3): KILL NOT FIRED. Note the midpoint value is above 1 by 5.5e-4, the original below by 1.05e-3: both are quadrature-sized.

## 13. WALL-RESIDUE-01 form 2 — RUN
Original reproduced (items/13/orig_rerun.out): row CV of dZeff 3.6, 10.4, 106.2, 73.9, 96.5 % (rows 2-6); form 2 dead. Opposite: items/13/opp_wall_kinds.py -> opp_out.txt (SCRIPT: WALLRES-OPP-01); kinds fixed by group before the run (s: groups 1-2; p: groups 13-18).
Numbers (s-kind CV / p-kind CV): row2 3.3/1.3, row3 7.3/4.9, row4 8.0/22.2, row5 7.6/16.6, row6 7.7/26.0 %. s-kind is below 10% in all five rows; p-kind exceeds 10% in rows 4, 5, 6.
Frozen kill line: KILL FIRED (3 rows). Splitting the two kinds removes the 74-106% CVs (s-kind <= 8.0%) but the p-kind stays above 10% in rows 4-6.

## 12. P-01 other fit family — RUN
Original reproduced (items/12/orig_rerun.out identical to stored first 8 lines: lattice R2 1.3895, knot versions 2.37 / 3.14 sigma stat). Opposite: items/12/opp_p01_family.py -> opp_out.txt (SCRIPT: P01-OPP-01), knots-only family from KnotInfo ropelength (no links), combined error = stat+anisotropy in quadrature, written before the run.
Numbers: R2 = L(4_1)/L(3_1) = 1.2854 vs lattice 1.3895: 2.51 combined sigma (2.84 stat). R3 = L(5_1)/L(3_1) = 1.4416 vs 1.5036: 1.31 (1.45 stat). R3 = L(5_2)/L(3_1) = 1.5108: 0.15 (0.17 stat).
Frozen kill line: KILL NOT FIRED (largest 2.51 < 3). The family is my choice (the item says only "other fit family"); the family labels in the script header list R2_C as identical to R2_B and are not separate results.

## 11. G-02 glueball — RUN
Original reproduced (items/11/orig_rerun.out, first 12 lines identical to stored: S1 uncorrected 9.36%, corrected 10.40%, both KILLED). Opposite: items/11/opp_g02_ratio.py -> opp_out.txt (SCRIPT: G02-OPP-01): first/second ratio, inverted direction.
Numbers: lattice M(0++)/M(2++) = 3.405/4.894 = 0.6957; length ratio Hopf/3_1 uncorrected 0.7676 (10.32% off), BCKR-corrected 0.7846 (12.77% off).
Frozen kill line (>5%): KILL FIRED. This is the registered S1 k=2 comparison read in the other direction; the opposite adds no independent information (the inverse ratio differs by o/p - 1 instead of p/o - 1).

## 3. NUC-01 shape 0.65 vs NPNN 0.83 — RUN (level-to-radius part not run)
Original reproduced with the v29 launcher (items/03/nuc_launch.py + nuc01.py copy; orig_rerun2.out): lin SHAPE 0.651, NPNN 0.827; knn SHAPE 0.624, NPNN 0.754; KILL 1 triggered. Stored numbers were 0.649 / 0.831 (knot_v29 REPORT already notes the small differences).
Opposite: items/03/opp_nuc_holdout.py -> opp_out.txt (SCRIPT: NUC01-OPP-01). Fit on the 434 even-even nuclei, score on the 1214 AME2020 ground states with Z>=8 that are NOT even-even (odd Z and/or odd N; same features, same 0.15 FRDM2012 beta2 label).
Numbers (holdout balanced accuracy): lin SHAPE 0.661 vs NPNN 0.840; knn SHAPE 0.697 vs NPNN 0.755.
Frozen kill line: KILL FIRED (SHAPE below NPNN in both models). "Other dataset" for the level-to-radius half (1 of 2) was not run. The label is a model quantity (FRDM2012), as in the original.

## 10. RUSSELL T2,T3,T4,T7,T8,S1,S2 — RUN (T3 and T7 data only, as the kill line names)
Original reproduced: items/10/orig_rerun.out identical to stored wave_output.txt (T3 wave 61.4 vs neighbour 47.5 kJ/mol; T7 275.2 vs 193.7 K; both KILL). Opposite: items/10/opp_russell_rowmean.py -> opp_out.txt (SCRIPT: RUSSELL-OPP-01), plain same-period leave-one-out mean.
Numbers: T3 E_at n=63: wave 61.4, row mean 180.4 (ratio 0.340). T7 T_m n=60: wave 275.2, row mean 846.1 (ratio 0.325). Neighbour interpolation (the original baseline that beat the wave): 47.5 and 193.7.
Operationalisation: beats by 20% = ratio <= 0.8. Frozen kill line: KILL NOT FIRED on both. The other named tests (T2, T4, T8, S1, S2) have no row-mean opposite defined; not run.

## 9. RHYTHM T02,T04,T05,T06,T07,T09,T13,T16,T18,T19,T20 — PARTLY RUN (generic kill needs a level-vs-peel comparison; defined for T13, T16, T20 only)
Original rerun: not repeated for Block B as a whole; T16 reproduced inside the opposite script (peel K=6: 4 of 7 correct; Rf, Db, Sg, Bh right, Hs->10, Mt and Ds missing data), matching blockB_corrected_output.txt.
- T16 (new run): items/09/opp_t16_level.py -> opp_out.txt (SCRIPT: RHYTHM-T16-OPP-01). Level reading (ln IE) vs peel shape, 1-NN, three handlings written before the run. H1 (K=6, missing=miss): level 4 of 7, peel 4 of 7 (no beat). H2 (assigned only): 0.80 vs 0.80 (no beat). H3 (K=3): level 3 of 7, peel 0 of 7 (level beats). Level beats peel in 1 of 3 handlings. Generic frozen kill line: KILL FIRED for T16.
- T13 (no new run; the level line is the original comparator, blockB_corrected_output.txt): level line beats r_h on both radii (0.087 vs 0.164 metallic, 0.104 vs 0.220 covalent) -> the level reading already wins; kill NOT FIRED in the sense of the proposal.
- T20 (no new run; original output): (n, Zeff) pair beats level line on all 4 properties (resistivity 0.596 vs 0.709; molar volume 0.286 vs 0.414; metallic radius 0.062 vs 0.082; bulk modulus 0.727 vs 1.248), so the level reading wins on 0 of 4 -> KILL FIRED for T20 (pair compared with level, not with peel shape tau).
- T02, T04, T05, T06, T07, T09, T18, T19: not run; no level-vs-peel-shape comparison exists for them (medians of steps, ridge prominence, octave assignment, extrapolation to Fr/Ra, dips in IE1). The proposal's generic kill line does not apply; no other opposite was invented.

## 20. LADDER-WALL-01 per-core listing — RUN
Original reproduced (items/20/orig_rerun.out identical to stored: 5,737 steps, 8 beyond the half line, 8 of 694 closed-core openings). Opposite: items/20/opp_ladder_inside.py -> opp_out.txt (SCRIPT: LADDERWALL-OPP-01).
Numbers: beyond count vs inside count per closed core N=2,10,18,28,36,46,54,60,68,78,86: 4/97, 1/92, 1/84, 0/75, 1/71, 0/64, 1/55, 0/50, 0/42, 0/32, 0/24. Beyond exceeds inside in 0 of 11 cores. Beyond-line elements: Li, Be, B, C (N=2), Na, K, Rb, Cs.
Operationalisation: "beyond exceeds inside" per core (the item does not say per Z or per core, written in the script before the run). Frozen kill line: KILL FIRED (0 of 11 < half).

## 21. PLASMA-WALL-01 — RUN
Original reproduced (items/21/orig_rerun.out identical to stored). Opposite: items/21/opp_plasma_inv.py -> opp_out.txt (SCRIPT: PLASMAWALL-OPP-01).
Numbers (n=30): Spearman of 1/E_wall vs IE1 -0.057 (p 0.77), vs z1 +0.279 (p 0.135), vs valence sum -0.261 (p 0.164); equal to E_wall values with sign flipped, as the proposal expected.
Frozen kill line: KILL FIRED (all three |rho| < 0.5). By construction no new information beyond the sign.

## 26. COLOUR-PEEL-03 strict form — RUN
Original reproduced (items/26/orig_rerun.out identical to stored .out: Exner toward 4.97/5.21/5.59% vs away 3.36/3.25/3.33%; unit weights 0 stretches). Opposite: items/26/opp_colour_cie.py -> opp_out.txt (SCRIPT: COLOURPEEL03-OPP-01), two CIE weight sets, seeds 1-3, tolerance unchanged.
Numbers (toward% / away%): sRGB Y (0.2126,0.7152,0.0722): 0.80/0.05, 1.03/0.12, 0.95/0.10. CIE1931 RGB (1,4.5907,0.0601): 5.92/1.95, 6.41/1.98, 6.75/2.05. Total stretched of 20000: 99,132,120 and 809,863,904.
Frozen kill line: KILL NOT FIRED (toward above away in all six). The weight sets are my choice of "CIE weights" (stated in the header before the run).

## 25. ELEMENT-BALL-01 K2 shell/screening split — RUN
Original reproduced (items/25/orig_rerun.out head identical to stored; K2 whole-boost ratio 1.362, p 1.0000, n=405 blocks). Opposite: items/25/opp_ball_k2_split.py -> opp_out.txt (SCRIPT: BALL-K2-OPP-01); shell part r_sh=(n_first/n_last)^2 and screening part r/r_sh with n = highest principal quantum number of the ground configuration (rhythm/rdata.nmax), same 405 blocks, same random-block null, 5000 draws.
Numbers (median |G2-1/2|, real vs random): whole boost 0.4040 vs 0.2965 (ratio 1.362, p 1.000); shell part 0.5000 vs 0.4216 (ratio 1.186, p 1.000); screening part 0.4152 vs 0.3844 (ratio 1.080, p 1.000). The real shell-part median of exactly 0.5000 means G2 = 0 for at least half the blocks (n unchanged inside the block, so there is no shell step to compose).
Frozen kill line: KILL FIRED. Operationalisation of "shell part" (n-ratio of first and last ion in the block) is mine, stated in the script header before the run.

## 30. DIELECTRICS-01 (80% vs 90%) — RUN (38 materials, not 40)
Original reproduced with the local rii copy (the original path /home/claude/data_ri_repo is absent; closure/s23_s24/ri/db used, items/30/orig_rerun.out): 94 compounds, 33,260 points, within 10 degrees of the real axis 0.797, |G|^2<1/2 0.923.
Opposite: items/30/opp_dielectrics_new.py -> opp_out.txt (SCRIPT: DIELECTRICS-OPP-01); materials from the glass, organic, other and specs shelves (never used before); only 38 qualify under the same selection rule, so n=38, not 40.
Numbers: 6,166 points; |G|^2<1/2 0.931; within 10 degrees 0.770; within 30 degrees 0.978.
Frozen kill line read literally (below 90% within 10 degrees): KILL FIRED, i.e. the new set stays at 77% (the original 'fill' kill, > 90%, again does not fire). The wording of the proposed kill line is ambiguous about which direction counts as failure; both readings are given by the numbers above.

## 22. NEVER-TURN-01 turners share something — RUN
Original rerun (items/22/orig_rerun.out) differs from the stored rerun file only in non-numeric lines if at all (diff head printed in session; the verdict line "INSIDE the turners spread" is the same). Opposite: items/22/opp_never_fields.py -> opp_out.txt (SCRIPT: NEVERTURN-OPP-01): exhaustive single-threshold / single-value search over 117 usable KnotInfo fields on 4 never-turners (6_3, 7_5, 8_7, 8_8) vs 19 turners.
Numbers: fields with <=1 error: 0 of 117. Control (2000 random 4-of-23 relabellings): median 0 fields reach <=1 error (5th-95th pct 0-0), so a null labelling also gives 0.
Frozen kill line: KILL FIRED (no field separates with at most one error). Single-field, single-threshold only; multi-field rules not tried.

## 23. Golden family [2,1^n,2] through the clock — COULD NOT RUN
Missing: the definition of the "clock reading" for a two-bridge knot. On disk only the clock-and-shift defect statement (limit commutator values 4 sin^2(pi j/d), d=2q, UPG Prop 4.9, computed for m=1 values) and the note "the same family read through the clock dimension d = 2q: not yet tried". No script, rule or number says which j or what turn/never prediction the clock gives for 89/34, so there is nothing to compare with the turn reading at 120 digits. The turn reading itself is on disk (never_turn_05.out: 89/34 at 120 digits, 0 band points; the 233/89 line did not finish). Also never_turn_02.py's helper is loaded from /home/claude/work, which does not exist here (a copy sits in nov/steps_a/unz/VOTKP_session_outputs_20261110_v1/).

## 24. 233/89 degree-116 root finder — COULD NOT RUN
Missing: the variable in which "a root lies on the unit circle" is meant. The degree-116 object is the Riley polynomial in v at a given s = e^x (real positive roots v are what the turn test uses; no unit-circle condition exists for v). The only unit-circle statements on disk are about Alexander polynomial roots (degree 232 for 233/89), not the degree-116 one. The 200-digit run of the Riley root finder on 233/89 is recorded as unfinished in the source notes; I did not rerun it (it did not finish for the original author either, and its kill line does not apply to it).

## 27. HIDDEN-G knots, other family class — RUN
Original reproduced (items/27/orig_rerun.out TOTAL line equals stored: 48 fits, 45 counted, 4 counted with g negative real; the original's 45 already included L6a2, L7a5, L7a6, so "non-Whitehead" is only partly new there). Opposite: items/27/opp_hidden_g_links.py -> opp_out.txt (SCRIPT: HIDDENG-OPP-01): 11 further links never used (L6a1, L6a3, L6a4, L6n1, L7a1, L7a2, L7a3, L7a4, L7a7, L7n1, L7n2), both cusps, slopes (1,a), same fit and counting rule.
Numbers: 116 (family, tetrahedron) fits, 97 counted, g negative real in 10 of 97 (0.103); Re g < 0 in 44 of 97.
Operationalisation: fires if fraction < 40/45. Frozen kill line: KILL FIRED. This is the "g negative real" claim; the hidden-level pole/sign claim on the atom side (HIDDEN-G-01) is a separate result and was not touched.

## 29. BOWL-HALF-01 outer region — RUN
Original reproduced (items/29/orig_rerun.out: 2777 tetrahedra, 8 with |G|^2 >= 1/2; circle averages 0.443026 at 0.5). Opposite: items/29/opp_bowl_outer.py -> opp_out.txt (SCRIPT: BOWLHALF-OPP-01). Two readings of "shows something at 1/2" were fixed in the header before the run.
Numbers: (a) circle average: second difference at r^2=0.50 is 5.16e-5, equal to the median elsewhere (ratio 1.00): nothing. (b) error: hinge at 1/2 in OLS of log10|bowl error| on |G|^2 (762 tetrahedra with |G|^2>=0.1, 8 above 0.5): coefficient -4.25, t = -4.39 (p<0.01).
Frozen kill line: KILL NOT FIRED, through reading (b) only. Control run afterwards (items/29/opp_bowl_control.py, control_out.txt; does not change the verdict): the same hinge at 0.2, 0.3, 0.4, 0.5, 0.6 gives t = -7.33, -6.32, -5.49, -4.39, -3.69, so the hinge is significant at every position and 1/2 is not special; the (b) signal is curvature of log error, not a feature at 1/2. The not-fired verdict is therefore weak; stated as computed.

## 31. SILENT-WALLS lopsidedness 233/143 — COULD NOT RUN
Missing: (1) "a fresh 200 walls": SILENT-WALLS-03 already used every double Alexander root on the unit circle in KnotInfo with a signature function (575 of 575; stored rerun: nullity-1 touches 376, nullity-2 crossings 199). No walls beyond those exist on disk, and no source for more (larger-crossing knots with Alexander roots) is present without new computation not specified by the item. (2) No rule is written anywhere on disk that predicts the lopsidedness from "the Smith-point position of the wall"; the quantity 233/143 is not printed in the stored outputs I read. A split within the same 575 would not be a fresh set, so I did not substitute it.

## 32. TORUS-ROOTS-01 (passed): homotopy search for 8_19 and 10_124 — COULD NOT RUN
Missing: a homotopy-continuation solver for the drawing system. On disk there is only the paper's own multi-start Newton solver (vd5/drawing_torus_02.py, drawing_robust_*.py; 5,000 starts per job, 267-579 non-degenerate roots, rerun outputs in closure/s23_s24/scripts/torus_roots_01.rerun.out). Writing and validating a continuation solver for a 20-variable polynomial system is new work of unknown length, not a script on disk. Also unclear in the item: "fewer than 3 and 4 directions" versus the registration's prediction of two distinct values for 8_19 (3 components) and 10_124 (4 components); the stored rerun finds exactly those two values for each (2/3 and 11/12; 11/15 and 14/15).

## 7. CAT-01 233 of 253 — RUN (on the 21 J2/J3-blind pairs)
Original not rerun (cat01 uses ki13.pkl; its stored result is 233 of 253 unseparated by all four groups). Opposite: items/07/opp_cat_khovanov.py -> opp_out.txt (SCRIPT: CAT01-OPP-01); the 21 pairs are the 19 twelve-crossing pairs with a J4 entry in close/c4_out.json plus K11n4/K11n21 and K11a196/K11a216 (identification stated in the header); KnotInfo Khovanov data.
Numbers: total rank of reduced rational Kh equal in 21 of 21 pairs (separated 0); unreduced integral total rank equal in 21 of 21 (separated 0). Full bigraded vectors as listed (not mirror-aware) differ in 7 of 21 (K12n10/n7, n135/n416, n3/n69, n312/n397, n348/n70, n416/n90, K11a196/K11a216), which could be chirality of the listed diagrams; not resolved.
Frozen kill line (rank separates fewer than half of the 21): KILL FIRED (0 of 21).

## 8. THIN-01 P1 and P2 — RUN (12 cases, not 15)
Original reproduced (items/08/orig_rerun.out identical to stored thin01_output.txt: P1 same side of bulk 11 of 15, both kills True; 10-20 nm 6 of 6 same side). Opposite: items/08/opp_thin_omitted.py -> opp_out.txt (SCRIPT: THIN01-OPP-01): Ciesielski 35 nm (2 datasets) plus Rosenblatt 11 nm and Lemarchand 11.7 nm, 3 wavelengths each.
Numbers: same side of bulk 11 of 12 (only miss: Ciesielski-Ge at 450 nm, R_film 0.4128 vs R_inf 0.4082, R_model 0.3864; difference to bulk 0.0046). Only 12 omitted cases exist locally; the 13/15 line was scaled to 11/12 before the run. The 10-20 nm cases were already in the original descriptive row (6 of 6); the Ciesielski cases are the new ones (5 of 6).
Frozen kill line (scaled): KILL NOT FIRED. P2 (thin-film thickness ratio) was not retried.
