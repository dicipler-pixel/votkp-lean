# STATE (T4_opposites)

Started 2026-11-12. Skip: 28 (other worker), 18, 19, 33 (no data).

## FROZEN KILL LINES (verbatim from /home/claude/closure/ledger/REPORT.md section C2; copied before any run; never altered)

A. Elemental and early
1. Run 02 polarizability 0/9: opposite = level-only feature. Kill: level-only (ln IE1) does not beat the peel shape in at least 7 of 9 settings.
2. NUM-01 0.392 vs 0.267: second numerator definition. Kill: ratio-to-neighbour numerator fails to beat the denominator at K=10.
3. NUC-01 shape 0.65 vs 0.83 and level-to-radius 1 of 2: other dataset. Kill: shape does not beat NPNN on the AME2020 holdout it was not fitted on.
4. H-01 echo weight 0.743: opposite weight. Kill: abs(G) alone does not beat abs(1 - G^2) on the same held-out metals (0.977 vs 0.743 already points this way, so this is a confirmation).
5. f-block cross-series 2-3/14: other row pairing. Kill: pairing 4f with 5f by Z offset gives 3 or fewer of 14 both ways.
6. Snell rules: third filling rule. Kill: a rule from the registered 8-electron contained set fails to beat the window rule on the 6 known turns.
7. CAT-01 233 of 253: other categorified invariant. Kill: Khovanov rank at the J4-blind pairs separates fewer than half of the 21.
8. THIN-01 P1 and P2: apply the frozen rule to the omitted Ciesielski 35 nm and 10-20 nm films in a new registration. Kill: same side of bulk in fewer than 13 of 15 films.
9. RHYTHM T02, T04, T05, T06, T07, T09, T13, T16, T18, T19, T20: first retry for those that fire; for each, the opposite is "the level reading wins". Kill (generic): the level reading does not beat the peel shape on the same data in at least 2 of 3 handlings.
10. RUSSELL T2, T3, T4, T7, T8, S1, S2: opposite = no-wave baseline. Kill: wave does not beat a plain row-mean baseline by 20% on T3 and T7 data.
11. G-02 glueball killed every arm: opposite = ratio test not length test. Kill: ratio of first to second J++ state from the loop lengths differs from lattice by more than 5%.
12. P-01: other fit family. Kill: abs(R_knot - R_lat) > 3 sigma with the combined error (2.8 sigma already below the line), registered before running.
13. WALL-RESIDUE-01 form 2: re-register "two wall kinds". Kill: CV of Delta Z_eff above 10% inside either kind in two or more rows.
14. TIME-01b real time 0.99895: midpoint rule registered first. Kill: midpoint charge off 1 by more than 1e-3.
15. Depth law "outer > K": other shell rule. Kill: a contained-set rule with K+1 explains fewer than 80% of misses at K=11-12.
16. Run 03 radius, hardness: other model class. Kill: random forest static beats peel in fewer than the same 9 of 9 and 8 of 9.
17. T-O at K=6 tie: new split. Kill: T1 does not exceed S2 on 5 random seeds of the K=6 split.
18. DATA-01 E-only arm: run when data exist. Kill: median below 16/18 on the extrapolated elements.
19. T-C and T-G never run: they need the NIST fetch; no opposite exists until then.
B. 10-12 Nov
20. LADDER-WALL-01 (clause 2 fired): opposite listing. Kill: the beyond-line count at closed-core openings exceeds the count of openings that stay inside, by Z, in fewer than half of the cores (the per-core table exists but no kill was written for it).
21. PLASMA-WALL-01: 1/E_wall alone. Kill: abs(Spearman) of 1/E_wall against each of the three ladder readings below 0.5 (this is a rank flip, so expect sign only; register the three numbers).
22. NEVER-TURN-01: turners share something. Kill: no KnotInfo field separates the 19 turners from the 4 never-turners with at most one error.
23. Golden family [2,1^n,2] through the clock: Kill: the clock reading of 89/34 differs from the turn reading at 120 digits.
24. 233/89: degree-116 root finder not run. Kill: any root of the degree-116 polynomial lies on the unit circle at 1e-30.
25. ELEMENT-BALL-01 K2: split blocks into shell and screening parts (Thm 8.2). Kill: shell part median abs(G^2 - 1/2) not at most half that of random blocks, p < 0.01.
26. COLOUR-PEEL-03 strict form: other weights. Kill: stretch rate toward white not above away at the registered tolerance with CIE weights.
27. HIDDEN-G knots, other family class. Kill: g negative real in fewer than 40 of 45 on a non-Whitehead family.
28. CHAIN-WHOLE-03: 10^8 and 10^9. Kill: angle moves more than 0.1 degree between 10^7 and 10^9.
29. BOWL-HALF-01: bowl feature at 1/2 FAILED-DIVERTED; opposite = outer region. Kill: neither the circle average nor the error shows anything at 1/2 in the 8 outside tetrahedra's region.
30. DIELECTRICS-01 (80% vs 90%, not fired): more dielectrics. Kill: below 90% within 10 degrees on a new set of 40 dielectrics.
31. SILENT-WALLS lopsidedness 233/143: Kill: the lopsidedness is not predicted by the Smith-point position of the wall, on a fresh 200 walls.
32. TORUS-ROOTS-01 (passed): 8_19 and 10_124 miss 2 and 3 roots in the drawing search; Kill: a homotopy search finds fewer than 3 and 4 directions.
33. ONE-PLAQUETTE gap, SHELL-SCREEN-04 D: Fr row untested; Kill: IE2 of Fr 23.738 eV or lower by the registered measurement.
### C3. Results that passed a registered test (with margin where it is thin)
Kills that did not fire, with the registered line:
- Run 01 0.951 vs 0.508 at K=10; 35/36 variants; DATA-01 median 17/18 (kill < 16/18) and 0.918 (kill < 0.90): margin one count and 0.018.
- TF-RESID-01 s1 0.951 vs 0.951 ("at least"): passes with zero margin; s2 envelope 0.000; STEP-23-01 1.051 in [0.85, 1.20]; FIVE-EIGHTHS-01 4.302 in [3.5, 4.5].
- T-M R^2 0.906 (kill < 0.5); T-K 2.847% and T-K2 2.942% (kill > 10%); T-N window; T-I noble resets 6/6; T-S alkalis 6/6; T-L 35/36; T-O K=10 18/18.
- Smith C3 87% (kill < 85%): margin two points.
- CLOSE C2 0.6% (kill 20%); C1 62 of 65 explained (kill < 80%).
- T-P colour over Jones: 0.992 vs 0.982, margin 0.010.
- T-Q 6/12 (kill < 6): zero margin.
- RHYTHM T01 0.846, T03 7.5% (kill 10%), T08 0.813, T10, T12, T14 1.31, T15, T17.
- RUSSELL T1 5/5 and T5 (both partly seen), S3 25.9 vs 27.5 (same data).
- TIME-01a 135/135; TIME-01b Chern 1.000000; TIME-01c 1 per knot; ADM A-poly, WALL-01 0/17,360; parity 16,656/16,656; SIG-02; SIG-01 1 of 2,525 (thin: kill is "separates none").
- WALL-RESIDUE-01 form 1; F-WALL-01 was killed on its own line (outside 6 of 6); PEEL-STAGGER p and d.
- NUC magic ridges 6/6 measured (5/6 with extrapolated: margin 0 against "< 5/6").
- 10 Nov: TORUS-STAIR-01, TORUS-DIRS-03, JOIN-K-01, TORUS-ROOTS-01, SILENT-WALLS-03 575/575, WALL-NILPOTENT-04 198/198, NEVER-TURN-03 A, B, C, PHASE-LADDER-02 (p 2.7e-06), HIDDEN-G-01 62/62 and 84/84, DEFECT-WALL-01, TIME-WALL-01, DEFECT-JOIN-01 (m=1), COLOUR-PEEL-01 and -02, DIELECTRICS-01 did not fire (80% vs 90%).
- 11 Nov: ELEMENT-BALL-01 K1 101/101; ISO-CROSS-03; SHELL-SCREEN-04 C (misses 0, crossing 6.538) and D (1.11% vs 2%); CORE-OPEN-02.
- Rounds 5-6: WINDOW_WALL 0 of 58 (slack 0.000276), B128 floor 4.000000000000, three-axis, tail check, LARGE-FIELD-FLOOR violation <= 8.9e-16.
Exact or proved (hardest ground): Thm 8.2 5,714 to 4e-16, Thm 6.2 9e-13, Thm 3.1(4) 200/200, colour-3 certificate 21/21, A-polynomial 4e-16 and 1e-10 (no script on disk).

## PROGRESS (final)
All runnable items done; REPORT.md written. Run: 1,2,3,4,5,7,8,9(partly),10,11,12,13,14,15,16,17,20,21,22,25,26,27,29,30. Could not run: 6 (ambiguous, deferred), 23, 24, 31, 32. Skipped: 18, 19, 28, 33.
Counts: FIRED 13, NOT FIRED 11 (of 24 run). Resume point if more is wanted: item 6 (needs a definition of the third filling rule and of "beat"), others need new definitions or data (see RESULTS.md).
