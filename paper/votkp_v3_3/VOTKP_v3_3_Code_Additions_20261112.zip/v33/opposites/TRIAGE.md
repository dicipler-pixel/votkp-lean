# TRIAGE (no runs; written from script headers, outputs and registrations). W = /home/claude/closure/knot_v29/tree/VOTKP_v2_9_Code_Proofs_Data_20261013/work ; S = /home/claude/closure/s23_s24
Skipped by instruction: 28, 18, 19, 33. Est. = minutes to run opposite. Order = planned run order (cheapest first).

| # | item | original script | data | runnable from disk? | est min |
|---|---|---|---|---|---|
| 1 | Run 02 polarizability | W/elemental/onion_atlas_02.py (+ _results.csv) | mendeleev 1.3.0 local (IE, alpha) | yes: S1 vs T1 MAE already in CSV and rerun | 3 |
| 4 | H-01 echo weight | W/particles/h01_lorentz_separator.py | W/rii database + elemental/*.yml | yes: LOMO accuracy |G| vs w printed by original | 3 |
| 5 | f-block pairing | W/wide/fblock.py | W/elemental/element_records.json | yes: Z-offset pairing 4f<->5f | 3 |
| 6 | Snell third rule | W/snell/run_snell.py, slater_geom.py | element_records.json | yes if rule from 8-electron contained set can be coded in slater_geom; open it first | 10 |
| 2 | NUM-01 numerator | W/numer/num01_run.py | ground_lines.json | yes, but item text ("K=10") does not map onto NUM-01; stated interpretation required | 5 |
| 17 | T-O at K=6 | W/tests (T-O code inside tests; open) | element_records.json | probably yes: 5 seeds of a K=6 split | 5 |
| 15 | depth law | W/close/c1_depth.py | element_records.json | yes if rule K+1 codable | 5 |
| 16 | Run 03 random forest | W/tests/run03.py | tests/run03_results.csv, IE data | yes (sklearn present) | 8 |
| 14 | TIME-01b midpoint | W/time01/time01b.py, time01b_refine.py | self-contained (SnapPy/mpmath) | likely yes | 10 |
| 13 | WALL-RESIDUE form 2 | W/v20/scripts/wall_residue_01.py | W/rhythm/rdata.py | yes; need "two wall kinds" definition from registration | 8 |
| 12 | P-01 other fit family | W/particles/p01_p02.py | stored in script | partly: needs lattice value + sigma on disk | 8 |
| 11 | G-02 ratio test | W/v11/checks/g02_run.py, g02_primary_source.json | spectrum json on disk | yes | 5 |
| 3 | NUC-01 other holdout | W/nuc/nuc01.py | pynucastro AME2020 + bmex h5 + nucleardatapy | yes: train/test split by region | 8 |
| 10 | RUSSELL wave vs row-mean | W/russell/wave.py, wave2.py | local | yes | 10 |
| 9 | RHYTHM level-vs-peel | W/rhythm/blockA.py, blockB.py, rdata.py | local | only where a level-vs-shape comparison is definable | 15 |
| 8 | THIN-01 Ciesielski | W/v07/checks/thin01_complete.py | W/rii | open: need the 15 films list and 10-20 nm data present | 10 |
| 7 | CAT-01 Khovanov | W/cat/cat01_hom13.py | database_knotinfo (Khovanov columns) | maybe: depends on 21 pairs identifiable | 10 |
| 20 | LADDER-WALL-01 per-core | S/round4/ladder_wall_01.py | element data | yes | 5 |
| 21 | PLASMA-WALL-01 1/E_wall | S/round4/plasma_wall_01.py | local | yes | 5 |
| 25 | ELEMENT-BALL-01 K2 split | S/elements/element_ball_01.py, rows.json | local | yes if Thm 8.2 split is codable from rows | 10 |
| 26 | COLOUR-PEEL-03 CIE weights | nov colour_peel_03.py (nov/steps_b/unz) | local | open | 10 |
| 30 | DIELECTRICS-01 new set | nov/steps_a/unz/.../dielectrics_01.py | rii database | yes if 40 more dielectrics exist in rii | 10 |
| 22 | NEVER-TURN-01 shared field | S/scripts/never_turn_01.py | database_knotinfo | yes | 10 |
| 23 | golden [2,1^n,2] clock | nov chain_whole_03.py / T2 files | self-contained | open | 10 |
| 24 | 233/89 degree-116 roots | none found; write | mpmath | open, heavy polynomial | 15 |
| 27 | HIDDEN-G non-Whitehead | nov/steps_b/unz/.../signs/hidden_g_01.py | SnapPy | yes if 45 knots in another family | 15 |
| 29 | BOWL-HALF outside region | nov/steps_a/unz/.../bowl_half_01.py | SnapPy | open | 15 |
| 31 | SILENT-WALLS lopsidedness | S/scripts/silent_walls_03.py | database_knotinfo | needs "fresh 200 walls" beyond the 575; may be unavailable | 15 |
| 32 | TORUS-ROOTS homotopy | S/scripts/torus_roots_01.py | SnapPy | heavy | 20 |
| 18,19,28,33 | skipped | | | | |

Rows marked open are refined (and may be re-marked "could not run" with the exact missing item) when reached.
