# SCRIPT: ONION02-OPP-01
# Opposite of the Run 02 kill: level-only feature S1 = ln IE1 against peel shape T1, same LOO settings,
# read from the reproduced results file of onion_atlas_02.py (identical to the stored CSV).
# Why it decides: the original compared T1 with S2 (level+shape record). The opposite asks whether the plain level beats the shape alone.
# Frozen kill: level-only (ln IE1) does not beat the peel shape in at least 7 of 9 settings.
import csv
R=list(csv.DictReader(open('onion_atlas_02_results.csv')))
def mae(tag,K,feat,model):
    return [float(r['MAE']) for r in R if r['set']==tag and int(r['K'])==K and r['feat']==feat and r['model']==model][0]
for tag in ('main','grade<=2%'):
    wins=0; n=0
    for K in (3,6,10):
        for m in ('knn1','knn3','ols'):
            s1=mae(tag,K,'S1',m); t1=mae(tag,K,'T1',m); w=s1<t1; wins+=w; n+=1
            print(tag,'K',K,m,'S1',s1,'T1',t1,'S1 beats T1' if w else 'S1 does not beat T1')
    print(tag,'level-only beats peel shape in',wins,'of',n,'settings')
    if tag=='main': print('KILL FIRED' if wins<7 else 'KILL NOT FIRED','(fires if wins < 7)')
