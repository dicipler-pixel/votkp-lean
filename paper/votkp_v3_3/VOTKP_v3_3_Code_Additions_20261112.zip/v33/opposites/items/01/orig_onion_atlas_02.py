# SCRIPT: ONION-ATLAS-02
import numpy as np, csv, warnings; warnings.filterwarnings('ignore')
from mendeleev import element
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
rng=np.random.default_rng(2)
E={}
for Z in range(1,104):
    e=element(Z); ie=e.ionenergies
    E[Z]=dict(sym=e.symbol,ie=[ie[k] for k in sorted(ie)],a=e.dipole_polarizability,u=e.dipole_polarizability_unc)
def F(Zs,name,K):
    X=[]
    for Z in Zs:
        l=np.log(E[Z]['ie'][:K+1])
        X.append({'Z':[Z],'S1':[l[0]],'S2':l,'S2c':l-l.mean(),'T1':np.diff(l),'T1+S1':np.r_[np.diff(l),l[0]]}[name])
    return StandardScaler().fit_transform(np.array(X,float))
def pred(X,y,model):
    m={'knn1':KNeighborsRegressor(1),'knn3':KNeighborsRegressor(3),'ols':LinearRegression()}[model]
    return cross_val_predict(m,X,y,cv=LeaveOneOut())
def boot(a,b,n=2000):
    d=[(a[i]-b[i]).mean() for i in [rng.integers(0,len(a),len(a)) for _ in range(n)]]; return np.percentile(d,[2.5,97.5])
rows=[]; k1=[]
for tag,zmax,relu in (('main',86,None),('Z<=103',103,None),('grade<=2%',86,0.02)):
  for K in (3,6,10):
    Zs=[Z for Z in range(1,zmax+1) if len(E[Z]['ie'])>=K+1 and E[Z]['a'] and (relu is None or (E[Z]['u'] or 0)/E[Z]['a']<=relu)]
    y=np.log([E[Z]['a'] for Z in Zs]); err={}
    for name in ('Z','S1','S2','S2c','T1','T1+S1'):
      X=F(Zs,name,K)
      for model in ('knn1','knn3','ols'):
        e_=np.abs(pred(X,y,model)-y); err[(name,model)]=e_
        rows.append(dict(set=tag,K=K,n=len(Zs),feat=name,model=model,MAE=round(e_.mean(),3)))
    for model in ('knn1','knn3','ols'):
      lo,hi=boot(err[('T1',model)],err[('S2',model)]); d=(err[('T1',model)]-err[('S2',model)]).mean()
      rows.append(dict(set=tag,K=K,n=len(Zs),feat='T1-S2 (neg=peel better)',model=model,MAE=round(d,3),CI=f'{lo:.3f}..{hi:.3f}'))
      if tag in ('main','grade<=2%'): k1.append((tag,K,model,d,lo,hi))
with open('onion_atlas_02_results.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['set','K','n','feat','model','MAE','CI']); w.writeheader(); w.writerows(rows)
# print compact tables
import collections
for tag in ('main','grade<=2%','Z<=103'):
  print('\n==',tag)
  for K in (3,6,10):
    sub=[r for r in rows if r['set']==tag and r['K']==K]; n=sub[0]['n']
    line=' | '.join(f"{r['feat']}:{r['MAE']}" for r in sub if r['model']=='knn1' and '-' not in r['feat'])
    line2=' | '.join(f"{r['feat']}:{r['MAE']}" for r in sub if r['model']=='ols' and '-' not in r['feat'])
    print(f' K={K} n={n}\n   kNN1  {line}\n   OLS   {line2}')
    for r in sub:
        if '-' in r['feat']: print('   T1-S2',r['model'],r['MAE'],r['CI'])
main=[x for x in k1 if x[0]=='main']
wins=sum(d<0 for _,_,_,d,_,_ in main); sig=sum(hi<0 for *_,hi in main)
print('\nK1 main: T1 beats S2 in',wins,'of',len(main),'settings; CI excludes zero (peel better) in',sig)
g=[x for x in k1 if x[0]=='grade<=2%']; print('K3 grade: T1 beats S2 in',sum(d<0 for _,_,_,d,_,_ in g),'of',len(g),'; sig',sum(hi<0 for *_,hi in g))
# K2 noble gases
la={Z:np.log(E[Z]['a']) for Z in E}
res=[]
for Z in (2,10,18,36,54,86):
    ok=la[Z]<la[Z+1] and (Z==2 or la[Z]<la[Z-1]); res.append((E[Z]['sym'],round(float(np.exp(la[Z])),3),ok))
print('K2 noble minima:',res,' count',sum(r[2] for r in res),'/6')
