# SCRIPT: NUM01-OPP-01
# Second numerator definition. NUM-01 N = ln(f_res/dE^2). Opposite N2 = ln(f_res / f_nb): resonance strength relative to its
# nearest-in-energy neighbouring listed line (ratio-to-neighbour). "K=10" is read as: only the 10 lowest listed lines by Eup are used.
# Elements with fewer than 2 such lines are dropped; D (ln dE, the denominator) is scored on the same subset, same LOO OLS, same paired bootstrap.
# Why it decides: same footing as the original; if a neighbour-ratio numerator carried information the level lacks, N2 would beat D.
# Frozen kill: ratio-to-neighbour numerator fails to beat the denominator at K=10.
# Operationalised before run: fires if N2 MAE >= D MAE or the 95% bootstrap interval of (D - N2) includes zero.
import json, numpy as np, warnings; warnings.filterwarnings('ignore')
from mendeleev import element
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut, cross_val_predict
Hcm=219474.6313632; G=json.load(open('ground_lines.json')); rng=np.random.default_rng(5)
rows=[]
for Z in range(1,87):
    e=element(Z)
    if e.symbol not in G or e.block=='f' or not e.dipole_polarizability: continue
    L=sorted([l for l in G[e.symbol] if l['Eup']>0 and l['f']>0],key=lambda l:l['Eup'])[:10]
    if len(L)<2: continue
    res=max(L,key=lambda l:l['f']); others=[l for l in L if l is not res]
    nb=min(others,key=lambda l:abs(l['Eup']-res['Eup']))
    rows.append(dict(sym=e.symbol,alpha=e.dipole_polarizability,D=np.log(res['Eup']/Hcm),N2=np.log(res['f']/nb['f']),L=np.log(e.ionenergies[1])))
print('n elements with >=2 lines:',len(rows))
y=np.log([r['alpha'] for r in rows]); err={}
for k in ('L','D','N2'):
    X=np.array([[r[k]] for r in rows]); p=cross_val_predict(LinearRegression(),X,y,cv=LeaveOneOut()); err[k]=np.abs(p-y)
print('held-out MAE ln alpha: L %.3f  D %.3f  N2 %.3f'%tuple(err[k].mean() for k in ('L','D','N2')))
d=[(err['D'][i]-err['N2'][i]).mean() for i in [rng.integers(0,len(y),len(y)) for _ in range(2000)]]
dd=(err['D']-err['N2']).mean(); ci=np.percentile(d,[2.5,97.5])
print('D - N2 = %+.3f  95%% [%+.3f, %+.3f]  (negative: D better)'%(dd,*ci))
fire = not (err['N2'].mean()<err['D'].mean() and ci[1]<0 is False and False) 
fire = (err['N2'].mean()>=err['D'].mean()) or not (ci[0]>0)
print('KILL FIRED' if fire else 'KILL NOT FIRED','(N2 fails to beat D unless N2 MAE < D MAE and interval of D-N2 excludes zero on the positive side)')
