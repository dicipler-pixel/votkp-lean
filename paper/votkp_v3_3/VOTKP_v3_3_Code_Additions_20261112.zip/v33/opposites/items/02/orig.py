# SCRIPT: ROUND02-NUM01-RUN
# Pre-registered in PREREG_ROUND_02.md. Features L, D, N, S; LOO OLS of ln alpha; paired bootstrap.
import json, numpy as np, warnings; warnings.filterwarnings('ignore')
from mendeleev import element
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut, cross_val_predict
Hcm=219474.6313632   # cm-1 per hartree
G=json.load(open('ground_lines.json')); rng=np.random.default_rng(5)
rows=[]
for Z in range(1,87):
    e=element(Z)
    if e.symbol not in G or e.block=='f' or not e.dipole_polarizability: continue
    L=[l for l in G[e.symbol] if l['Eup']>0]
    if not L: continue
    ie1=e.ionenergies[1]; res=max(L,key=lambda l:l['f']); dE=res['Eup']/Hcm
    S=sum(l['f']/(l['Eup']/Hcm)**2 for l in L)
    rows.append(dict(Z=Z,sym=e.symbol,alpha=e.dipole_polarizability,ie1=ie1,L=np.log(ie1),D=np.log(dE),N=np.log(res['f']/dE**2),S=np.log(S),Sraw=S,nlines=len(L)))
print('elements in NUM-01 sample:',len(rows),' '.join(r['sym'] for r in rows))
def run(sub,tag):
    y=np.log([r['alpha'] for r in sub]); err={}
    for k in ('L','D','N','S'):
        X=np.array([[r[k]] for r in sub]); p=cross_val_predict(LinearRegression(),X,y,cv=LeaveOneOut()); err[k]=np.abs(p-y)
    def boot(a,b):
        d=[(err[a][i]-err[b][i]).mean() for i in [rng.integers(0,len(y),len(y)) for _ in range(2000)]]; return (err[a]-err[b]).mean(),np.percentile(d,[2.5,97.5])
    print('\n[%s] n=%d  held-out MAE in ln alpha:  L %.3f   D %.3f   N %.3f   S %.3f'%(tag,len(sub),*(err[k].mean() for k in 'LDNS')))
    for a,b in (('D','N'),('L','N'),('L','S'),('D','S'),('N','S')):
        d,ci=boot(a,b); print('   %s - %s = %+.3f  95%% [%+.3f, %+.3f]%s'%(a,b,d,ci[0],ci[1],'  (positive: second is better)' if (a,b)==('D','N') else ''))
    fit=np.polyfit([r['S'] for r in sub],y,1); print('   slope of ln alpha on S: %.3f (sum rule: 1 if listed lines dominate); intercept %.3f'%tuple(fit))
    ratio=np.array([r['Sraw']/r['alpha'] for r in sub]); print('   parameter-free sum f/dE^2 over alpha: median %.3f, IQR %.3f-%.3f, range %.3f-%.3f'%(np.median(ratio),*np.percentile(ratio,[25,75]),ratio.min(),ratio.max()))
    d,ci=boot('D','N'); return d,ci
d,ci=run(rows,'A1 all')
print('\nKILL (numerator thesis): N fails to beat D, or interval includes zero ->',not(d>0 and ci[0]>0))
run([r for r in rows if r['ie1']<12],'A2 IE1<12 eV')
json.dump(rows,open('num01_table.json','w'),indent=0)
