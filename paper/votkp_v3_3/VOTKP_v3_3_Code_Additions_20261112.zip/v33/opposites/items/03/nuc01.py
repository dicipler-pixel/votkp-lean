# SCRIPT: NUC-01-SHAPE-LEVEL  (pre-registered in PREREG_NUC_01.md)
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
import numpy as np, pandas as pd, os, warnings; warnings.filterwarnings('ignore')
import pynucastro.nucdata as nd, nucleardatapy
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from sklearn.metrics import balanced_accuracy_score
rng=np.random.default_rng(1)
# measured masses
F=os.path.dirname(nd.__file__)+'/AtomicMassEvaluation/nubase_4.mas20.txt'
ME={}
for line in open(F):
    if not line[:3].strip().isdigit(): continue
    A=int(line[0:3]); zc=line[4:8]
    if zc[3]!='0': continue
    Z=int(zc[:3]); s=line[18:31].strip()
    if not s or '#' in s or s.startswith('*'): continue
    ME[(Z,A-Z)]=float(s)
B=lambda Z,N: Z*7288.97061+N*8071.31806-ME[(Z,N)]
def S2n(Z,N):
    return B(Z,N)-B(Z,N-2) if (Z,N) in ME and (Z,N-2) in ME else None
MAG=[2,8,20,28,50,82,126,184]
def val(x):
    lo=max(m for m in MAG if m<=x); hi=min(m for m in MAG if m>x); return min(x-lo,hi-x)
fr=pd.read_hdf(_ROOT+'/bmex/data/2-26-25.h5','FRDM12').set_index(['Z','N'])['QDB2t']
rad=pd.read_csv(os.path.dirname(nucleardatapy.__file__)+'/data/nuclei/radch/2013-Angeli.csv',comment='#',header=None,names=['z','sym','n','a','r','ru','rp','rpu'])
RAD={(int(r.z),int(r.n)):r.r for r in rad.itertuples() if not np.isnan(r.r)}
rows=[]
for (Z,N) in ME:
    if Z<8 or Z%2 or N%2: continue
    s=[S2n(Z,M) for M in (N-2,N,N+2,N+4)]
    if any(x is None or x<=0 for x in s): continue
    if not all(k in ME for k in ((Z-2,N),(Z-2,N-2))): continue
    shape=[np.log(s[0]/s[1]),np.log(s[1]/s[2]),np.log(s[2]/s[3])]
    dv=0.25*((B(Z,N)-B(Z,N-2))-(B(Z-2,N)-B(Z-2,N-2)))
    b2=fr.get((Z,N),np.nan)
    rows.append(dict(Z=Z,N=N,A=Z+N,shape=shape,level=np.log(s[1]),npnn=val(Z)*val(N),dvpn=dv,b2=b2,r=RAD.get((Z,N),np.nan)))
df=pd.DataFrame(rows); print('even-even nuclei with full measured features:',len(df))
def X(d,name):
    if name=='SHAPE': return np.array(d['shape'].tolist())
    if name=='LEVEL': return d[['level']].values
    if name=='NPNN': return d[['npnn']].values
    if name=='DVPN': return d[['dvpn']].values
    if name=='A': return d[['A']].values.astype(float)
def cv_pred(d,name,model,y,task,shuffle=False):
    g=d['Z'].values; pred=np.zeros(len(d)); Xa=X(d,name)
    for tr,te in GroupKFold(10).split(Xa,y,g):
        ytr=y[tr].copy()
        if shuffle: ytr=rng.permutation(ytr)
        sc=StandardScaler().fit(Xa[tr])
        if task=='clf': m=LogisticRegression(max_iter=2000) if model=='lin' else KNeighborsClassifier(5)
        else: m=LinearRegression() if model=='lin' else KNeighborsRegressor(5)
        m.fit(sc.transform(Xa[tr]),ytr); pred[te]=m.predict(sc.transform(Xa[te]))
    return pred
# Part 1
d1=df.dropna(subset=['b2']).reset_index(drop=True); y=(d1['b2'].abs()>0.15).astype(int).values
print('\nPART 1 (label = FRDM2012 model beta2 > 0.15): n =',len(d1),' deformed fraction %.2f'%y.mean())
res={}
for model in ('lin','knn'):
    for name in ('SHAPE','LEVEL','NPNN','DVPN','A'):
        p=cv_pred(d1,name,model,y,'clf'); res[(model,name)]=(p==y).astype(float); print(f'  {model:3s} {name:5s} balanced acc {balanced_accuracy_score(y,p):.3f}')
    p=cv_pred(d1,'SHAPE',model,y,'clf',shuffle=True); print(f'  {model:3s} SHAPE shuffled {balanced_accuracy_score(y,p):.3f}')
def bacc_boot(a,b,yy,n=2000):
    # paired bootstrap of balanced-accuracy difference using per-sample correctness
    out=[]
    for _ in range(n):
        i=rng.integers(0,len(yy),len(yy)); yi=yy[i]
        f=lambda c: 0.5*(c[i][yi==1].mean()+c[i][yi==0].mean())
        out.append(f(a)-f(b))
    return np.percentile(out,[2.5,97.5])
beats=[]
for model in ('lin','knn'):
    for comp in ('NPNN','DVPN','LEVEL'):
        lo,hi=bacc_boot(res[(model,'SHAPE')],res[(model,comp)],y)
        dpt=0.5*(res[(model,'SHAPE')][y==1].mean()+res[(model,'SHAPE')][y==0].mean())-0.5*(res[(model,comp)][y==1].mean()+res[(model,comp)][y==0].mean())
        print(f'  {model} SHAPE - {comp}: {dpt:+.3f}  95% [{lo:+.3f},{hi:+.3f}]')
        if comp!='LEVEL': beats.append((model,comp,dpt>0,lo>0))
k1=not any(all(b[2] for b in beats if b[0]==m) for m in ('lin','knn')) or all(not b[3] for b in beats)
print('  KILL 1 triggered:',k1)
# Part 2
d2=df.dropna(subset=['r']).reset_index(drop=True); print('\nPART 2 (measured charge radii, A^(1/3) trend removed in-fold): n =',len(d2))
A3=d2['A'].values**(1/3); r=d2['r'].values; g=d2['Z'].values
mae={}
for model in ('lin','knn'):
    for name in ('SHAPE','LEVEL','NPNN','DVPN','A'):
        Xa=X(d2,name); err=np.zeros(len(d2))
        for tr,te in GroupKFold(10).split(Xa,r,g):
            a,b=np.polyfit(A3[tr],r[tr],1); res_tr=r[tr]-(a*A3[tr]+b); res_te=r[te]-(a*A3[te]+b)
            sc=StandardScaler().fit(Xa[tr]); m=LinearRegression() if model=='lin' else KNeighborsRegressor(5)
            m.fit(sc.transform(Xa[tr]),res_tr); err[te]=np.abs(m.predict(sc.transform(Xa[te]))-res_te)
        mae[(model,name)]=err; print(f'  {model:3s} {name:5s} MAE {err.mean():.4f} fm')
    print(f'  {model} baseline (predict zero residual): {np.mean(np.abs(r-np.poly1d(np.polyfit(A3,r,1))(A3))):.4f} fm (in-sample trend)')
k2=not all(mae[(m,'LEVEL')].mean()<mae[(m,'SHAPE')].mean() for m in ('lin','knn'))
print('  KILL 2 triggered:',k2)
df.to_pickle('nuc01_table.pkl')
