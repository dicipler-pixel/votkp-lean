# SCRIPT: KNOT-V29-NUC-LAUNCH
# WHY: nucleardatapy 1.0.2 inserts None into sys.path at import, which crashes sklearn/narwhals (importlib.metadata) later.
# This launcher only drops None entries from sys.path inserts, then runs nuc01.py unchanged (runpy). It changes no number.
# KILL LINE: if nuc01's printed SHAPE/NPNN/radius numbers differ from stored nuc01_output.txt, the claim 0.65 vs 0.83 is not reproduced.
import sys,runpy
class P(list):
    def insert(self,i,x):
        if x is not None: list.insert(self,i,x)
    def append(self,x):
        if x is not None: list.append(self,x)
sys.path=P(sys.path)
sys.argv=['nuc01.py']
runpy.run_path('nuc01.py',run_name='__main__')
