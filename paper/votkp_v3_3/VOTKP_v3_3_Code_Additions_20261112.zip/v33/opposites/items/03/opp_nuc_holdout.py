# SCRIPT: NUC01-OPP-01
# Other dataset for NUC-01 Part 1. Original: even-even nuclei (n=434), label |beta2_FRDM2012| > 0.15, GroupKFold(10) by Z, SHAPE vs NPNN balanced accuracy.
# Opposite: fit on all 434 even-even nuclei, score on a HOLDOUT never fitted on: AME2020 ground states with Z >= 8, same full-feature rule,
# but NOT even-even (odd Z and/or odd N). Same features (SHAPE = ln S2n ratios, NPNN), same models (lin, kNN5), same threshold 0.15, same scaler fitted on the training set.
# Why it decides: the 0.65 vs 0.83 gap was measured with cross-validation inside one family; a disjoint family tests whether it is the family.
# Frozen kill: shape does not beat NPNN on the AME2020 holdout it was not fitted on.
# Operationalised before run: fires if SHAPE balanced accuracy <= NPNN balanced accuracy in either model on the holdout (point estimate).
import sys, runpy
class P(list):
    def insert(self,i,x):
        if x is not None: list.insert(self,i,x)
    def append(self,x):
        if x is not None: list.append(self,x)
sys.path=P(sys.path)
src=open('orig.py').read().split('# Part 1')[0]
g={'__name__':'nuc_orig'}; exec(src,g)
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import balanced_accuracy_score
ME,B,S2n,val,fr,df=g['ME'],g['B'],g['S2n'],g['val'],g['fr'],g['df']
rows=[]
for (Z,N) in ME:
    if Z<8 or (Z%2==0 and N%2==0): continue
    s=[S2n(Z,M) for M in (N-2,N,N+2,N+4)]
    if any(x is None or x<=0 for x in s): continue
    b2=fr.get((Z,N),np.nan)
    if np.isnan(b2): continue
    rows.append(dict(Z=Z,N=N,shape=[np.log(s[0]/s[1]),np.log(s[1]/s[2]),np.log(s[2]/s[3])],npnn=val(Z)*val(N),b2=b2))
h=pd.DataFrame(rows); d1=df.dropna(subset=['b2']).reset_index(drop=True)
print('train even-even n =',len(d1),' holdout (not even-even) n =',len(h),' deformed fraction train %.2f holdout %.2f'%((d1['b2'].abs()>0.15).mean(),(h['b2'].abs()>0.15).mean()))
ytr=(d1['b2'].abs()>0.15).astype(int).values; yte=(h['b2'].abs()>0.15).astype(int).values
Xs={'SHAPE':(np.array(d1['shape'].tolist()),np.array(h['shape'].tolist())),'NPNN':(d1[['npnn']].values,h[['npnn']].values)}
acc={}; 
for model in ('lin','knn'):
    for name,(Xa,Xb) in Xs.items():
        sc=StandardScaler().fit(Xa); m=LogisticRegression(max_iter=2000) if model=='lin' else KNeighborsClassifier(5)
        m.fit(sc.transform(Xa),ytr); acc[(model,name)]=balanced_accuracy_score(yte,m.predict(sc.transform(Xb)))
        print(f'  {model} {name:5s} holdout balanced acc {acc[(model,name)]:.3f}')
# reproduction of the original in-family numbers is in orig_rerun2.out (nuc_launch run)
fire=any(acc[(m,'SHAPE')]<=acc[(m,'NPNN')] for m in ('lin','knn'))
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if SHAPE <= NPNN in either model)')
