# SCRIPT: H01-OPP-01
# Opposite of H-01 (weight w=|1-G^2| as separator): |G| alone as separator, same 171 cases and same leave-one-metal-out rule.
# Why it decides: both scores are scored by the identical LOMO threshold fit on the same held-out metals; a paired per-metal
# comparison and a metal-level bootstrap show whether |G| beats w beyond one split. Reversed orientation is also run (opposite direction).
# Frozen kill: abs(G) alone does not beat abs(1 - G^2) on the same held-out metals.
import os, sys
src=open('orig.py').read().split('# transfer from the 12 calibration')[0]
os.environ.setdefault('VOTKP_ROOT','')
exec(src)   # defines rows, g, w, o, metal, best_t
import numpy as np
rng=np.random.default_rng(4)
def lomo(s):
    pred=np.zeros(len(o),bool)
    for m in np.unique(metal):
        tr=metal!=m; tt,_=best_t(s[tr],o[tr]); pred[~tr]=s[~tr]>=tt
    return pred==o
cg=lomo(-g); cw=lomo(w); cr=lomo(g)   # cr = reversed orientation of |G|
print('LOMO accuracy |G|:',cg.mean().round(3),' w:',cw.mean().round(3),' |G| reversed orientation:',cr.mean().round(3))
ms=np.unique(metal)
pg=np.array([cg[metal==m].mean() for m in ms]); pw=np.array([cw[metal==m].mean() for m in ms])
print('per-metal: |G| better on',int((pg>pw).sum()),'metals, w better on',int((pw>pg).sum()),'tie',int((pg==pw).sum()),'of',len(ms))
d=[(pg[i]-pw[i]).mean() for i in [rng.integers(0,len(ms),len(ms)) for _ in range(5000)]]
print('metal-level bootstrap of mean (|G| - w) accuracy: %.3f  95%% [%.3f, %.3f]'%((pg-pw).mean(),*np.percentile(d,[2.5,97.5])))
print('KILL FIRED' if cg.mean()<=cw.mean() else 'KILL NOT FIRED','(fires if |G| LOMO accuracy <= w LOMO accuracy)')
