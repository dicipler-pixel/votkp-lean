# SCRIPT: PART-01-H01-LORENTZ-FACTOR-SEPARATOR
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
# Does the front-surface echo weight w = |1 - Gamma^2| (1/gamma^2 in the Einstein-addition reading)
# separate bump / no-bump better than |Gamma|?  Pre-registration: PREREG_PART_01.md
import numpy as np, yaml, os
B=_ROOT+'/rii/database/data/main/'
def load_db(f):
    d=yaml.safe_load(open(f))
    for blk in d['DATA']:
        if blk['type'].startswith('tabulated nk'):
            return np.array([[float(x) for x in l.split()] for l in blk['data'].strip().split('\n')])
    return None
def case(N,lam,ns):
    G=(1-N)/(1+N); r12=(N-ns)/(N+ns); ds=np.linspace(5,200,6000); p2=np.exp(4j*np.pi*N*ds*1e-3/lam)
    R=np.abs((G+r12*p2)/(1+G*r12*p2))**2; i=R.argmax()
    return G, (i<len(ds)-1 and R[i]>R[-1]+1e-6)
# the 171 generalization cases, same source rule as CLOSE-01 C3
order=['Johnson','Rakic-LD','Werner','Palm','Ordal','Weaver','Querry','Windt']
rows=[]
for m in 'Al Be Cr Co Fe Ir Mo Nb Ni Os Pd Rh Ta Ti V W Zn Mg Pb'.split():
    fs=sorted(os.listdir(B+m+'/nk')); pick=None
    cand=[o+'.yml' for o in order if o+'.yml' in fs]+[f for f in fs if f.replace('.yml','') not in order and 'DFT' not in f]
    for f in cand:
        a=load_db(B+m+'/nk/'+f)
        if a is not None and a[:,0].min()<=0.45 and a[:,0].max()>=0.65: pick=(f,a); break
    f,a=pick
    for lam in (0.45,0.55,0.65):
        N=np.interp(lam,a[:,0],a[:,1])+1j*np.interp(lam,a[:,0],a[:,2])
        for ns in (1.0,1.5,2.0):
            G,b=case(N,lam,ns); rows.append((m,lam,ns,G,b))
print('cases',len(rows),' bumps',sum(r[4] for r in rows))
g=np.array([abs(r[3]) for r in rows]); w=np.array([abs(1-r[3]**2) for r in rows]); o=np.array([r[4] for r in rows]); metal=np.array([r[0] for r in rows])
# bump when |Gamma| small  <=>  w large ; orient both as 'bump if score >= t'
S={'|Gamma|':-g,'w=|1-Gamma^2|':w}
def best_t(s,y):
    ts=np.unique(s); accs=[np.mean((s>=t)==y) for t in ts]; k=int(np.argmax(accs)); 
    # midpoint to next lower value for a clean threshold
    return ts[k], accs[k]
for name,s in S.items():
    t,acc=best_t(s,o)
    # leave-one-metal-out
    pred=np.zeros(len(o),bool)
    for m in np.unique(metal):
        tr=metal!=m; tt,_=best_t(s[tr],o[tr]); pred[~tr]=s[~tr]>=tt
    print('%-16s in-sample best %.3f   leave-one-metal-out %.3f'%(name,acc,np.mean(pred==o)))
# transfer from the 12 calibration cases (Cu Ag Au Pt on n_s=1.5, same files as CLOSE-01 C2)
exec(open(_ROOT+'/elemental/chk_optics.py').read().split('claimed=')[0])
files={'Cu':'Cu_nk_Johnson.yml','Ag':'Ag_nk_Johnson.yml','Au':'Au_JC.yml','Pt':'Pt_nk_Rakic-LD.yml'}
cal=[]
for el,f in files.items():
    a=load(_ROOT+'/elemental/'+f)
    for lam in (0.45,0.55,0.65):
        N=nk(a,lam); G,b=case(N,lam,1.5); cal.append((el,lam,G,b))
cg=np.array([abs(c[2]) for c in cal]); cw=np.array([abs(1-c[2]**2) for c in cal]); co=np.array([c[3] for c in cal])
print('calibration bumps',co.sum(),'of',len(co))
for name,cs,s in (('|Gamma|',-cg,-g),('w=|1-Gamma^2|',cw,w)):
    lo=cs[~co].max(); hi=cs[co].min()
    if hi>lo: t=(lo+hi)/2; print('%-16s calibration gap clean, threshold %.4f -> transfer accuracy on 171: %.3f'%(name,abs(t),np.mean((s>=t)==o)))
    else: print('%-16s calibration classes overlap (bump min %.4f, no-bump max %.4f)'%(name,hi,lo))
print('bump   w range %.3f-%.3f ; no-bump w range %.3f-%.3f'%(w[o].min(),w[o].max(),w[~o].min(),w[~o].max()))
print('bump |G| range %.3f-%.3f ; no-bump |G| range %.3f-%.3f'%(g[o].min(),g[o].max(),g[~o].min(),g[~o].max()))
# errors of the best w threshold
t,acc=best_t(w,o)
for r,ww,gg in zip(rows,w,g):
    if (ww>=t)!=r[4]: print('  w-error',r[0],int(r[1]*1000),r[2],'|G|=%.3f w=%.3f'%(gg,ww),'bump' if r[4] else 'no bump')
t,acc=best_t(-g,o)
for r,ww,gg in zip(rows,w,g):
    if (-gg>=t)!=r[4]: print('  |G|-error',r[0],int(r[1]*1000),r[2],'|G|=%.3f w=%.3f'%(gg,ww),'bump' if r[4] else 'no bump')
