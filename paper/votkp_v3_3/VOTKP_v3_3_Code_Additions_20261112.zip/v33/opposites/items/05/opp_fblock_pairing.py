# SCRIPT: FBLOCK-OPP-01
# Opposite of WIDE F: pair the rows the other way. Original: La..Yb (57-70) <-> Ac..No (89-102), column = Z-56 / Z-88.
# Opposite pairing (shifted by one, the f^1..f^14 reading): Ce..Lu (58-71) <-> Th..Lr (90-103), column = Z-57 / Z-89.
# Same classifier (1-NN on T1, K in 3,6, z-scored on training row), both directions. Operationalisation written before the run:
# kill fires if exact accuracy is <= 3 of 14 in BOTH directions at BOTH K; not fired if any of the four exceeds 3.
# Frozen kill: pairing 4f with 5f by Z offset gives 3 or fewer of 14 both ways.
import os, json, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
_ROOT=os.environ['VOTKP_ROOT']
D={int(k):v for k,v in json.load(open(_ROOT+'/elemental/element_records.json')).items()}
def run(Ln,An,o1,o2,tag):
    out={}
    for K in (3,6):
        f=lambda Z: np.diff(np.log(D[Z]['ie'][:K+1]))
        for name,tr,te,ot,oe in (('Ln->An',Ln,An,o1,o2),('An->Ln',An,Ln,o2,o1)):
            sc=StandardScaler().fit([f(Z) for Z in tr]); m=KNeighborsClassifier(1).fit(sc.transform([f(Z) for Z in tr]),[Z-ot for Z in tr])
            p=m.predict(sc.transform([f(Z) for Z in te])); y=np.array([Z-oe for Z in te]); ex=int((p==y).sum())
            out[(K,name)]=ex; print(f'{tag} K={K} {name}: exact {ex}/{len(te)}  within1 {int((abs(p-y)<=1).sum())}/{len(te)}')
    return out
a=run(list(range(57,71)),list(range(89,103)),56,88,'original pairing 57-70/89-102')
b=run(list(range(58,72)),list(range(90,104)),57,89,'opposite pairing 58-71/90-103')
fire=all(v<=3 for v in b.values())
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if all four exact counts <= 3 of 14)')
