# SCRIPT: WIDE-F-BLOCK  (pre-registered F)
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
import json, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
D={int(k):v for k,v in json.load(open(_ROOT+'/elemental/element_records.json')).items()}
Ln=list(range(57,71)); An=list(range(89,103))
for K in (3,6):
    f=lambda Z: np.diff(np.log(D[Z]['ie'][:K+1]))
    for name,tr,te in (('Ln->An',Ln,An),('An->Ln',An,Ln)):
        tr=[Z for Z in tr if len(D[Z]['ie'])>=K+1]; te=[Z for Z in te if len(D[Z]['ie'])>=K+1]
        col=lambda Z: Z-56 if Z<80 else Z-88
        sc=StandardScaler().fit([f(Z) for Z in tr]); m=KNeighborsClassifier(1).fit(sc.transform([f(Z) for Z in tr]),[col(Z) for Z in tr])
        p=m.predict(sc.transform([f(Z) for Z in te])); y=[col(Z) for Z in te]
        exact=np.mean(p==np.array(y)); within1=np.mean(abs(p-np.array(y))<=1)
        print(f'K={K} {name}: n_train {len(tr)} n_test {len(te)} exact {exact:.3f} ({int(exact*len(te))}/{len(te)}) within±1 {within1:.3f}  pred:',list(zip([D[Z]['sym'] for Z in te],p.tolist(),y)))
    # static comparison
    for name,tr,te in (('Ln->An',Ln,An),):
        g=lambda Z: np.log(D[Z]['ie'][:K+1])
        tr=[Z for Z in tr if len(D[Z]['ie'])>=K+1]; te=[Z for Z in te if len(D[Z]['ie'])>=K+1]
        sc=StandardScaler().fit([g(Z) for Z in tr]); m=KNeighborsClassifier(1).fit(sc.transform([g(Z) for Z in tr]),[Z-56 for Z in tr])
        p=m.predict(sc.transform([g(Z) for Z in te])); print(f'   static S2 Ln->An exact {np.mean(p==np.array([Z-88 for Z in te])):.3f}')
