# SCRIPT: CAT01-OPP-01
# Khovanov rank at the J4-blind pairs. The 21 pairs = the 21 volume-different HOMFLY-Alexander-Jones-blind pairs blind to J2 and J3 (CLOSE-C4: 19 at 12 crossings, dict keys '3' and '4' in c4_out.json, plus K11n4/K11n21 and K11a196/K11a216 at 11 crossings; J4 separates all 21).
# Invariant: Khovanov homology from KnotInfo (database_knotinfo 2026.9.1). 'Rank' = total rank (sum of ranks over all bigradings) of (i) reduced rational Kh, (ii) unreduced integral Kh (free + torsion entries counted as listed). Secondary: full bigraded vector equal as listed.
# Why it decides: CAT-01 asked whether the categorified record separates volume-different blind pairs (233 of 253 unseparated). The 21 are exactly the pairs where a coloured Jones at 4 already separates; if Khovanov rank is blind there, Kh carries less than J4.
# Frozen kill: Khovanov rank at the J4-blind pairs separates fewer than half of the 21.
# Operationalised before run: separates = total rank of reduced rational Kh differs; fires if separated count < 10.5 (i.e. <= 10 of 21).
import json, warnings; warnings.filterwarnings('ignore')
from database_knotinfo import link_list
KI={r['name']:r for r in link_list()[1:]}
d=json.load(open('c4_out.json'))
pairs=[(r[0],r[1]) for r in d if isinstance(r[4],dict) and '4' in r[4]]+[('K11n4','K11n21'),('K11a196','K11a216')]
nm=lambda k: k[0:3]+'_'+k[3:] if k[2] in 'an' and k[:2].isdigit() else k   # placeholder replaced below
def ki(k):
    k=k[1:]; i=2 if k[2] in 'an' else 3 if False else None
    n=int(k[:2]); rest=k[2:]; return '%d%s_%s'%(n,rest[0],rest[1:])
def vec(r,key):
    a=json.loads(r[key]); d={}
    for x in a: d[tuple(x[:1]+x[2:])]=d.get(tuple(x[:1]+x[2:]),0)+x[1]
    return d,sum(x[1] for x in a)
rows=[]
for a,b in pairs:
    A,B=KI[ki(a)],KI[ki(b)]
    va,ra=vec(A,'khovanov_reduced_rational_vector'); vb,rb=vec(B,'khovanov_reduced_rational_vector')
    ua,sa=vec(A,'khovanov_unreduced_integral_vector'); ub,sb=vec(B,'khovanov_unreduced_integral_vector')
    rows.append((a,b,ra,rb,sa,sb,va==vb,ua==ub))
    print('%-8s %-8s reduced rank %3d vs %3d | unreduced rank %3d vs %3d | reduced vectors equal: %s | unreduced equal: %s'%(a,b,ra,rb,sa,sb,va==vb,ua==ub))
n=len(rows); s1=sum(r[2]!=r[3] for r in rows); s2=sum(r[4]!=r[5] for r in rows); s3=sum(not r[6] for r in rows); s4=sum(not r[7] for r in rows)
print('pairs',n,'| separated by reduced total rank',s1,'| unreduced total rank',s2,'| reduced full vector',s3,'| unreduced full vector',s4)
print('KILL FIRED' if s1<n/2 else 'KILL NOT FIRED','(fires if reduced total rank separates fewer than half of',n,')')
