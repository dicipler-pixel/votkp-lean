# SCRIPT: THIN01-OPP-01
# THIN-01 frozen rule (same side of bulk: sign(R_film - R_inf) = sign(R_model - R_inf), same Airy formula, ns=1.5, JC bulk, wavelengths 450/550/650) applied to the films the P1 registration left out:
# Ciesielski 35 nm (two datasets: Ciesielski, Ciesielski-Ge; thickness 35 nm taken from the dataset names/post-hoc script) and the 10-20 nm films (Rosenblatt 11 nm, Lemarchand 11.7 nm). Klinavicius nanoparticles excluded as before.
# Only 4 films x 3 wavelengths = 12 cases exist locally, not 15. The 13-of-15 line (0.867) is scaled to the smallest integer count that meets it: 11 of 12 (0.917).
# Why it decides: P1 on the registered thick films gave 11 of 15; omitted films test the same rule on cases that were not in that count.
# Frozen kill: same side of bulk in fewer than 13 of 15 films. Fires here if same-side count < 11 of 12.
import os,sys; sys.argv=['x']
src=open('orig.py').read().split("rows=[]")[0]
exec(src)
extra={'Ciesielski.yml':35.0,'Ciesielski-Ge.yml':35.0,'Rosenblatt-11nm.yml':11.0,'Lemarchand-11.7nm.yml':11.7}
rows=[]
for f,d in extra.items():
    a=load(R0+f)
    for lam in (0.45,0.55,0.65):
        Nj=Nat(JC,lam); Rinf=abs((1-Nj)/(1+Nj))**2; Rf=R(Nat(a,lam),d,lam); Rm=R(Nj,d,lam)
        ok=np.sign(Rf-Rinf)==np.sign(Rm-Rinf); rows.append(ok)
        print('%-22s %5.1f nm %d nm: R_film %.4f R_model %.4f R_inf %.4f same side %s'%(f[:-4],d,int(lam*1000),Rf,Rm,Rinf,ok))
s=sum(rows); print('same side of bulk: %d of %d'%(s,len(rows)))
print('KILL FIRED' if s<11 else 'KILL NOT FIRED','(fires if fewer than 11 of 12)')
