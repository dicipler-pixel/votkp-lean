# SCRIPT: V07-THIN-01  the film model against measured thin-film gold constants (pre-registration PREREG_THIN_01.md)
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))  # package: work/
import numpy as np, yaml, os, re
R0=_ROOT+'/rii/database/data/main/Au/nk/'
def load(f):
    d=yaml.safe_load(open(f))
    for blk in d['DATA']:
        if blk['type'].startswith('tabulated nk'):
            return np.array([[float(v) for v in l.split()] for l in blk['data'].strip().split('\n')])
films={'Lemarchand-3.96nm.yml':3.96,'Yakubovsky-4nm.yml':4.1,'Lemarchand-4.62nm.yml':4.62,'Lemarchand-5.77nm.yml':5.77,'Yakubovsky-6nm.yml':6.1,
       'Yakubovsky-9nm.yml':9.0,'Rosenblatt-11nm.yml':11.0,'Lemarchand-11.7nm.yml':11.7,'Rosenblatt-21nm.yml':21.0,'Yakubovsky-25nm.yml':25.0,
       'Rosenblatt-44nm.yml':44.0,'Yakubovsky-53nm.yml':53.0,'Yakubovsky-117nm.yml':117.0}
JC=load(_ROOT+'/elemental/Au_JC.yml'); ns=1.5
Nat=lambda a,lam: np.interp(lam,a[:,0],a[:,1])+1j*np.interp(lam,a[:,0],a[:,2])
def R(N,d,lam):
    G=(1-N)/(1+N); x=((N-ns)/(N+ns))*np.exp(4j*np.pi*N*d*1e-3/lam); return abs((G+x)/(1+G*x))**2
rows=[]
for f,d in films.items():
    a=load(R0+f)
    for lam in (0.45,0.55,0.65):
        Nj=Nat(JC,lam); Rinf=abs((1-Nj)/(1+Nj))**2
        Rf=R(Nat(a,lam),d,lam); Rm=R(Nj,d,lam)
        rows.append((f.replace('.yml',''),d,int(lam*1000),Rf,Rm,Rinf,np.sign(Rf-Rinf)==np.sign(Rm-Rinf)))
print('%-20s %6s %4s %8s %8s %8s %6s %s'%('film','d(nm)','nm','R_film','R_model','R_inf','|dR|','same side of bulk'))
for r in rows: print('%-20s %6.2f %4d %8.4f %8.4f %8.4f %6.3f %s'%(r[0],r[1],r[2],r[3],r[4],r[5],abs(r[3]-r[4]),r[6]))
P1=[r for r in rows if r[1]>=20]; P2=[r for r in rows if r[1]<10]; Pm=[r for r in rows if 10<=r[1]<20]
m1=np.median([abs(r[3]-r[4]) for r in P1]); m2=np.median([abs(r[3]-r[4]) for r in P2]); mm=np.median([abs(r[3]-r[4]) for r in Pm])
s1=sum(r[6] for r in P1)
print('\nP1 (d>=20 nm, %d cases): same side of bulk %d of %d; median |R_film-R_model| %.4f'%(len(P1),s1,len(P1),m1))
print('P2 (d<10 nm, %d cases): median |R_film-R_model| %.4f = %.1f x P1; same side of bulk %d of %d'%(len(P2),m2,m2/m1,sum(r[6] for r in P2),len(P2)))
print('10-20 nm (%d cases): median |dR| %.4f; same side %d of %d'%(len(Pm),mm,sum(r[6] for r in Pm),len(Pm)))
print('KILL P1:',not(s1>=13 and m1<=0.02),'| KILL P2:',not(m2>2*m1))
