# SCRIPT: RHYTHM-T16-OPP-01
# Opposite for RHYTHM T16 (superheavy group assignment): the LEVEL reading (ln IE_1..ln IE_{K+1}) in place of the peel shape tau_1..tau_K, same 1-NN, same training set (Z<=86 non-f with IE1..IE7 present), same test elements Rf..Ds (104-110).
# Three handlings registered here before the run: H1 = missing (no IE data) counted as a miss, out of 7; H2 = scored on assigned elements only; H3 = shallow depth K=3 (tau_1..3 vs ln IE1..4), out of 7 with missing as a miss.
# Why it decides: T16 killed the peel shape (4 of 7); this asks whether the level reading does better on exactly the same elements and handlings.
# Frozen kill (generic, item 9): the level reading does not beat the peel shape on the same data in at least 2 of 3 handlings.
# Operationalised before the run: "beat" = strictly more correct (or higher fraction for H2). Fires if level beats peel in fewer than 2 of H1,H2,H3.
src=open('orig.py').read().split('# ---- T16')[0]
exec(src)
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
def run(feat,K):
    need=range(1,K+2)
    tr=[Z for Z in base if all(k in IE[Z] for k in range(1,K+2))]; X=np.array([feat(Z,K) for Z in tr]); sc=StandardScaler().fit(X)
    kn=KNeighborsClassifier(1).fit(sc.transform(X),[grp[Z] for Z in tr]); res=[]
    for Z in range(104,111):
        if all(k in IE[Z] for k in need): res.append((SYM[Z],grp[Z],int(kn.predict(sc.transform([feat(Z,K)]))[0])))
        else: res.append((SYM[Z],grp[Z],None))
    return res
lev=lambda Z,K: np.log([IE[Z][k] for k in range(1,K+2)])
out={}
for tag,K in (('K6',6),('K3',3)):
    for fn,f in (('peel',T1),('level',lev)):
        r=run(f,K); ok=sum(1 for x in r if x[2]==x[1]); n=sum(1 for x in r if x[2] is not None); out[(tag,fn)]=(ok,n,r)
        print(tag,fn,'correct',ok,'of 7; assigned',n,'; detail',r)
h=[]
h.append(('H1 K6 missing=miss',out[('K6','level')][0]>out[('K6','peel')][0],out[('K6','level')][0],out[('K6','peel')][0]))
fr=lambda t:out[(t,'level')][0]/max(1,out[(t,'level')][1]); fp=lambda t:out[(t,'peel')][0]/max(1,out[(t,'peel')][1])
h.append(('H2 K6 assigned only (fraction)',fr('K6')>fp('K6'),round(fr('K6'),3),round(fp('K6'),3)))
h.append(('H3 K3 missing=miss',out[('K3','level')][0]>out[('K3','peel')][0],out[('K3','level')][0],out[('K3','peel')][0]))
for x in h: print(x[0],'level',x[2],'peel',x[3],'-> level beats peel' if x[1] else '-> level does not beat peel')
w=sum(x[1] for x in h); print('level beats peel in',w,'of 3 handlings')
print('KILL FIRED' if w<2 else 'KILL NOT FIRED','(fires if level beats peel in fewer than 2 of 3)')
