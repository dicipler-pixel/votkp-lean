# SCRIPT: RHYTHM-BLOCK-B  tests T11-T20 of PREREG_RHYTHM_20.md
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
import sys, os, yaml, numpy as np; sys.path.insert(0,_ROOT+'/rhythm'); from rdata import *
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
R={}
grp={Z:prop(Z,'group_id') for Z in range(1,111)}; per={Z:prop(Z,'period') for Z in range(1,111)}; blk={Z:prop(Z,'block') for Z in range(1,111)}
base=[Z for Z in range(1,87) if blk[Z]!='f' and grp[Z]]
def T1(Z,K=3): return np.diff(np.log([IE[Z][k] for k in range(1,K+2)]))
def loo(Zs,y,feat):
    """median abs LOO error for: level line, 3-NN on features (in-fold scaling), group mean"""
    y=np.array(y); x=np.array([np.log(IE[Z][1]) for Z in Zs]); F=np.array([feat(Z) for Z in Zs]); g=np.array([grp[Z] for Z in Zs])
    el=[];es=[];eg=[]
    for i in range(len(Zs)):
        m=np.arange(len(Zs))!=i
        b=np.polyfit(x[m],y[m],1); el.append(abs(np.polyval(b,x[i])-y[i]))
        sc=StandardScaler().fit(F[m]); kn=KNeighborsRegressor(3).fit(sc.transform(F[m]),y[m]); es.append(abs(kn.predict(sc.transform(F[i:i+1]))[0]-y[i]))
        gm=y[m][g[m]==g[i]]; eg.append(abs(gm.mean()-y[i]) if len(gm) else np.nan)
    return np.median(el),np.median(es),np.nanmedian(eg),len(Zs)
def have(Zs,f): return [Z for Z in Zs if f(Z) is not None and all(k in IE[Z] for k in range(1,5))]
# ---- T11, T12
for tid,key in (('T11','Electrical resistivity'),('T12','Molar volume')):
    Zs=have(base,lambda Z: pmg(SYM[Z],key)); y=[np.log(pmg(SYM[Z],key)) for Z in Zs]
    L,S,G,n=loo(Zs,y,T1); R[tid]=S<L
    print('%s %s (n=%d): LOO median |error| in ln: level %.3f | peel shape %.3f | group mean %.3f -> %s'%(tid,key,n,L,S,G,'PASS' if R[tid] else 'KILL'))
# ---- T13
out=[]
for key in ('metallic_radius','covalent_radius_pyykko'):
    Zs=[Z for Z in base if prop(Z,key) and 1 in IE[Z]]
    y=np.log([prop(Z,key) for Z in Zs]); rh=np.log([per[Z]*np.sqrt(Ry/IE[Z][1]) for Z in Zs]); x=np.log([IE[Z][1] for Z in Zs])
    eh=[];el=[]
    for i in range(len(Zs)):
        m=np.arange(len(Zs))!=i
        c=np.mean(y[m]-rh[m]); eh.append(abs(rh[i]+c-y[i]))          # one constant: r = C * r_h
        b=np.polyfit(x[m],y[m],1); el.append(abs(np.polyval(b,x[i])-y[i]))
    out.append((key,len(Zs),np.median(eh),np.median(el)))
R['T13']=all(h<l for _,_,h,l in out)
for k,n,h,l in out: print('T13 RADIUS-HYDROGENIC %s (n=%d): LOO median |error| in ln: r_h %.3f | level line %.3f'%(k,n,h,l))
print('T13 ->','PASS' if R['T13'] else 'KILL')
# ---- T14
pts=[]
for Z in range(1,87):
    if grp[Z] in (1,2) and Z>2:
        B=pmg(SYM[Z],'Bulk modulus'); V=pmg(SYM[Z],'Molar volume')
        if B and V: pts.append((SYM[Z],np.log(grp[Z]/V),np.log(B)))
sl=np.polyfit([p[1] for p in pts],[p[2] for p in pts],1)[0]; R['T14']=1.2<=sl<=2.2
print('T14 BULK-DENSITY groups 1-2 metals (n=%d, %s): slope of ln B on ln n_v = %.2f -> %s'%(len(pts),[p[0] for p in pts],sl,'PASS' if R['T14'] else 'KILL'))
# ---- T15
RB=_ROOT+'/rii/database/data/main/'; order=['Johnson','Rakic-LD','Werner','Palm','Ordal','Weaver','Querry','Windt']
def loadnk(f):
    d=yaml.safe_load(open(f))
    for blk_ in d['DATA']:
        if blk_['type'].startswith('tabulated nk'): return np.array([[float(v) for v in l.split()] for l in blk_['data'].strip().split('\n')])
rows=[]
for Z in range(1,87):
    s=SYM[Z]
    if not (prop(Z,'block') in ('s','d','p') and grp[Z] and os.path.isdir(RB+s+'/nk')): continue
    if s in ('H','He','C','N','O','F','Ne','Si','P','S','Cl','Ar','Ge','As','Se','Br','Kr','I','Xe','Rn','B','Te','At'): continue   # metals only
    fs=sorted(os.listdir(RB+s+'/nk')); cand=[o+'.yml' for o in order if o+'.yml' in fs]+[f for f in fs if f.replace('.yml','') not in order and 'DFT' not in f]
    a=None
    for f in cand:
        a_=loadnk(RB+s+'/nk/'+f)
        if a_ is not None and a_[:,0].min()<=0.55<=a_[:,0].max(): a=a_; break
    V=pmg(s,'Molar volume'); nv=prop(Z,'nvalence')
    if a is None or not V or not nv: continue
    N=np.interp(0.55,a[:,0],a[:,1])+1j*np.interp(0.55,a[:,0],a[:,2]); rows.append((s,abs((1-N)/(1+N)),np.log(IE[Z][1]),np.log(nv/V)))
g_=np.array([r[1] for r in rows]); xa=np.array([r[2] for r in rows]); xs=np.array([r[3] for r in rows]); ea=[];es=[]
for i in range(len(rows)):
    m=np.arange(len(rows))!=i
    ea.append(abs(np.polyval(np.polyfit(xa[m],g_[m],1),xa[i])-g_[i])); es.append(abs(np.polyval(np.polyfit(xs[m],g_[m],1),xs[i])-g_[i]))
R['T15']=np.median(es)<np.median(ea)
print('T15 SURFACE-FROM-SOLID %d metals: LOO median |error| in |Gamma(550)|: atom level %.4f | solid valence density %.4f -> %s'%(len(rows),np.median(ea),np.median(es),'PASS' if R['T15'] else 'KILL'))
# ---- T16
tr=[Z for Z in base if all(k in IE[Z] for k in range(1,8))]; X=np.array([T1(Z,6) for Z in tr]); sc=StandardScaler().fit(X)
kn=KNeighborsClassifier(1).fit(sc.transform(X),[grp[Z] for Z in tr]); res=[]
for Z in range(104,111):
    if all(k in IE[Z] for k in range(1,8)): res.append((SYM[Z],grp[Z],int(kn.predict(sc.transform([T1(Z,6)]))[0])))
    else: res.append((SYM[Z],grp[Z],None))
ok=sum(1 for r in res if r[2]==r[1]); R['T16']=ok>=5
print('T16 SUPERHEAVY-GROUP (element, true group, assigned):',res,'| correct %d of 7 -> %s'%(ok,'PASS' if R['T16'] else 'KILL'))
# ---- T17
anom={'Cr','Cu','Nb','Mo','Ru','Rh','Pd','Ag','Pt','Au'}
dZ=[Z for Z in range(21,81) if blk[Z]=='d' and per[Z] in (4,5,6) and 2 in IE[Z]]
ta=[np.log(IE[Z][2]/IE[Z][1]) for Z in dZ if SYM[Z] in anom]; tn=[np.log(IE[Z][2]/IE[Z][1]) for Z in dZ if SYM[Z] not in anom]
R['T17']=np.mean(ta)>np.mean(tn)
print('T17 MADELUNG-ANOMALY mean tau_1: anomalous %.3f (n=%d) vs normal %.3f (n=%d) -> %s'%(np.mean(ta),len(ta),np.mean(tn),len(tn),'PASS' if R['T17'] else 'KILL'))
# ---- T18
Zs=list(range(1,87)); y=np.log([IE[Z][1] for Z in Zs])
qb=[0,2,10,18,36,54,86]
def feat_q(Z):
    p=max(i for i,b in enumerate(qb) if Z>b); return (p,(Z-qb[p])/(qb[p+1]-qb[p]))
L9=86/9; feat_9=lambda Z: (int((Z-1)//L9),((Z-1)%L9)/L9)
feat_8=lambda Z: (int((Z-3)//8) if Z>2 else -1,((Z-3)%8)/8 if Z>2 else (Z-1)/2)
def loo_knn(f):
    F=np.array([f(Z) for Z in Zs],float); e=[]
    for i in range(len(Zs)):
        m=np.arange(len(Zs))!=i; sc=StandardScaler().fit(F[m]); kn=KNeighborsRegressor(3).fit(sc.transform(F[m]),y[m]); e.append(abs(kn.predict(sc.transform(F[i:i+1]))[0]-y[i]))
    return np.median(e)
eq,e9,e8=loo_knn(feat_q),loo_knn(feat_9),loo_knn(feat_8); R['T18']=min(e9,e8)<=eq
print('T18 NINE-OCTAVE LOO median |error| in ln IE1: quantum periods %.3f | nine equal octaves %.3f | octaves of 8 %.3f -> %s'%(eq,e9,e8,'PASS' if R['T18'] else 'KILL'))
# ---- T19
pairs=[(7,8),(15,16),(33,34),(51,52),(83,84)]
d=[(SYM[a],SYM[b],round(IE[a][1],3),round(IE[b][1],3),IE[b][1]<IE[a][1]) for a,b in pairs]; hits=sum(x[4] for x in d); R['T19']=hits>=4
print('T19 HALF-FILL p3 vs p4 IE1:',d,'| dips %d of 5 -> %s'%(hits,'PASS' if R['T19'] else 'KILL'))
# ---- T20
keys={'ln resistivity':lambda Z: pmg(SYM[Z],'Electrical resistivity'),'ln molar volume':lambda Z: pmg(SYM[Z],'Molar volume'),
      'ln metallic radius':lambda Z: prop(Z,'metallic_radius'),'ln bulk modulus':lambda Z: pmg(SYM[Z],'Bulk modulus')}
wins=0
for lab,f in keys.items():
    Zs=[Z for Z in base if f(Z) and all(k in IE[Z] for k in range(1,5))]; y=[np.log(f(Z)) for Z in Zs]
    L,S,G,n=loo(Zs,y,lambda Z:(per[Z],per[Z]*np.sqrt(IE[Z][1]/Ry)))
    w=S<L and S<G; wins+=w
    print('T20 ONE-KEY %s (n=%d): LOO median |error|: (n, Zeff) %.3f | level %.3f | group %.3f -> %s'%(lab,n,S,L,G,'beats both' if w else 'does not beat both'))
R['T20']=wins>=3; print('T20 -> %d of 4 -> %s'%(wins,'PASS' if R['T20'] else 'KILL'))
print('\nBLOCK B:',R)
