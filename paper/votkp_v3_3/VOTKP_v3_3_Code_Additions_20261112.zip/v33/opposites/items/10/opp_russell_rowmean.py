# SCRIPT: RUSSELL-OPP-01
# No-wave baseline: plain row mean. For each element, predict the mean of the other elements in the same period (same Y, same elements, leave-one-out), using the original compare() so the sample is the same as T3 (E_at, n=63) and T7 (T_m, n=60).
# Model B (Russell-type octave+insert wave, original code) vs row mean.
# Why it decides: T3/T7 compared the wave with neighbour interpolation; a flat row mean is the baseline with no structure at all. The wave must beat it by a margin to carry shape.
# Frozen kill: wave does not beat a plain row-mean baseline by 20% on T3 and T7 data.
# Operationalised before the run: "beats by 20%" = median LOO |error| of B <= 0.8 x that of the row mean; the kill fires if this fails on either T3 (E_at) or T7 (T_m).
src=open('orig.py').read().split('R={}')[0]
exec(src)
def pred_rowmean(Z,Y,exclude):
    v=[Y[J] for J in Y if P[J]==P[Z] and J!=Z and J not in exclude]
    return np.mean(v) if v else None
fire=False
for tag,Y in (('T3 E_at (kJ/mol)',EAT),('T7 T_m (K)',TM)):
    e,n=compare(Y,{'B':lambda Z,ex,Y=Y: pred_wave(Z,Y,coordB,ex),'S':lambda Z,ex,Y=Y: pred_smooth(Z,Y,ex),'M':lambda Z,ex,Y=Y: pred_rowmean(Z,Y,ex)},list(Y))
    ok=e['B']<=0.8*e['M']; fire|=not ok
    print('%s n=%d LOO median |error|: wave B %.1f | neighbour S %.1f | row mean %.1f | B/rowmean %.3f -> %s'%(tag,n,e['B'],e['S'],e['M'],e['B']/e['M'],'beats by >=20%' if ok else 'does not beat by 20%'))
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if B > 0.8 x row mean on either)')
