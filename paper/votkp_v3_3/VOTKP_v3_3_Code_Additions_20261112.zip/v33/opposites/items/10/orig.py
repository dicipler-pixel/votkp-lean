# SCRIPT: RUSSELL-WAVE  tests T1-T8 of PREREG_RUSSELL_WAVE.md (written 2026-09-24T14:43Z, before this script)
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
import sys, os, numpy as np, collections
sys.path.insert(0,_ROOT+'/rhythm'); from rdata import *     # IE, FLAG, SYM, prop, pmg (bounds dropped)
Z_ALL=[Z for Z in range(3,87) if prop(Z,'block')!='f' and prop(Z,'group_id')]
G={Z:prop(Z,'group_id') for Z in Z_ALL}; P={Z:prop(Z,'period') for Z in Z_ALL}
NONNOBLE=[Z for Z in Z_ALL if G[Z]!=18]
EAT={Z:prop(Z,'heat_of_formation') for Z in NONNOBLE}; EAT={Z:v for Z,v in EAT.items() if v}
TM={Z:prop(Z,'melting_point') for Z in NONNOBLE}; TM={Z:v for Z,v in TM.items() if v}
f=lambda x: 4*x*(1-x)
def coordB(Z):
    g,p=G[Z],P[Z]
    if g<=2: return ('sp',p),g/8
    if g>=13: return ('sp',p),(g-10)/8
    return ('d',p),(g-2)/10
def coordR(Z):
    g,p=G[Z],P[Z]
    if p<=3: return ('R',p),(g if g<=2 else g-10)/8
    return ('R',p),g/18
def amp(members,Y,coord):
    fx=np.array([f(coord(Z)[1]) for Z in members]); y=np.array([Y[Z] for Z in members])
    if (fx>0).sum()<2: return None
    return (y*fx).sum()/(fx*fx).sum()
def pred_wave(Z,Y,coord,exclude):
    w,x=coord(Z); mem=[J for J in Y if J not in exclude and J!=Z and coord(J)[0]==w]
    A=amp(mem,Y,coord); return None if A is None else A*f(x)
def pred_smooth(Z,Y,exclude):
    mem=sorted(J for J in Y if P[J]==P[Z] and J!=Z and J not in exclude)
    lo=[J for J in mem if J<Z]; hi=[J for J in mem if J>Z]
    if lo and hi:
        a,b=lo[-1],hi[0]; return Y[a]+(Y[b]-Y[a])*(Z-a)/(b-a)
    side=lo[-2:] if lo else hi[:2]
    if len(side)==2:
        a,b=side; return Y[a]+(Y[b]-Y[a])*(Z-a)/(b-a)
    return Y[side[0]] if side else None
def compare(Y,models,Zs,exclude_fn=lambda Z:set()):
    errs={m:[] for m in models}; used=[]
    for Z in Zs:
        ps={m:fn(Z,exclude_fn(Z)) for m,fn in models.items()}
        if any(v is None for v in ps.values()): continue
        used.append(Z)
        for m,v in ps.items(): errs[m].append(abs(v-Y[Z]))
    return {m:np.median(e) for m,e in errs.items()},len(used)
R={}
# ---- T1
t1=[]
for p in range(2,7):
    Zs=[Z for Z in EAT if P[Z]==p]; top=max(Zs,key=lambda Z:EAT[Z]); g=G[top]
    ok=(13<=g<=15) if p<=3 else (3<=g<=15)
    t1.append((p,SYM[top],g,round(EAT[top],1),ok))
R['T1']=all(t[4] for t in t1)
print('T1 CREST  period, max-E_at element, group, E_at, in crest zone:',t1,'->','PASS' if R['T1'] else 'KILL')
# ---- T2
t2=[]
for p in range(2,7):
    seq=[]
    for g in (1,2,13,14):
        Z=[Z for Z in Z_ALL if P[Z]==p and G[Z]==g][0]; seq.append((SYM[Z],pmg(SYM[Z],'Molar volume')))
    ok=all(seq[i][1] is not None and seq[i+1][1] is not None and seq[i+1][1]<seq[i][1] for i in range(3))
    t2.append((p,seq,ok))
R['T2']=sum(t[2] for t in t2)>=4
for t in t2: print('T2 CONTRACTION period %d molar volumes (cm3/mol) %s -> %s'%(t[0],t[1],'decreasing' if t[2] else 'not decreasing'))
print('T2 -> %d of 5 -> %s'%(sum(t[2] for t in t2),'PASS' if R['T2'] else 'KILL'))
# ---- T3
e,n=compare(EAT,{'B':lambda Z,ex: pred_wave(Z,EAT,coordB,ex),'S':lambda Z,ex: pred_smooth(Z,EAT,ex)},list(EAT))
R['T3']=e['B']<e['S']
print('T3 WAVE-VS-SMOOTH E_at (n=%d): LOO median |error| kJ/mol: Model B %.1f | Baseline S %.1f -> %s'%(n,e['B'],e['S'],'PASS' if R['T3'] else 'KILL'))
# ---- T4
Z46=[Z for Z in EAT if P[Z]>=4]
e,n=compare(EAT,{'R':lambda Z,ex: pred_wave(Z,EAT,coordR,ex),'B':lambda Z,ex: pred_wave(Z,EAT,coordB,ex)},Z46)
R['T4']=e['R']<=e['B']
print('T4 ONE-WAVE periods 4-6 (n=%d): Model R (Russell, one wave) %.1f | Model B (octave+insert) %.1f -> %s'%(n,e['R'],e['B'],'PASS (Russell)' if R['T4'] else 'KILL (Russell)'))
# ---- T5
Asp={p:amp([Z for Z in EAT if coordB(Z)[0]==('sp',p)],EAT,coordB) for p in range(2,7)}
Ad={p:amp([Z for Z in EAT if coordB(Z)[0]==('d',p)],EAT,coordB) for p in range(4,7)}
dec=sum(Asp[p+1]<Asp[p] for p in range(2,6)); inc=all(Ad[p+1]>Ad[p] for p in (4,5))
R['T5']=dec>=3 and inc
print('T5 TWO AMPLITUDES sp octave A(p) kJ/mol:',{p:round(v,1) for p,v in Asp.items()},'decreases %d of 4 | d insert A(p):'%dec,{p:round(v,1) for p,v in Ad.items()},'rises both steps' if inc else 'does not rise both steps','->','PASS' if R['T5'] else 'KILL')
# ---- T6
grp_of=lambda Z: {J for J in EAT if G[J]==G[Z]}
e,n=compare(EAT,{'B':lambda Z,ex: pred_wave(Z,EAT,coordB,ex),'S':lambda Z,ex: pred_smooth(Z,EAT,ex)},list(EAT),exclude_fn=grp_of)
R['T6']=e['B']<e['S']
print('T6 GROUP-OUT E_at (n=%d): Model B %.1f | Baseline S %.1f -> %s'%(n,e['B'],e['S'],'PASS' if R['T6'] else 'KILL'))
# ---- T7
e,n=compare(TM,{'B':lambda Z,ex: pred_wave(Z,TM,coordB,ex),'S':lambda Z,ex: pred_smooth(Z,TM,ex)},list(TM))
R['T7']=e['B']<e['S']
print('T7 MELTING T_m (n=%d): LOO median |error| K: Model B %.1f | Baseline S %.1f -> %s'%(n,e['B'],e['S'],'PASS' if R['T7'] else 'KILL'))
# ---- T8
def ieN(n): return IE[n][1] if FLAG[n].get(1)=='M' else None
def ieL(Zg,n):
    k=Zg-n+1; return IE[Zg][k] if FLAG[Zg].get(k)=='M' else None
rows=[]
for Zg,lo in ((10,3),(18,11),(36,31),(54,49),(86,81)):
    for n in range(lo+1,Zg):
        a=[ieN(m) for m in (n-1,n,n+1)]; b=[ieL(Zg,m) for m in (n-1,n,n+1)]
        if None in a or None in b: rows.append((SYM[Zg],n,None,None,None)); continue
        d2a=np.log(a[2])-2*np.log(a[1])+np.log(a[0]); d2b=np.log(b[2])-2*np.log(b[1])+np.log(b[0])
        rows.append((SYM[Zg],n,round(d2a,3),round(d2b,3),np.sign(d2a)==np.sign(d2b)))
use=[r for r in rows if r[4] is not None]; agree=sum(r[4] for r in use)
R['T8']=len(use)>0 and agree/len(use)>=0.8
for r in rows: print('T8 %s n=%d (like %s): d2 neutral %s | d2 ladder %s | %s'%(r[0],r[1],SYM[r[1]],r[2],r[3],'no measured data' if r[4] is None else ('same sign' if r[4] else 'opposite sign')))
print('T8 MASTER-TONE RECORD: %d of %d usable second differences agree in sign (%.0f%%) -> %s'%(agree,len(use),100*agree/max(1,len(use)),'PASS' if R['T8'] else 'KILL'))
print('\nRUSSELL-WAVE:',{k:bool(v) for k,v in R.items()})
