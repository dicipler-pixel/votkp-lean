# PREREG G-02 — the tight-knot glueball extension, tested in its own sector

Registered before reading the continuum spectrum of Athenodorou & Teper (2020) beyond the three
values already known here (0++ 3.405, 2++ 4.894, 0-+ 5.276, in units of the square root of the
string tension). The outline of the SU(3) spectrum is general knowledge; the rules below are fixed
before any value beyond those three is looked up.

## Why a second test
The published tight-knot model (Buniy & Kephart 2003; Buniy, Cantarella, Kephart & Rawdon 2014) is
fitted to J^{++} states and assigns no J^{PC}. P-01 compared the two shortest lengths with the two
lightest pure-gauge states. The third lightest state, 0-+, lies outside the model's sector, so the
0.5% agreement of the corrected 4^2_1 length with M(0-+)/M(0++) is not a test of the model.

## Inputs (fixed now)
Lengths, uncorrected ropelength: Hopf link 8*pi; trefoil 32.7436, figure-eight 42.0887,
5_1 47.2016, 5_2 49.4701 (KnotInfo); 4^2_1 40.0122 (Cantarella atlas). Curvature-corrected (BCKR):
Hopf 11.724, trefoil 14.943, 4^2_1 18.250. Objects are ordered by length; the uncorrected order is
Hopf, trefoil, 4^2_1, then the next objects (4_1 and any link shorter than it, if its length can
be obtained; otherwise the knots only are used beyond 4^2_1 and this is stated).

## Tests
S1 — the model's own sector. Take the continuum J^{++} states (P = +, C = +, any J) in order of
mass. Assign the k-th shortest object to the k-th lightest J^{++} state. Prediction:
M_k / M_1 = L_k / L_1. Kill: the median |relative error| over k = 2..4 exceeds 5%, for both length
sets (corrected lengths only where available).

S2 — each object's ground state is a scalar. Compare the 0++ tower (ground and excited 0++ states)
with the shortest objects in order. Same prediction and the same 5% kill over the available k >= 2.

S3 — base rate of a 0.5% match. Over all continuum states i != 0++ in the table, the fraction of
ratios M_i / M(0++) that fall within 0.5% of a given knot ratio in [1.2, 2.0], and the chance that
at least one of the table's ratios does. Reported, not a pass/fail test.

## What is not allowed
No length prescription, scale or assignment is changed after the table is read. Uncertainties are
the table's statistical errors only; the continuum values are used as published.
