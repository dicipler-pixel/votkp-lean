# SCRIPT: G02-OPP-01
# Ratio test instead of length test, first-to-second form: R = (first J++ state mass)/(second J++ state mass) from Table 17 against
# (first object length)/(second object length) with objects ordered Hopf, 3_1 (uncorrected and BCKR-corrected lengths), same inputs as g02_run.py.
# Why it decides: the registered S1 compared M_k/M_1 with L_k/L_1 as a median over k=2..4; this isolates the single first-to-second ratio and inverts its direction, so the comparison does not depend on which object is the unit.
# Frozen kill: ratio of first to second J++ state from the loop lengths differs from lattice by more than 5%.
from math import pi
exec(open('orig.py').read().split('def test(')[0].split("print('prereg")[0].split('import hashlib')[0])  # no-op header guard
T17 = {'0++': 3.405, '0++*': 5.855, '2++': 4.894, '2++*': 6.788, '3++': 7.71, '4++': 7.60,'0-+': 5.276, '0-+*': 7.29, '2-+': 6.32, '2-+*': 8.18, '1-+': 8.48, '1-+*': 8.57, '1-+**': 8.66,'1+-': 6.065, '1+-*': 7.82, '1--': 8.31, '2+-': 8.74, '2--': 8.08, '3-+': 7.27, '4--': 9.02}
jpp=sorted([(m,s) for s,m in T17.items() if s.rstrip('*')[1:]=='++'])
lat=jpp[0][0]/jpp[1][0]; print('first two J++ states',jpp[0],jpp[1],'lattice first/second = %.4f'%lat)
fire=False
for name,(a,b) in (('uncorrected Hopf/3_1',(8*pi,32.7436)),('BCKR-corrected Hopf/3_1',(11.724,14.943))):
    r=a/b; err=abs(r/lat-1); fire|=err>0.05
    print('%-24s length ratio first/second %.4f  vs lattice %.4f  |diff| = %.2f%%'%(name,r,lat,100*err))
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if either exceeds 5%)')
