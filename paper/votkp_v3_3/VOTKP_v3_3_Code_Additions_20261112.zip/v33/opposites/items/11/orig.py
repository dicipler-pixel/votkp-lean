# SCRIPT: G02-RUN
# Runs the registered G-02 test (PREREG_G02.md, SHA-256 3ce6f954...) exactly as written, on the continuum SU(3)
# masses of Athenodorou & Teper (2020), Table 17, as transcribed from the printed table in the external audit
# record (g02_primary_source.json; all twenty values are in that record's script, work/gap_review/audit_v10_g02.py,
# and T17 below repeats them). Independent code: it shares no lines with the audit script.
import hashlib, json, itertools, os
from fractions import Fraction
from math import pi
here = os.path.dirname(os.path.abspath(__file__))
prereg = open(here + '/PREREG_G02.md', 'rb').read()
print('prereg sha256', hashlib.sha256(prereg).hexdigest())
T17 = {  # state: M/sqrt(sigma), continuum, Table 17
 '0++': 3.405, '0++*': 5.855, '2++': 4.894, '2++*': 6.788, '3++': 7.71, '4++': 7.60,
 '0-+': 5.276, '0-+*': 7.29, '2-+': 6.32, '2-+*': 8.18, '1-+': 8.48, '1-+*': 8.57, '1-+**': 8.66,
 '1+-': 6.065, '1+-*': 7.82, '1--': 8.31, '2+-': 8.74, '2--': 8.08, '3-+': 7.27, '4--': 9.02}
assert len(T17) == 20
L_unc = [('Hopf', 8 * pi), ('3_1', 32.7436), ('4^2_1', 40.0122), ('4_1', 42.0887)]
L_cor = [('Hopf', 11.724), ('3_1', 14.943), ('4^2_1', 18.250)]
jpp = sorted([(m, s) for s, m in T17.items() if s.rstrip('*')[1:] == '++'])
tower = sorted([(m, s) for s, m in T17.items() if s.rstrip('*') == '0++'])
def test(states, lengths, kmax):
    rows = []
    for k in range(2, min(kmax, len(states), len(lengths)) + 1):
        pred = lengths[k - 1][1] / lengths[0][1]; obs = states[k - 1][0] / states[0][0]
        rows.append((k, lengths[k - 1][0], states[k - 1][1], pred, obs, abs(pred / obs - 1)))
    errs = sorted(r[5] for r in rows); n = len(errs)
    med = errs[n // 2] if n % 2 else 0.5 * (errs[n // 2 - 1] + errs[n // 2])
    return rows, med
out = {}
for name, states, kmax in (('S1 J++ sector', jpp, 4), ('S2 0++ tower', tower, 99)):
    for lname, L in (('uncorrected', L_unc), ('corrected', L_cor)):
        rows, med = test(states, L, kmax)
        print(f'{name:14s} {lname:11s} median |err| = {100*med:5.2f}%  -> {"KILLED" if med > 0.05 else "passes"}')
        for r in rows: print(f'      k={r[0]} {r[1]:6s} vs {r[2]:5s}: predicted {r[3]:.4f}  observed {r[4]:.4f}  |err| {100*r[5]:.2f}%')
        out[f'{name}|{lname}'] = med
# S3: base rate of a 0.5% match (reported, not a test)
others = sorted(m / T17['0++'] for s, m in T17.items() if s != '0++')
for lname, t in (('corrected 4^2_1/Hopf', 18.250 / 11.724), ('uncorrected 4^2_1/Hopf', 40.0122 / (8 * pi))):
    hits = [s for s, m in T17.items() if s != '0++' and abs((m / T17['0++']) / t - 1) <= 0.005]
    print(f'S3 {lname}: target {t:.4f}; states within 0.5%: {hits}')
# chance that a target drawn uniformly from [1.2, 2.0] has at least one of the 19 ratios within 0.5%
iv = sorted((max(1.2, r / 1.005), min(2.0, r / 0.995)) for r in others if r / 1.005 < 2.0 and r / 0.995 > 1.2)
cover, cur = 0.0, None
for a, b in iv:
    if cur is None or a > cur[1]:
        if cur: cover += cur[1] - cur[0]
        cur = [a, b]
    else: cur[1] = max(cur[1], b)
if cur: cover += cur[1] - cur[0]
print(f'S3 base rate: {sum(1 for r in others if 1.2 <= r <= 2.0)} of 19 ratios lie in [1.2, 2.0]; a target drawn uniformly there '
      f'has a table ratio within 0.5% with probability {cover/0.8:.3f}')
