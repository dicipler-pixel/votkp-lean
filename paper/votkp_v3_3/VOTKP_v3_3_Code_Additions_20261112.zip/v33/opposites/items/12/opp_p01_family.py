# SCRIPT: P01-OPP-01
# Other fit family for P-01. Original: R_knot = L(trefoil)/L(Hopf link) against R_lat = m2/m1 = 5.85/4.21 (Morningstar-Peardon 1999 Table VII).
# Family B (knots only, no links, KnotInfo ropelength): R2_B = L(4_1)/L(3_1), R3_B = L(5_1)/L(3_1) against R2_lat and R3_lat (6.33/4.21).
# Family C (all KnotInfo knots in ropelength order up to 5_2): R2_C = L(4_1)/L(3_1), R3_C = L(5_2)/L(3_1)  [3_1<4_1<5_1<5_2 ordering as in G-02 inputs; 5_1 < 5_2 by length].
# Errors: 'combined' = statistical and anisotropy errors added in quadrature (the conservative variant of PREREG_PART_01), registered here before the run.
# Why it decides: P-01's pass/fail rests on one length ordering; a knots-only family changes which lengths enter. 
# Frozen kill: abs(R_knot - R_lat) > 3 sigma with the combined error. Operationalised: fires if any of R2_B, R3_B, R3_C exceeds 3 combined sigma.
import numpy as np
from database_knotinfo import link_list
L={r['name']:float(r['ropelength']) for r in link_list()[1:] if r['ropelength'] not in ('',None)}
m1,s1,a1=4.21,0.11,0.04; m2,s2,a2=5.85,0.02,0.06; m3,s3,a3=6.33,0.07,0.06
def ratio(ma,sa,aa,mb,sb,ab):
    R=mb/ma; cons=R*np.hypot(np.hypot(sa,aa)/ma,np.hypot(sb,ab)/mb); st=R*np.hypot(sa/ma,sb/mb); return R,st,cons
R2,st2,c2=ratio(m1,s1,a1,m2,s2,a2); R3,st3,c3=ratio(m1,s1,a1,m3,s3,a3)
print('ropelengths:',{k:L[k] for k in ('3_1','4_1','5_1','5_2')})
fire=False
for lab,rk,R,st,c in (('R2_B 4_1/3_1',L['4_1']/L['3_1'],R2,st2,c2),('R3_B 5_1/3_1',L['5_1']/L['3_1'],R3,st3,c3),('R3_C 5_2/3_1',L['5_2']/L['3_1'],R3,st3,c3)):
    z=abs(R-rk)/c; zs=abs(R-rk)/st; fire|=z>3
    print('%-14s R_knot %.4f  R_lat %.4f  |diff| %.4f  = %.2f sigma(combined) = %.2f sigma(stat)'%(lab,rk,R,abs(R-rk),z,zs))
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if any > 3 combined sigma)')
