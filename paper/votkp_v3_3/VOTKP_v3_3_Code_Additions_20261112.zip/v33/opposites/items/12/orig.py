# SCRIPT: PART-01-P01-P02
import numpy as np
from database_knotinfo import link_list
L={r['name']:r['ropelength'] for r in link_list()[1:]}
tre=float(L['3_1']); hopf=8*np.pi
print('P-01  knot lengths: trefoil (KnotInfo) %.4f, Hopf link 8pi %.4f, atlas Hopf 25.1334'%(tre,hopf))
# lattice: Morningstar & Peardon 1999 Table VII, r0*m with (stat)(aniso)
m1,s1,a1=4.21,0.11,0.04; m2,s2,a2=5.85,0.02,0.06; m3,s3,a3=6.33,0.07,0.06
def ratio(ma,sa,aa,mb,sb,ab):
    R=mb/ma; st=R*np.hypot(sa/ma,sb/mb); cons=R*np.hypot(np.hypot(sa,aa)/ma,np.hypot(sb,ab)/mb); return R,st,cons
R2,st2,c2=ratio(m1,s1,a1,m2,s2,a2); R3,st3,c3=ratio(m1,s1,a1,m3,s3,a3)
print('lattice R2 = %.4f  sigma_stat %.4f  sigma_cons %.4f'%(R2,st2,c2))
print('lattice R3 = %.4f  sigma_stat %.4f  sigma_cons %.4f'%(R3,st3,c3))
for lab,rk2,rk3 in (('uncorrected ropelength',tre/hopf,40.0122/hopf),('BCKR curvature-corrected',14.943/11.724,18.250/11.724)):
    print('  %-26s R2_knot %.4f -> %.2f sigma (stat), %.2f sigma (cons) | R3_knot %.4f -> %+.2f sigma (stat)'%(lab,rk2,(R2-rk2)/st2,(R2-rk2)/c2,rk3,(rk3-R3)/st3))
k1=all(abs(R2-r)/st2>3 for r in (tre/hopf,14.943/11.724))
print('  KILL (both versions beyond 3 sigma, primary):',k1, '| any version beyond 3 sigma:',any(abs(R2-r)/st2>3 for r in (tre/hopf,14.943/11.724)))
# knots-only variant (no links): trefoil and figure-eight
print('  knots-only first ratio 4_1/3_1 = %.4f'%(float(L['4_1'])/tre))
# P-02 constituent axis
hc_cm=8065.543937  # cm^-1 per eV (CODATA 2018)
IE_H=13.598434599702; EA_H=6082.99/hc_cm; sEA_H=0.15/hc_cm
mu=lambda M: 1/(1+5.48579909065e-4/M)   # M in electron... use mass ratio below
me_mp=1/1836.15267343; me_md=1/3670.48296788
IE_D=IE_H*(1+me_mp)/(1+me_md)          # hydrogenic reduced-mass scaling (QED/nuclear-size differences below 1e-9 relative)
EA_D=6086.2/hc_cm; sEA_D=0.6/hc_cm
EA_Ps=0.32688; sEA_Ps=np.hypot(0.09,0.10)*1e-3; IE_Ps=13.605693122994/2  # Rydberg energy/2, nonrelativistic
tau=lambda IE,EA: np.log(IE/EA)
tH,tD,tP=tau(IE_H,EA_H),tau(IE_D,EA_D),tau(IE_Ps,EA_Ps)
print('\nP-02  tau = ln(IE/EA), Gamma = tanh(tau/2)')
for lab,t,s in (('H-  (p e e)',tH,sEA_H/EA_H),('D-  (d e e)',tD,sEA_D/EA_D),('Ps- (e+ e e)',tP,sEA_Ps/EA_Ps)):
    print('  %-14s tau = %.5f +- %.5f   Gamma = %.5f'%(lab,t,s,np.tanh(t/2)))
# infinite-mass theory point: E(H-inf) = -0.527751016544377 a.u. (Drake/Frolov value), IE = 0.5
tinf=np.log(0.5/0.027751016544377); print('  H- infinite nuclear mass (theory) tau = %.5f'%tinf)
tPs_nr=np.log(0.25/0.01200507023298010); print('  Ps- nonrelativistic theory tau = %.5f (Grigorescu-Drake binding)'%tPs_nr)
d=tD-tH; sd=np.hypot(sEA_H/EA_H,sEA_D/EA_D)
print('  tau(D)-tau(H) = %.2e +- %.1e  (normal-mass-shift expectation 0)'%(d,sd))
nms=EA_H*hc_cm*((1+me_mp)/(1+me_md)-1); print('  EA isotope shift measured %.2f cm-1; normal mass shift %.2f cm-1; residual (specific) %.2f +- %.2f cm-1'%(6086.2-6082.99,nms,6086.2-6082.99-nms,np.hypot(0.15,0.6)))
print('  tau(Ps-)-tau(H-) = %.4f'%(tP-tH))
