# SCRIPT: WALLRES-OPP-01
# Re-register form 2 with two wall kinds. Kind s = first-wall elements of groups 1-2 (valence is s only); kind p = groups 13-18 (valence p).
# Kinds are fixed here by group, before any CV is computed. Same rows 2-6 and same first_wall dZeff as wall_residue_01.py (exec'd from orig.py).
# Why it decides: the original pooled all elements of a row; the dZeff pattern in rows 4-6 is clearly bimodal (s-wall vs p-wall), so pooling is the suspect; the kind split tests it.
# Frozen kill: CV of Delta Z_eff above 10% inside either kind in two or more rows.
# Operationalised before the run: fires if the number of rows in which at least one kind has CV > 10% is >= 2.
import os, sys, numpy as np
src=open('orig.py').read().split('print("row  Z  el')[0]
exec(src)
bad=0
for r,Zs in rows.items():
    out={}
    for kind,pick in (('s',lambda p:p<=2),('p',lambda p:p>=len(Zs)-5)):
        ds=[first_wall(Z)[4] for p,Z in enumerate(Zs,1) if pick(p)]
        out[kind]=(len(ds),np.std(ds,ddof=1)/np.mean(ds)*100)
    flag=any(v[1]>10 for v in out.values()); bad+=flag
    print(f'row {r}: s-kind n={out["s"][0]} CV={out["s"][1]:.1f}%   p-kind n={out["p"][0]} CV={out["p"][1]:.1f}%   row exceeds 10%: {flag}')
print('rows with a kind above 10%:',bad)
print('KILL FIRED' if bad>=2 else 'KILL NOT FIRED','(fires if >= 2 rows)')
