# SCRIPT: WALL-RESIDUE-01  two forms of the wall-residue test, rows 2-6, main group, first valence wall
# run with VOTKP_ROOT pointing at the v1.2 package's work/ directory (uses rhythm/rdata.py)
import sys, os, numpy as np
sys.path.insert(0, os.environ['VOTKP_ROOT']+'/rhythm')
from rdata import IE, SH, FLAG, SYM, nmax, zeff
from scipy.stats import spearmanr
rows={2:[3,4,5,6,7,8,9,10],3:[11,12,13,14,15,16,17,18],4:[19,20,31,32,33,34,35,36],5:[37,38,49,50,51,52,53,54],6:[55,56,81,82,83,84,85,86]}
def first_wall(Z):
    for k in sorted(IE[Z]):
        if k+1 not in IE[Z]: return None
        n1,n2=nmax(SH[Z][k]),nmax(SH[Z][k+1])
        if n2==n1-1:
            z1,z2=zeff(Z,k),zeff(Z,k+1)
            G=np.tanh(0.5*np.log(IE[Z][k+1]/IE[Z][k])); Gsh=np.tanh(np.log(n1/n2))
            x=(G-Gsh)/(1-G*Gsh)
            return k,n1,z1,z2,z2-z1,x,FLAG[Z][k],FLAG[Z][k+1]
print("row  Z  el  wall_k n  Zeff_before Zeff_after  dZeff   x_resid  grades")
res={}
for r,Zs in rows.items():
    xs=[];ds=[];pos=[]
    for p,Z in enumerate(Zs,1):
        k,n,z1,z2,dz,x,g1,g2=first_wall(Z)
        print(f"{r}   {Z:2d} {SYM[Z]:2s}  {k:2d}     {n}  {z1:8.4f}   {z2:8.4f}  {dz:7.4f}  {x:7.4f}  {g1}{g2}")
        xs.append(x);ds.append(dz);pos.append(p)
    rho=spearmanr(pos,xs).correlation; cv=np.std(ds,ddof=1)/np.mean(ds); res[r]=(rho,cv)
    print(f"   row {r}: Spearman(x, position) = {rho:+.3f}   dZeff mean = {np.mean(ds):.4f}  CV = {100*cv:.1f}%\n")
print("KILL: form1 dies if any row rho > -0.8 ; form2 dies if CV>10% in >=2 rows")
print({r:(round(v[0],3),round(100*v[1],1)) for r,v in res.items()})
