# SCRIPT: TIME01B-OPP-01
# Midpoint rule registered first. Original (2b) accumulates <dH/dk> at the START state of each step (left-point in time, H at the step midpoint).
# Opposite: evaluate <dH/dk> on the midpoint state psi_mid = expm(-i H dt/2) psi (time-centred quadrature). Same Rice-Mele pump, same k grid (64), same T in (50, 200), same dt (T*20 steps).
# Why it decides: the original miss was 1.0e-3 (0.9990). A time-centred integral removes the first-order quadrature bias; if the miss remains the shortfall is not the quadrature rule.
# Frozen kill: midpoint charge off 1 by more than 1e-3.
import numpy as np
from scipy.linalg import expm
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]]); sz=np.diag([1.,-1.]).astype(complex)
J,d0,D0=1.0,0.6,0.6
def H(k,s):
    v=J+d0*np.cos(2*np.pi*s); w=J-d0*np.cos(2*np.pi*s); D=D0*np.sin(2*np.pi*s)
    return (v+w*np.cos(k))*sx+w*np.sin(k)*sy+D*sz
def dHdk(k,s):
    w=J-d0*np.cos(2*np.pi*s); return -w*np.sin(k)*sx+w*np.cos(k)*sy
fire=False
for T in (50.0,200.0):
    nt=int(T*20); dt=T/nt; Qo=0.0; Qm=0.0
    for k in np.linspace(0,2*np.pi,64,endpoint=False):
        e,v=np.linalg.eigh(H(k,0)); psi=v[:,0]
        for it in range(nt):
            s=(it+0.5)/nt; Hk=H(k,s); h=expm(-1j*Hk*dt/2)
            Qo+=np.real(np.vdot(psi,dHdk(k,s)@psi))*dt
            pm=h@psi; Qm+=np.real(np.vdot(pm,dHdk(k,s)@pm))*dt
            psi=h@pm
    Qo/=64; Qm/=64
    print('T=%g  original-rule Q = %.6f   midpoint-rule Q = %.6f   |Q-1| = %.2e'%(T,Qo,Qm,abs(Qm-1)))
    if abs(Qm-1)>1e-3: fire=True
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if |Q_mid - 1| > 1e-3 at either T)')
