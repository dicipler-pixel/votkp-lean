# SCRIPT: TIME-01B-PHASE-TO-REAL-TIME
import numpy as np, mpmath as mp
from scipy.linalg import expm
print('(1) circle: eta(alpha)=1-2alpha; Goldstone-Wilczek charge Q=-eta/2 = alpha-1/2 (mod integers)')
for a in (0.1,0.4,0.9):
    eta=float(mp.zeta(0,a)-mp.zeta(0,1-a)); print('   alpha=%.1f eta=%.4f Q=%.4f'%(a,eta,-eta/2))
print('   one period alpha->alpha+1 moves Q by exactly 1 (spectral flow +1); with alpha=t/T the current is I=e/T')
for T,label in ((1e-9,'1 ns'),(1e-6,'1 us')): print('     T = %s  ->  I = %.3e A'%(label,1.602176634e-19/T))
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]]); sz=np.diag([1.,-1.]).astype(complex)
J,d0,D0=1.0,0.6,0.6
def H(k,s):
    v=J+d0*np.cos(2*np.pi*s); w=J-d0*np.cos(2*np.pi*s); D=D0*np.sin(2*np.pi*s)
    return (v+w*np.cos(k))*sx+w*np.sin(k)*sy+D*sz
def dHdk(k,s):
    w=J-d0*np.cos(2*np.pi*s); return -w*np.sin(k)*sx+w*np.cos(k)*sy
# (2a) Chern number over (k,s) by Fukui-Hatsugai-Suzuki
Nk,Ns=120,120; ks=np.linspace(0,2*np.pi,Nk,endpoint=False); ss=np.linspace(0,1,Ns,endpoint=False)
U=np.empty((Nk,Ns,2),complex); gapmin=9
for i,k in enumerate(ks):
    for j,s in enumerate(ss):
        e,v=np.linalg.eigh(H(k,s)); U[i,j]=v[:,0]; gapmin=min(gapmin,e[1]-e[0])
F=0
for i in range(Nk):
    for j in range(Ns):
        u1=U[i,j];u2=U[(i+1)%Nk,j];u3=U[(i+1)%Nk,(j+1)%Ns];u4=U[i,(j+1)%Ns]
        F+=np.angle(np.vdot(u1,u2)*np.vdot(u2,u3)*np.vdot(u3,u4)*np.vdot(u4,u1))
print('(2a) Rice-Mele pump: minimum gap %.3f; Chern number (pumped charge per cycle) = %.6f'%(gapmin,F/(2*np.pi)))
# (2b) real-time adiabatic evolution: pumped charge = (1/2pi) int dk int dt <psi|dH/dk|psi>
for T in (50.0,200.0):
    nt=int(T*20); dt=T/nt; Q=0.0
    for k in np.linspace(0,2*np.pi,64,endpoint=False):
        e,v=np.linalg.eigh(H(k,0)); psi=v[:,0]
        for it in range(nt):
            s=(it+0.5)/nt; Hk=H(k,s)
            Q+=np.real(np.vdot(psi,dHdk(k,s)@psi))*dt
            psi=expm(-1j*Hk*dt)@psi
    Q/=64
    print('(2b) real-time evolution over one cycle of duration T=%g: pumped charge = %.4f'%(T,Q))
