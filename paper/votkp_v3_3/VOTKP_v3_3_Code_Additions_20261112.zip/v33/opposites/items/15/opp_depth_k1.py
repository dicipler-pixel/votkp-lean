# SCRIPT: DEPTH-OPP-01
# Other shell rule for the depth law. Original rule at depth K: a miss is contained if outer > K. Opposite rule ("K+1"): contained if outer > K+1.
# Also reported: contained if outer >= K+1 under the alternative outer definition (d-count: group for groups 3-12 only counts d+s; main group = group-10).
# Same classifier/misses as c1_depth.py (1-NN on z-scored T1, train Z<=54, test period 6 non-f).
# Why it decides: the original depth law has 3 misses outside its set at K=11-12; a shifted shell rule says whether any shell rule of this form covers them.
# Frozen kill: a contained-set rule with K+1 explains fewer than 80% of misses at K=11-12.
# Operationalised before run: pooled over K=11 and 12, fraction of misses contained under the K+1 rule < 0.80 -> fires.
import os, json, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
D={int(k):v for k,v in json.load(open(os.environ['VOTKP_ROOT']+'/elemental/element_records.json')).items()}
outer=lambda Z: D[Z]['group'] if D[Z]['group']<=12 else D[Z]['group']-10
tot=0; c0=0; c1=0
for K in (11,12):
    tr=[Z for Z in range(1,55) if len(D[Z]['ie'])>=K+1 and D[Z]['group'] and D[Z]['block']!='f']
    te=[Z for Z in range(55,87) if len(D[Z]['ie'])>=K+1 and D[Z]['group'] and D[Z]['block']!='f']
    f=lambda Z: np.diff(np.log(D[Z]['ie'][:K+1]))
    sc=StandardScaler().fit([f(Z) for Z in tr]); m=KNeighborsClassifier(1).fit(sc.transform([f(Z) for Z in tr]),[D[Z]['group'] for Z in tr])
    p=m.predict(sc.transform([f(Z) for Z in te]))
    miss=[Z for Z,pp in zip(te,p) if pp!=D[Z]['group']]
    a=[D[Z]['sym'] for Z in miss if outer(Z)>K]; b=[D[Z]['sym'] for Z in miss if outer(Z)>K+1]
    print(f'K={K}: misses {[D[Z]["sym"] for Z in miss]} outer {[outer(Z) for Z in miss]}; contained (outer>K) {a}; contained (outer>K+1) {b}')
    tot+=len(miss); c0+=len(a); c1+=len(b)
print('pooled K=11-12: misses',tot,'contained under K rule',c0,'under K+1 rule',c1,'fraction %.3f'%(c1/max(tot,1)))
print('KILL FIRED' if c1/max(tot,1)<0.8 else 'KILL NOT FIRED','(fires if fraction < 0.80)')
