# SCRIPT: CLOSE-C1-DEPTH-LAW
import os as _os; _ROOT=_os.environ.get('VOTKP_ROOT') or _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))  # package: work/
import json, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
D={int(k):v for k,v in json.load(open(_ROOT+'/elemental/element_records.json')).items()}
outer=lambda Z: D[Z]['group'] if D[Z]['group']<=12 else D[Z]['group']-10
tot=0; inside=0; outside=[]
for K in range(1,13):
    tr=[Z for Z in range(1,55) if len(D[Z]['ie'])>=K+1 and D[Z]['group'] and D[Z]['block']!='f']
    te=[Z for Z in range(55,87) if len(D[Z]['ie'])>=K+1 and D[Z]['group'] and D[Z]['block']!='f']
    f=lambda Z: np.diff(np.log(D[Z]['ie'][:K+1]))
    sc=StandardScaler().fit([f(Z) for Z in tr]); m=KNeighborsClassifier(1).fit(sc.transform([f(Z) for Z in tr]),[D[Z]['group'] for Z in tr])
    p=m.predict(sc.transform([f(Z) for Z in te]))
    miss=[(D[Z]['sym'],outer(Z)) for Z,pp in zip(te,p) if pp!=D[Z]['group']]
    ins=[s for s,o in miss if o>K]; out=[(s,o) for s,o in miss if o<=K]
    tot+=len(miss); inside+=len(ins); outside+= [(K,)+x for x in out]
    print(f'K={K:2d} acc {1-len(miss)/len(te):.3f} (n={len(te)}) misses {[s for s,_ in miss]}  outside rule: {out}')
print('pooled misses',tot,'explained by outer>K',inside,'(%.1f%%)'%(100*inside/max(tot,1)),' misses outside rule:',outside)
