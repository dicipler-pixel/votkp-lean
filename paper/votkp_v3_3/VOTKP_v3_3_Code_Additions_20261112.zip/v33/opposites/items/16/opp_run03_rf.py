# SCRIPT: RUN03-OPP-01
# Other model class for Run 03: random forest regression (LOO) replaces kNN/OLS. Settings = 3 K (3,6,10) x 3 forest configs
# (max_features 1.0, 0.5, sqrt; 100 trees, seed 0) = 9. Static S2 vs peel T1 held-out MAE on ln covalent radius, ln atomic radius, ln hardness.
# Original counts (reproduced from run03_results.csv): static beats peel in 9/9 (covalent), 9/9 (atomic), 8/9 (hardness).
# Frozen kill: random forest static beats peel in fewer than the same 9 of 9 and 8 of 9.
# Operationalised before run: fires if, for any of the three targets, RF static wins fewer settings than the original count for that target.
import numpy as np, warnings; warnings.filterwarnings('ignore')
exec(open('orig.py').read().split('rows=[]; verdict={}')[0])   # E, F, hard, targets, helpers
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import LeaveOneOut, cross_val_predict
orig={'ln covalent radius':9,'ln atomic radius':9,'ln hardness':8}
fire=False
for tname,need in orig.items():
    get,tr=targets[tname]; wins=0; lines=[]
    for K in (3,6,10):
        Zs=[Z for Z in range(1,87) if len(E[Z]['ie'])>=K+1 and get(Z) is not None]
        y=tr(np.array([get(Z) for Z in Zs],float))
        for mf in (1.0,0.5,'sqrt'):
            err={}
            for name in ('S2','T1'):
                X=F(Zs,name,K); p=cross_val_predict(RandomForestRegressor(100,max_features=mf,random_state=0),X,y,cv=LeaveOneOut(),n_jobs=2)
                err[name]=np.abs(p-y).mean()
            w=err['S2']<err['T1']; wins+=w; lines.append((K,mf,round(err['S2'],3),round(err['T1'],3)))
    print(tname,'RF static beats peel in',wins,'of 9 (original',need,'of 9)',lines)
    if wins<need: fire=True
print('KILL FIRED' if fire else 'KILL NOT FIRED')
