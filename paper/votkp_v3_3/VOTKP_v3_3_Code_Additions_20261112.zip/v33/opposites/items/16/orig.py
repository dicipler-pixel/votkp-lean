# SCRIPT: ONION-ATLAS-03  (tests T-B and T-I, pre-registered in PREREGISTRATION_RUN03.md)
import numpy as np, csv, warnings; warnings.filterwarnings('ignore')
from mendeleev import element
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
rng=np.random.default_rng(3)
E={}
for Z in range(1,88):
    e=element(Z); ie=e.ionenergies
    E[Z]=dict(sym=e.symbol,ie=[ie[k] for k in sorted(ie)],ea=e.electron_affinity,rc=e.covalent_radius_pyykko,ra=e.atomic_radius,g=e.group_id,blk=e.block)
def F(Zs,name,K):
    X=[]
    for Z in Zs:
        l=np.log(E[Z]['ie'][:K+1])
        X.append({'Z':[Z],'S1':[l[0]],'S2':l,'S2c':l-l.mean(),'T1':np.diff(l),'T1+S1':np.r_[np.diff(l),l[0]]}[name])
    return StandardScaler().fit_transform(np.array(X,float))
def pred(X,y,model):
    m={'knn1':KNeighborsRegressor(1),'knn3':KNeighborsRegressor(3),'ols':LinearRegression()}[model]
    return cross_val_predict(m,X,y,cv=LeaveOneOut())
def boot(a,b,n=2000):
    d=[(a[i]-b[i]).mean() for i in [rng.integers(0,len(a),len(a)) for _ in range(n)]]; return np.percentile(d,[2.5,97.5])
def hard(Z):
    ea=E[Z]['ea']; return (E[Z]['ie'][0]-ea)/2 if (ea is not None and ea>0) else None
targets={
 'EA (eV)':(lambda Z:E[Z]['ea'] if (E[Z]['ea'] is not None and E[Z]['ea']>0) else None, lambda v:v),
 'ln covalent radius':(lambda Z:E[Z]['rc'], np.log),
 'ln atomic radius':(lambda Z:E[Z]['ra'], np.log),
 'ln hardness':(hard, np.log),
}
rows=[]; verdict={}
for tname,(get,tr) in targets.items():
  res=[]
  for K in (3,6,10):
    Zs=[Z for Z in range(1,87) if len(E[Z]['ie'])>=K+1 and get(Z) is not None]
    y=tr(np.array([get(Z) for Z in Zs],float)); err={}
    for name in ('Z','S1','S2','S2c','T1','T1+S1'):
      X=F(Zs,name,K)
      for model in ('knn1','knn3','ols'):
        e_=np.abs(pred(X,y,model)-y); err[(name,model)]=e_
        rows.append(dict(target=tname,K=K,n=len(Zs),feat=name,model=model,MAE=round(e_.mean(),4),CI=''))
    for model in ('knn1','knn3','ols'):
      lo,hi=boot(err[('T1',model)],err[('S2',model)]); d=(err[('T1',model)]-err[('S2',model)]).mean()
      rows.append(dict(target=tname,K=K,n=len(Zs),feat='T1-S2',model=model,MAE=round(d,4),CI=f'{lo:.4f}..{hi:.4f}'))
      res.append((K,model,d,lo,hi))
  wins=sum(d<0 for _,_,d,_,_ in res); sig=sum(hi<0 for *_,hi in res); sigS=sum(lo>0 for *_,lo,hi in res)
  verdict[tname]=(wins,sig,sigS)
  print(f'{tname}: T1 beats S2 in {wins}/9; peel-better CI excl 0 in {sig}; static-better CI excl 0 in {sigS}')
  for K in (3,6,10):
    sub={(r['feat'],r['model']):r['MAE'] for r in rows if r['target']==tname and r['K']==K and r['feat']!='T1-S2'}
    print(f'   K={K}: OLS S1 {sub[("S1","ols")]} S2 {sub[("S2","ols")]} T1 {sub[("T1","ols")]} T1+S1 {sub[("T1+S1","ols")]} | kNN1 S2 {sub[("S2","knn1")]} T1 {sub[("T1","knn1")]}')
killed=[t for t,(w,s,_) in verdict.items() if w>=5 and s>=1]
print('T-B KILL triggered by:',killed if killed else 'none')
with open('run03_results.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['target','K','n','feat','model','MAE','CI']); w.writeheader(); w.writerows(rows)
# secondary: does adding level hurt family?
print('\nSecondary: group accuracy (LOO 1-NN), T1 vs T1+S1')
for K in (3,6,10):
    Zs=[Z for Z in range(1,87) if len(E[Z]['ie'])>=K+1 and E[Z]['g'] and E[Z]['blk']!='f']
    y=np.array([E[Z]['g'] for Z in Zs])
    for name in ('T1','T1+S1','S2'):
        p=cross_val_predict(KNeighborsClassifier(1),F(Zs,name,K),y,cv=LeaveOneOut()); print(f'  K={K} {name}: {np.mean(p==y):.3f}',end='')
    print()
# T-I noble resets
print('\nT-I noble-gas extremum counts')
noble=(2,10,18,36,54,86)
def ext(get,kind):
    out=[]
    for Z in noble:
        v=get(Z); nb=[get(Z+1)]+([get(Z-1)] if Z>2 else [])
        if v is None or any(x is None for x in nb): out.append((E[Z]['sym'],'missing')); continue
        ok=all(v<x for x in nb) if kind=='min' else all(v>x for x in nb)
        out.append((E[Z]['sym'],bool(ok)))
    return out
for nm,get,kind in (('covalent radius (min)',lambda Z:E[Z]['rc'],'min'),('atomic radius (min)',lambda Z:E[Z]['ra'],'min'),
                    ('IE1 (max)',lambda Z:E[Z]['ie'][0],'max'),('hardness (max)',hard,'max')):
    o=ext(get,kind); print(f'  {nm}: {sum(1 for _,x in o if x is True)}/6 ',o)
o=[(E[Z]['sym'],E[Z]['ea'],E[Z+1]['ea'],E[Z-1]['ea'] if Z>2 else None) for Z in noble]
print('  EA (noble, next, prev):',o)
