# SCRIPT: TO-OPP-01
# T-O reproduction (train Z<=54, test period-6 non-f, 1-NN on z-scored feature, K=6) then the opposite: random splits of the same size.
# Original script is not on disk (only the TEST_LOG declaration), so the reproduction is a re-implementation written from that declaration; the check is the logged number K=6: T1 0.667 = S2 0.667.
# Why it decides: T-O tied at K=6 on one split (period boundary). Random splits of the same size (18 test elements from Z 1-86 non-f) ask whether the tie is the split.
# Frozen kill: T1 does not exceed S2 on 5 random seeds of the K=6 split.
# Operationalised before run: fires if T1 accuracy <= S2 accuracy on ALL 5 seeds (0..4). Seeds 5-204 reported as supplementary only.
import os, json, numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
D={int(k):v for k,v in json.load(open(os.environ['VOTKP_ROOT']+'/elemental/element_records.json')).items()}
K=6
Zs=[Z for Z in range(1,87) if D[Z]['group'] and D[Z]['block']!='f' and len(D[Z]['ie'])>=K+1]
feat=lambda Z,n: np.log(D[Z]['ie'][:K+1]) if n=='S2' else np.diff(np.log(D[Z]['ie'][:K+1]))
def acc(tr,te,n):
    X=np.array([feat(Z,n) for Z in tr]); sc=StandardScaler().fit(X); m=KNeighborsClassifier(1).fit(sc.transform(X),[D[Z]['group'] for Z in tr])
    p=m.predict(sc.transform(np.array([feat(Z,n) for Z in te]))); return np.mean(p==np.array([D[Z]['group'] for Z in te]))
tr=[Z for Z in Zs if Z<=54]; te=[Z for Z in Zs if Z>=55]
print('reproduction: n_test',len(te),'T1 %.3f S2 %.3f'%(acc(tr,te,'T1'),acc(tr,te,'S2')),'(logged: 0.667 = 0.667, n=18)')
res=[]
for s in range(205):
    r=np.random.default_rng(s); te=list(r.choice(Zs,18,replace=False)); tr=[Z for Z in Zs if Z not in te]
    res.append((s,acc(tr,te,'T1'),acc(tr,te,'S2')))
for s,a,b in res[:5]: print('seed',s,'T1 %.3f S2 %.3f'%(a,b),'T1 exceeds' if a>b else 'T1 does not exceed')
print('registered 5 seeds: T1 exceeds on',sum(a>b for s,a,b in res[:5]),'of 5; ties',sum(a==b for s,a,b in res[:5]))
print('KILL FIRED' if all(a<=b for s,a,b in res[:5]) else 'KILL NOT FIRED','(fires if T1<=S2 on all 5 seeds)')
a=np.array(res[5:]); print('supplementary seeds 5-204: T1>S2 %d, tie %d, T1<S2 %d; mean T1 %.3f mean S2 %.3f'%((a[:,1]>a[:,2]).sum(),(a[:,1]==a[:,2]).sum(),(a[:,1]<a[:,2]).sum(),a[:,1].mean(),a[:,2].mean()))
