# SCRIPT: LADDERWALL-OPP-01
# Opposite listing: at each closed-core count N, count openings BEYOND the half line (z > 3+2sqrt2) and openings that stay INSIDE, by Z.
# Same data, same closed set, same step definition as ladder_wall_01.py (exec'd).
# Why it decides: the registered kill (clause 2) asks whether closed-core openings are beyond the line; the per-core table shows where they are not.
# Frozen kill: the beyond-line count at closed-core openings exceeds the count of openings that stay inside, by Z, in fewer than half of the cores.
# Operationalised before the run: for each of the 11 closed cores with openings, 'exceeds' = (beyond count) > (inside count); fires if fewer than 5.5 cores (i.e. <= 5 of 11) exceed.
src=open('orig.py').read().split("for N in sorted(closed):")[0]
exec(src)
ex=0; tot=0
for N in sorted(closed):
    m=S[:,2]==N
    if m.sum()==0: continue
    zz=S[m]; b=zz[:,3]>Z0; nb=int(b.sum()); ni=int((~b).sum()); tot+=1; ex+= nb>ni
    print('core N=%2d: openings %3d  beyond %2d  inside %3d  beyond>inside: %s  | inside Z range %d..%d, beyond Z %s'%(N,len(zz),nb,ni,nb>ni,int(zz[~b][:,0].min()),int(zz[~b][:,0].max()),[int(z) for z in zz[b][:,0]]))
print('cores where beyond > inside:',ex,'of',tot)
print('KILL FIRED' if ex<tot/2 else 'KILL NOT FIRED','(fires if fewer than half of the cores)')
