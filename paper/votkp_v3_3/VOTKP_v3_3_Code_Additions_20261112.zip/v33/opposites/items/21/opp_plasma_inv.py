# SCRIPT: PLASMAWALL-OPP-01
# 1/E_wall alone against the three ladder readings (IE1, z1 = IE2/IE1, valence sum), same 30 elements as plasma_wall_01.py (exec'd).
# Why it decides: a rank correlation of 1/E_wall must be exactly minus that of E_wall (monotone decreasing map); registering the three numbers shows the check is a sign flip and nothing else.
# Frozen kill: abs(Spearman) of 1/E_wall against each of the three ladder readings below 0.5.
# Fires if all three |rho| < 0.5.
src=open('orig.py').read().split('A=np.array([[r[2],r[3],r[4],r[5],r[6]] for r in has])')[0]
exec(src)
A=np.array([[r[2],r[3],r[4],r[5],r[6]] for r in has]); big=[]
for j,name in ((2,'IE1'),(3,'z1'),(4,'valence sum')):
    m=~np.isnan(A[:,j]); r1,p1=spearmanr(A[m,0],A[m,j]); r2,p2=spearmanr(1.0/A[m,0],A[m,j]); big.append(abs(r2))
    print('Spearman 1/E_wall vs %-12s rho = %+.3f (p %.3g)   [E_wall: %+.3f]  n = %d'%(name,r2,p2,r1,m.sum()))
print('KILL FIRED' if all(b<0.5 for b in big) else 'KILL NOT FIRED','(fires if all three |rho| < 0.5)')
