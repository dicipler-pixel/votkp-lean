# SCRIPT: NEVERTURN-OPP-01
# Do the turners share something? Exhaustive single-field separation of the 4 hyperbolic never-turners (6_3, 7_5, 8_7, 8_8) from the 19 turners
# (names as in never_turn_01.py) over EVERY KnotInfo field available in database_knotinfo. Numeric fields: best single threshold, either direction.
# Categorical fields: best single "equals value v" indicator, either direction. Errors = misclassified knots out of 23.
# Why it decides: the original 26-knot lead-finding printed AUCs but never searched for an exact (<=1 error) separator on the 4 vs 19 split.
# Frozen kill: no KnotInfo field separates the 19 turners from the 4 never-turners with at most one error.
# Added control (numbers only): the same search on 2000 random 4-vs-19 relabellings of the same 23 knots, count of fields with <=1 error.
import numpy as np, random, warnings; warnings.filterwarnings('ignore')
from database_knotinfo import link_list
KI={r['name']:r for r in link_list()[1:]}
never=['6_3','7_5','8_7','8_8']
turn=['4_1','5_2','6_1','6_2','7_2','7_3','8_1','7_4','8_2','8_3','8_4','7_6','7_7','8_6','8_9','8_11','8_13','8_12','8_14']
names=never+turn; lab=np.array([1]*4+[0]*19)
def col(f): return [KI[n].get(f) for n in names]
def tofloat(v):
    try: return float(v)
    except Exception: return None
fields=[f for f in KI['6_3'] if not f.endswith('_anon')]
cols={}
for f in fields:
    v=col(f)
    if any(x in (None,'') for x in v): continue
    fl=[tofloat(x) for x in v]
    cols[f]=('num',np.array(fl)) if all(x is not None for x in fl) else ('cat',np.array(v,dtype=object))
def best_errors(kind,x,y):
    n=len(y)
    if kind=='num':
        best=n; vals=np.unique(x)
        cuts=list((vals[:-1]+vals[1:])/2) if len(vals)>1 else []
        for c in cuts:
            p=(x>c).astype(int); e=int((p!=y).sum()); best=min(best,e,n-e)
        return best
    best=n
    for v in set(x):
        p=(x==v).astype(int); e=int((p!=y).sum()); best=min(best,e,n-e)
    return best
res={f:best_errors(k,x,lab) for f,(k,x) in cols.items()}
print('fields tested:',len(res),'of',len(fields))
ok=sorted([f for f,e in res.items() if e<=1],key=lambda f:res[f])
print('fields with <=1 error:',len(ok))
for f in ok: print('  %-40s errors %d  kind %s'%(f,res[f],cols[f][0]))
random.seed(3); cnt=[]
for _ in range(2000):
    idx=random.sample(range(23),4); y=np.zeros(23,int); y[idx]=1
    cnt.append(sum(best_errors(k,x,y)<=1 for f,(k,x) in cols.items()))
print('control: random 4-of-23 labellings, fields with <=1 error: median %d, 5th-95th pct %d-%d, fraction of relabellings with at least as many as observed %.3f'%(np.median(cnt),np.percentile(cnt,5),np.percentile(cnt,95),np.mean(np.array(cnt)>=len(ok))))
print('KILL NOT FIRED' if ok else 'KILL FIRED','(fires if no field reaches <=1 error)')
