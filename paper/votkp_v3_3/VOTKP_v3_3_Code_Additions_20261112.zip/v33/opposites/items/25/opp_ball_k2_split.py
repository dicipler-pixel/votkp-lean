# SCRIPT: BALL-K2-OPP-01
# Split each whole-shell block's composed boost into its shell part and its screening part (tau = 2 dln Zeff - 2 dln n, the RHYTHM/Thm 8.2 split).
# For a block of stages a+1 .. a+n (ladder indices a..a+n-1, r = IE_last/IE_first): ln r = [2 ln Zeff_last/Zeff_first] - [2 ln n_last/n_first], n = highest principal quantum number of the ion's ground configuration (rdata.nmax).
# shell part r_sh = (n_first/n_last)^2 ; screening part r_scr = r / r_sh ; G2(x) = ((x-1)/(x+1))^2.
# Same 405 real blocks as element_ball_01.py (those with ground configurations for first and last stage), same random-block null (5000 draws, same pool, same seed rule), same score: median |G2 - 1/2|.
# Why it decides: K2 failed on the whole composed boost (ratio 1.362). The registered idea is that the SHELL part sits at the wall and screening does not; the split asks which part carries the miss.
# Frozen kill: shell part median abs(G^2 - 1/2) not at most half that of random blocks, p < 0.01.
# Fires unless (median_shell <= 0.5 x random median_shell and p < 0.01).
import os, sys, json, gzip, math, random
sys.path.insert(0,os.environ['VOTKP_ROOT']+'/rhythm')
from rdata import SH, IE, nmax
G2=lambda x: ((x-1)/(x+1))**2
d=json.load(gzip.open('/home/claude/repos/votkp-lean/data/element_thresholds_20261011.json.gz'))['records']
NOBLE={0,2,10,18,36,54,86,118}
ladders={}; Zof={}
blocks=[]
for r in d:
    Z,s=r['Z'],r['symbol']; ie={t['q']:t['IE_eV'] for t in r['thresholds'] if t.get('IE_eV')}; qs=sorted(ie); n=0
    while n<len(qs) and qs[n]==n: n+=1
    lad=[ie[q] for q in range(n)]; ladders[s]=lad; Zof[s]=Z
    cuts=[q+1 for q in range(len(lad)-1) if (Z-q-1) in NOBLE]; edges=[0]+cuts+[len(lad)]
    for a,b in zip(edges,edges[1:]):
        if b-a>=3: blocks.append((s,Z,a,b-a))
def parts(s,Z,a,n):
    lad=ladders[s]; r=lad[a+n-1]/lad[a]
    if Z not in SH or (a+1) not in SH[Z] or (a+n) not in SH[Z]: return None
    n1,n2=nmax(SH[Z][a+1]),nmax(SH[Z][a+n]); rs=(n1/n2)**2
    return G2(r),G2(rs),G2(r/rs)
real=[p for p in (parts(*b) for b in blocks) if p]
print('blocks',len(blocks),'with configuration data',len(real))
random.seed(1)
pool=[(s,Zof[s]) for s,l in ladders.items() if len(l)>=3]
lens=[b[3] for b in blocks if parts(*b)]
def med(v): v=sorted(v); return v[len(v)//2]
out={}
for idx,name in ((0,'whole boost'),(1,'shell part'),(2,'screening part')):
    out[name]=med([abs(p[idx]-.5) for p in real])
meds={'whole boost':[],'shell part':[],'screening part':[]}
for _ in range(5000):
    cur={0:[],1:[],2:[]}
    for n in lens:
        while True:
            s,Z=random.choice(pool); l=ladders[s]
            if len(l)>=n:
                a=random.randrange(len(l)-n+1); p=parts(s,Z,a,n)
                if p: break
        for i in range(3): cur[i].append(abs(p[i]-.5))
    for i,name in enumerate(('whole boost','shell part','screening part')): meds[name].append(med(cur[i]))
for name in out:
    cm=med(meds[name]); p=sum(m<=out[name] for m in meds[name])/len(meds[name])
    print('%-15s real median |G2-1/2| = %.4f   random median %.4f   ratio %.3f   p(random <= real) = %.4f'%(name,out[name],cm,out[name]/cm,p))
    if name=='shell part': ok=(out[name]<=cm/2 and p<.01)
print('KILL NOT FIRED' if ok else 'KILL FIRED','(fires unless shell median <= half of random and p < 0.01)')
