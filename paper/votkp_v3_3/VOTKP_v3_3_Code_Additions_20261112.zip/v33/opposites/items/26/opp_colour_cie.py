# SCRIPT: COLOURPEEL03-OPP-01
# Other weights for the strict COLOUR-PEEL-03 form: CIE luminous weights in place of Exner (43.33, 32.76, 1).
# Sets (written before the run): (a) sRGB/Rec.709 luminance (0.2126, 0.7152, 0.0722); (b) CIE 1931 RGB luminous coefficients (1.0, 4.5907, 0.0601).
# Same sampler, N=20000, seeds 1,2,3, same strict tolerance (stretch only if sch(Mx,My) > sch(x,y)(1+1e-12)); run() exec'd from colour_peel_03.py.
# Why it decides: the original stretch rate toward share-white (4.97-5.59%) above away (3.25-3.36%) was shown only for Exner-type weights; other positive weights test whether it is a property of two-channel forcing or of those numbers.
# Frozen kill: stretch rate toward white not above away at the registered tolerance with CIE weights.
# Fires if, for any of the 2 weight sets x 3 seeds, the toward-white stretch rate is not above the away rate.
import re, io, contextlib, numpy as np
src=open('orig.py').read().split('for seed in (1,2,3):')[0]
exec(src)
fire=False
for lab,a in (('sRGB Y',np.array([0.2126,0.7152,0.0722])),('CIE1931 RGB',np.array([1.0,4.5907,0.0601]))):
    for seed in (1,2,3):
        buf=io.StringIO()
        with contextlib.redirect_stdout(buf): run(a,'%s seed %d'%(lab,seed),seed)
        line=buf.getvalue().strip(); print(line)
        m=re.findall(r'\(([\d.]+)%\)',line); tw,aw=float(m[0]),float(m[1]); ok=tw>aw; fire|=not ok
        print('    toward %.2f%% vs away %.2f%% ->'%(tw,aw),'toward above away' if ok else 'NOT above')
print('KILL FIRED' if fire else 'KILL NOT FIRED','(fires if toward is not above away in any of the six runs)')
