# SCRIPT: HIDDENG-OPP-01
# Other family class for the knot-side hidden level: links NOT used in HIDDEN-G-02 (not Whitehead L5a1, not L6a2, L7a5, L7a6):
# L6a1, L6a3, L6a4, L6n1, L7a1, L7a2, L7a3, L7a4, L7a7, L7n1, L7n2; both cusps, slopes (1,a), same fit, same counting rule, same 'negative real' test
# (family() and fitH() are exec'd unchanged from hidden_g_02.py).
# Why it decides: HIDDEN-G-02 found g negative real in 4 of 45 counted fits (Hermitian-coupled reading killed there); new links show whether that is the Whitehead/near-Whitehead family.
# Frozen kill: g negative real in fewer than 40 of 45 on a non-Whitehead family.
# Operationalised before run: over all counted fits on the new links, fires if (negative real)/(counted) < 40/45.
src=open('orig.py').read().split("for name,cusp in (('L5a1',1),('L5a1',0)): family(name,cusp,'(1,a)')")[0]
exec(src)
import sys
for name in ('L6a1','L6a3','L6a4','L6n1','L7a1','L7a2','L7a3','L7a4','L7a7','L7n1','L7n2'):
    for cusp in (0,1):
        try: family(name,cusp,'(1,a)')
        except Exception as e: print('\n',name,cusp,'failed:',repr(e)[:80])
        sys.stdout.flush()
print('\nTOTAL new links: fits %d ; counted %d ; counted with g negative real %d ; Re g<0 %d'%(tot['fam'],tot['counts'],tot['negreal'],tot['reneg']))
frac=tot['negreal']/max(tot['counts'],1)
print('negative real fraction among counted: %.3f (threshold %.3f)'%(frac,40/45))
print('KILL FIRED' if frac<40/45 else 'KILL NOT FIRED','(fires if fraction < 40/45; counted =',tot['counts'],')')
