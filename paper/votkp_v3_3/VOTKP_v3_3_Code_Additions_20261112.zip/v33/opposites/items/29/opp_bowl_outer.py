# SCRIPT: BOWLHALF-OPP-01
# Opposite = look at the OUTER region (|G|^2 >= 1/2; 8 tetrahedra among 2777) as well as the circle average across 1/2.
# Quantities from bowl_half_01.py (exec'd): D(z), zofG, V0, k2, same tetrahedra (knots to 10 crossings) and same bowl+quartic error.
# Registered before the run, two readings of "shows something at 1/2":
#  (a) circle average m(r^2) on the grid r^2 = 0.05..0.95 step 0.01: the second difference at 0.50 exceeds 10 x the median |second difference| over the grid excluding 0.48..0.52.
#  (b) change of character of the error: OLS of log10|bowl error| on [1, |G|^2, max(|G|^2 - 1/2, 0)] over tetrahedra with |G|^2 >= 0.1; the hinge coefficient is significant at p < 0.01 (|t| > 2.58).
# Frozen kill: neither the circle average nor the error shows anything at 1/2 in the 8 outside tetrahedra's region.
# Fires if neither (a) nor (b).
import numpy as np, mpmath as mp
src=open('orig.py').read().split("print('circle average")[0]
exec(src)
r2=np.round(np.arange(0.05,0.951,0.01),2); th=np.linspace(0,2*np.pi,361)[:-1]
m=np.array([np.mean([D(zofG(np.sqrt(x)*np.exp(1j*t))) for t in th]) for x in r2])
sd=m[2:]-2*m[1:-1]+m[:-2]; mid=r2[1:-1]; at=sd[np.argmin(abs(mid-0.5))]
ref=np.median(abs(sd[(abs(mid-0.5)>0.02)]))
print('(a) second difference at 0.50: %.3e ; median |second difference| elsewhere: %.3e ; ratio %.2f'%(at,ref,abs(at)/ref))
a_flag=abs(at)>10*ref
G2=[];err=[]
for k in link_list()[1:]:
    if int(k['crossing_number'])>10: continue
    try: M=snappy.Manifold(k['name'])
    except Exception: continue
    if M.volume()<1e-6: continue
    for z in M.tetrahedra_shapes('rect'):
        z=complex(z); G=(z-w)/(z-np.conj(w)); g2=abs(G)**2; d=D(z)
        q=V0-k2*g2+np.sqrt(3)/8*2*(G**3).real+3*np.sqrt(3)/16*g2*g2
        G2.append(g2); err.append(q-d)
G2=np.array(G2); err=np.array(err); sel=(G2>=0.1)&(abs(err)>0)
y=np.log10(abs(err[sel])); X=np.c_[np.ones(sel.sum()),G2[sel],np.maximum(G2[sel]-0.5,0)]
b,res,rk,sv=np.linalg.lstsq(X,y,rcond=None); s2=((y-X@b)**2).sum()/(len(y)-3); cov=s2*np.linalg.inv(X.T@X); t=b[2]/np.sqrt(cov[2,2])
print('(b) tetrahedra with |G|^2>=0.1: %d, of which outside (>=0.5): %d ; hinge coefficient %.3f, t = %.2f'%(sel.sum(),int((G2[sel]>=0.5).sum()),b[2],t))
b_flag=abs(t)>2.58
print('outside tetrahedra signed errors:',np.round(err[G2>=0.5],4).tolist())
print('KILL NOT FIRED' if (a_flag or b_flag) else 'KILL FIRED','(a shows: %s ; b shows: %s)'%(a_flag,b_flag))
