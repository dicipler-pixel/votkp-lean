# SCRIPT: DIELECTRICS-OPP-01
# A new set of dielectrics: tabulated-nk materials from the glass, organic, other and specs shelves of the local refractiveindex.info copy
# (the original used the main shelf only), same selection rule as dielectrics_01.py (covers 0.40-0.70 um, >=3 points inside 0.38-0.78 um, best file = most points).
# If more than 40 qualify, the first 40 in alphabetical order of shelf/material are used (fixed before the run); otherwise all that qualify, with the count stated.
# Why it decides: the original 79.7% within 10 degrees of the real axis (kill for 'fill' was > 90%) was measured on one shelf (94 compounds).
# Frozen kill: below 90% within 10 degrees on a new set of 40 dielectrics.
# Read literally: fires if the fraction within 10 degrees of the real axis is below 0.90 on the new set (i.e. the original 'not fired' is reproduced).
import os, re, yaml, numpy as np, warnings; warnings.filterwarnings('ignore')
R='/home/claude/closure/s23_s24/ri/db/database/data'
def load(path):
    try: d=yaml.safe_load(open(path))
    except Exception: return None
    for blk in d.get('DATA',[]):
        if blk.get('type')=='tabulated nk':
            try: arr=np.array([[float(x) for x in ln.split()] for ln in blk['data'].strip().split('\n') if ln.strip()])
            except Exception: return None
            if arr.ndim==2 and arr.shape[1]>=3: return arr[:,0],arr[:,1],arr[:,2]
    return None
rows=[]
for shelf in ('glass','organic','other','specs'):
    for mat in sorted(os.listdir(os.path.join(R,shelf))):
        best=None
        for dp,dn,fn in os.walk(os.path.join(R,shelf,mat)):
            for f in fn:
                if not f.endswith('.yml'): continue
                r=load(os.path.join(dp,f))
                if r is None: continue
                lam,n,k=r
                if lam.min()>0.40 or lam.max()<0.70: continue
                m=(lam>=0.38)&(lam<=0.78)
                if m.sum()<3: continue
                if best is None or m.sum()>best[0]: best=(m.sum(),n[m]+1j*k[m])
        if best: rows.append((shelf+'/'+mat,best[1]))
print('qualifying new-shelf materials:',len(rows),' using',min(40,len(rows)))
rows=rows[:40]
allG=np.concatenate([(1-N)/(1+N) for _,N in rows]); g2=np.abs(allG)**2; ang=np.degrees(np.abs(np.angle(-allG)))
print('points',len(allG),' |G|^2<1/2: %.3f'%np.mean(g2<.5),' within 10 deg: %.3f'%np.mean(ang<10),' within 30 deg: %.3f'%np.mean(ang<30))
frac=np.mean(ang<10)
print('KILL FIRED' if frac<0.90 else 'KILL NOT FIRED','(fires if fraction within 10 degrees < 0.90; n materials =',len(rows),')')
