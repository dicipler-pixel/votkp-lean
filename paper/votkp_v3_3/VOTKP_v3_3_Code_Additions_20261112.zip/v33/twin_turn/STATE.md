# STATE T2_twin_turn  (worker T2_twin_turn)

## Step 1 DONE: original script and definition (one definition only exists)
Original: /home/claude/nov/steps_a/unz/VOTKP_session_outputs_20261110_v1/chain_whole_03.py (copied here as orig_chain_whole_03.py).
Definition: twin pairs (a,a+2), a>=11. Step from pair a to next pair a' uses z=a'/a and axis of the LAST DIGIT OF a' (1,7,9 -> sigma_x, sigma_y, sigma_z).
Step matrix B=((z+1)/(2 sqrt z)) I + ((z-1)/(2 sqrt z)) sigma_axis. M = B_1 B_2 ... B_n (right multiplication). Polar split M = H U (H = (MM^dag+I)/sqrt(tr+2), exact for det 1).
Frame turn = angle of U = 2*atan2(|v|, c), c=Re tr U/2, v_k=-Im tr(U sigma_k)/2 (sign fixed so c>=0). Cut-off = first twin a' >= mark.
## Step 2 DONE: original reproduced unchanged (orig_run.out): 9.86997, 11.61993, 12.07249 (1e5,1e6,1e7), 12.07976 at 19,999,547. Matches 9.87/11.62/12.07/12.08.

## Written BEFORE the long run (step 4)
KILL LINE (ledger item 28): angle at first twin >=1e9 differs from angle at first twin >=1e7 by more than 0.1 degree  => "settles" is killed in this setup.
MY SETTLE TEST (own): record angles A at 1e5,1e6,1e7,3e7,1e8,3e8,1e9. Take differences per decade D(6->7)=0.4526 (known), D(7->8), D(8->9).
 Settled iff D(7->8) <= 0.5*D(6->7)  AND  D(8->9) <= 0.5*D(7->8)  AND |A(1e9)-A(1e7)| <= 0.1.
 Why it decides: the known decade steps are 1.75 then 0.45 (ratio about 0.26). A convergent sequence must keep shrinking by a factor below 1 each decade, so the tail beyond 1e9 is bounded by D(8->9)*r/(1-r) < D(8->9). If the differences instead stay level or grow (ratio >=1) the turn is growing with the path ln(a), not converging. Ratio between 0.5 and 1 = undecided/slow.
 If not settled: fit nothing; report the sequence; opposite readings under the same budget: turn per chain step (A/n), turn against path ln(a/11), tan(A/2) (peel-type coordinate of the rotation), and the reversed word (B_n...B_1).
PRECISION CHECK: run same walk in float64 and in mpmath at 40 digits; they must agree to 1e-9 degree, otherwise float64 is not valid.

## Files
sieve_twins.py (segmented numpy sieve -> tw/tw_XXX.npy, resumable), walk.py (resumable walker, mode float or mp), out/ results.
walk float done to 1e9 (out/marks_float.jsonl); mp running: nohup python3 -I walk.py mp 100 (resumable)
ALL STEPS DONE. 1e9 reached in mp and float. Kill line fires (0.197 deg). REPORT.md written.
