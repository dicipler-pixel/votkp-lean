# SCRIPT: SIEVE-TWINS-T2
# Segmented sieve; writes lower members of twin pairs (a, a+2), a>=11, per segment of 1e7 into tw/tw_NNN.npy. Skips finished segments (resumable).
import numpy as np, os, sys
SEG=10**7; TOP=int(float(sys.argv[1])) if len(sys.argv)>1 else 10**9
base_lim=int(TOP**0.5)+10
b=np.ones(base_lim+1,bool); b[:2]=False
for i in range(2,int(base_lim**.5)+1):
    if b[i]: b[i*i::i]=False
bp=np.nonzero(b)[0]
here=os.path.dirname(os.path.abspath(__file__))
for k in range(TOP//SEG):
    fn=os.path.join(here,'tw','tw_%03d.npy'%k)
    if os.path.exists(fn): continue
    lo=k*SEG; hi=lo+SEG+2           # sieve [lo,hi) so that a in [lo,lo+SEG) has a+2 inside
    s=np.ones(hi-lo,bool)
    if lo==0: s[:2]=False
    for p in bp:
        if p*p>=hi: break
        st=max(p*p,((lo+p-1)//p)*p)
        s[st-lo::p]=False
    idx=np.nonzero(s[:SEG]&s[2:SEG+2])[0]+lo
    idx=idx[idx>=11]
    np.save(fn+'.tmp.npy',idx.astype(np.int64)); os.replace(fn+'.tmp.npy',fn)
    print('seg',k,len(idx),flush=True)
