# SCRIPT: WALK-T2
# Resumable walk of the twin-chain frame turn. Usage: python3 walk.py float|mp
# Definition identical to chain_whole_03.py: step from pair a to next pair a2: z=a2/a, B=(z+1)k I+(z-1)k sigma_arm(a2%10), k=1/(2 sqrt z); M=M*B.
# Checkpoint after every 1e7 segment: out/state_<mode>.json. Marks recorded to out/marks_<mode>.csv.
import numpy as np, os, sys, json, math
mode=sys.argv[1]; here=os.path.dirname(os.path.abspath(__file__))
NSEG=int(sys.argv[2]) if len(sys.argv)>2 else 100
MARKS=[10**5,10**6,10**7,3*10**7,10**8,3*10**8,10**9]
if mode=='mp':
    import mpmath as mp
    mp.mp.dps=40
    C=mp.mpc; R=mp.mpf; SQ=mp.sqrt
    def num(x): return R(x)
    def ser(m): return [[str(x.real),str(x.imag)] for r in m for x in r]
    def des(l): return [[C(R(l[0][0]),R(l[0][1])),C(R(l[1][0]),R(l[1][1]))],[C(R(l[2][0]),R(l[2][1])),C(R(l[3][0]),R(l[3][1]))]]
    ONE=C(1,0); ZERO=C(0,0); I=C(0,1)
    atan2=mp.atan2; acosh=mp.acosh; log=mp.log; deg=lambda x: float(x*180/mp.pi)
    NORM=lambda v: mp.sqrt(sum(x*x for x in v))
else:
    C=complex; R=float; SQ=math.sqrt
    def num(x): return float(x)
    def ser(m): return [[repr(x.real),repr(x.imag)] for r in m for x in r]
    def des(l): return [[complex(float(l[0][0]),float(l[0][1])),complex(float(l[1][0]),float(l[1][1]))],[complex(float(l[2][0]),float(l[2][1])),complex(float(l[3][0]),float(l[3][1]))]]
    ONE=1+0j; ZERO=0j; I=1j
    atan2=math.atan2; acosh=math.acosh; log=math.log; deg=math.degrees
    NORM=lambda v: math.sqrt(sum(x*x for x in v))
def mul(A,B):
    return [[A[0][0]*B[0][0]+A[0][1]*B[1][0],A[0][0]*B[0][1]+A[0][1]*B[1][1]],[A[1][0]*B[0][0]+A[1][1]*B[1][0],A[1][0]*B[0][1]+A[1][1]*B[1][1]]]
def step(c,s,arm):
    if arm==0: return [[c,s+ZERO],[s+ZERO,c]]
    if arm==1: return [[c,-I*s],[I*s,c]]
    return [[c+s,ZERO],[ZERO,c-s]]
def conjT(M): return [[M[0][0].conjugate(),M[1][0].conjugate()],[M[0][1].conjugate(),M[1][1].conjugate()]]
def read(M,n,a2,a1):
    P=mul(M,conjT(M)); tr=(P[0][0]+P[1][1]).real
    f=SQ(tr+2); H=[[(P[0][0]+1)/f,P[0][1]/f],[P[1][0]/f,(P[1][1]+1)/f]]
    Hi=[[H[1][1],-H[0][1]],[-H[1][0],H[0][0]]]; U=mul(Hi,M)
    c=(U[0][0]+U[1][1]).real/2
    # tr(U sigma_x)=U01+U10 ; sigma_y: -i U01 + i U10 ; sigma_z: U00-U11
    t=[U[0][1]+U[1][0], -I*U[0][1]+I*U[1][0], U[0][0]-U[1][1]]
    v=[-(x.imag)/2 for x in t]
    if c<0: c=-c; v=[-x for x in v]
    nv=NORM(v); ang=2*atan2(nv,c)
    d=acosh(max(R(1),tr/2)); L=log(R(a2)/11)
    return dict(a=a2,n=n,turn_deg=deg(ang),ax=[float(x/nv) for x in v],dist=float(d),path=float(L),tanhalf=float(nv/c),re_ok=float(abs(U[0][0]*U[1][1]-U[0][1]*U[1][0]-1)))
sf=os.path.join(here,'out','state_%s.json'%mode); mf=os.path.join(here,'out','marks_%s.jsonl'%mode)
if os.path.exists(sf):
    S=json.load(open(sf)); M=des(S['M']); Rv=des(S['Rv']); prev=S['prev']; n=S['n']; seg0=S['seg']; mi=S['mi']
else:
    M=[[ONE,ZERO],[ZERO,ONE]]; Rv=[[ONE,ZERO],[ZERO,ONE]]; prev=None; n=0; seg0=0; mi=0
for seg in range(seg0,NSEG):
    fn=os.path.join(here,'tw','tw_%03d.npy'%seg)
    if not os.path.exists(fn): print('missing',fn); break
    arr=[int(x) for x in np.load(fn)]
    for a2 in arr:
        if prev is None: prev=a2; continue
        z=R(a2)/R(prev); k=1/(2*SQ(z)); c=(z+1)*k; s=(z-1)*k
        B=step(c,s,{1:0,7:1,9:2}[a2%10])
        M=mul(M,B)
        if mode=='float': Rv=mul(B,Rv)
        n+=1; prev=a2
        if mi<len(MARKS) and a2>=MARKS[mi]:
            r=read(M,n,a2,prev); r['mark']=MARKS[mi]
            if mode=='float': rr=read(Rv,n,a2,prev); r['rev_turn_deg']=rr['turn_deg']; r['rev_ax']=rr['ax']
            open(mf,'a').write(json.dumps(r)+'\n'); print(mode,'mark',MARKS[mi],'a',a2,'n',n,'turn %.8f'%r['turn_deg'],flush=True); mi+=1
    json.dump(dict(M=ser(M),Rv=ser(Rv),prev=prev,n=n,seg=seg+1,mi=mi),open(sf+'.tmp','w')); os.replace(sf+'.tmp',sf)
    print(mode,'checkpoint seg',seg+1,'n',n,flush=True)
